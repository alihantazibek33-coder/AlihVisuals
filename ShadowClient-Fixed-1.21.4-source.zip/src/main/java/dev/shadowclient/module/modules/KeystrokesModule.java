package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class KeystrokesModule extends ClientModule {
    public KeystrokesModule() { super("Keystrokes", "Shows movement keys and mouse clicks.", ModuleCategory.HUD); }
}
