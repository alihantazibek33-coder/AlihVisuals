package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class ArmorStatusModule extends ClientModule {
    public ArmorStatusModule() { super("Armor Status", "Shows equipped armor durability.", ModuleCategory.HUD); }
}
