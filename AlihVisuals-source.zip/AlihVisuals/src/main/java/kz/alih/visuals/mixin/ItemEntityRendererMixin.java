package kz.alih.visuals.mixin;

import kz.alih.visuals.ItemPhysics;
import kz.alih.visuals.Modules;
import kz.alih.visuals.PhysicsHolder;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntityRenderer.class)
public abstract class ItemEntityRendererMixin {

    @Inject(method = "updateRenderState(Lnet/minecraft/entity/ItemEntity;Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V",
            at = @At("RETURN"), require = 0)
    private void alih$update(ItemEntity entity, ItemEntityRenderState state, float td, CallbackInfo ci) {
        if (!Modules.ITEMPHYSIC.enabled) return;
        float[] d = ItemPhysics.data(entity, entity.isOnGround());
        float angle = (entity.getItemAge() + td) * 28f;
        float yaw = entity.uniqueOffset * 57.29578f;
        ((PhysicsHolder) (Object) state).alih$set(d[0], angle, yaw);
    }

    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void alih$render(ItemEntityRenderState state, MatrixStack ms, VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        if (!Modules.ITEMPHYSIC.enabled) return;
        if (state.itemRenderState.isEmpty()) return;
        PhysicsHolder h = (PhysicsHolder) (Object) state;
        float b = h.alih$blend(), a = h.alih$angle(), yaw = h.alih$yaw();
        ms.push();
        ms.translate(0f, 0.06f + 0.19f * b, 0f);
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw + b * a * 0.5f));
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90f + b * a));
        ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(b * a * 0.7f));
        state.itemRenderState.render(ms, vcp, light, OverlayTexture.DEFAULT_UV);
        ms.pop();
        ci.cancel();
    }
}
