package kz.alih.visuals.cosmetics;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.stream.Stream;

/**
 * What is equipped + the list of all cosmetics found in config/alihvisuals/cosmetics.
 * Drop your own .png/.gif capes into capes/ and Blockbench .bbmodel (or .zip) files into models/.
 */
public final class CosmeticsState {
    public record Entry(String id, String name, CosmeticType type, Path file, String variant) {}

    private static final CosmeticsState I = new CosmeticsState();
    public static CosmeticsState get() { return I; }

    private final Map<CosmeticType, String> selected = new EnumMap<>(CosmeticType.class);
    private final Map<String, Entry> byId = new HashMap<>();
    private List<Entry> catalog = List.of();

    /** other players' loadouts (filled later by a sync service); key = player uuid */
    private final Map<UUID, Map<CosmeticType, String>> remote = new HashMap<>();

    public boolean hideElytra = true;
    public float wingMotion = 1f;
    public float petFollow = 0.6f;

    // render state -> player uuid (filled by PlayerEntityRendererCosmeticsMixin)
    private static final Map<Object, UUID> BOUND = Collections.synchronizedMap(new WeakHashMap<>());
    public static void bind(Object renderState, UUID uuid) { BOUND.put(renderState, uuid); }
    public static UUID boundUuid(Object renderState) { return BOUND.get(renderState); }

    private CosmeticsState() {}

    // ------------------------------------------------------------------ setup
    public Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("alihvisuals").resolve("cosmetics"); }
    private Path settingsFile() { return FabricLoader.getInstance().getConfigDir().resolve("alihvisuals").resolve("cosmetics.properties"); }

    public void init() {
        installBundled();
        refresh();
        load();
    }

    private void installBundled() {
        try {
            Files.createDirectories(dir().resolve("capes"));
            Files.createDirectories(dir().resolve("models"));
            Optional<ModContainer> mod = FabricLoader.getInstance().getModContainer("alihvisuals");
            if (mod.isEmpty()) return;
            Optional<Path> index = mod.get().findPath("assets/alihvisuals/cosmetics/index.txt");
            if (index.isEmpty()) return;
            for (String line : Files.readAllLines(index.get())) {
                String rel = line.trim();
                if (rel.isEmpty()) continue;
                Path target = dir().resolve(rel);
                if (Files.exists(target)) continue;
                Optional<Path> src = mod.get().findPath("assets/alihvisuals/cosmetics/" + rel);
                if (src.isPresent()) Files.copy(src.get(), target, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ignored) {
            // cosmetics are optional, never break the game
        }
    }

    // ------------------------------------------------------------------ catalog
    public synchronized void refresh() {
        List<Entry> list = new ArrayList<>();
        scan(dir().resolve("capes"), list, true);
        scan(dir().resolve("models"), list, false);
        list.sort((a, b) -> {
            int c = Integer.compare(a.type().ordinal(), b.type().ordinal());
            return c != 0 ? c : a.name().compareToIgnoreCase(b.name());
        });
        catalog = list;
        byId.clear();
        for (Entry e : list) byId.put(e.id(), e);
    }

    private void scan(Path folder, List<Entry> out, boolean capes) {
        if (!Files.isDirectory(folder)) return;
        try (Stream<Path> s = Files.list(folder)) {
            s.filter(Files::isRegularFile).forEach(p -> {
                String file = p.getFileName().toString();
                String low = file.toLowerCase(Locale.ROOT);
                if (capes) {
                    if (!(low.endsWith(".png") || low.endsWith(".gif"))) return;
                    out.add(new Entry("cape:" + file, capeName(file), CosmeticType.CAPE, p, null));
                } else {
                    if (!(low.endsWith(".bbmodel") || low.endsWith(".zip"))) return;
                    CosmeticType type = modelType(low);
                    String name = modelName(file);
                    List<String> variants = (type == CosmeticType.HAT || type == CosmeticType.WING) ? BBModel.variants(p, type) : List.of();
                    if (variants.size() >= 2) {
                        int i = 1;
                        for (String v : variants) out.add(new Entry("model:" + file + "#" + v, name + " " + (i++), type, p, v));
                    } else {
                        out.add(new Entry("model:" + file, name, type, p, null));
                    }
                }
            });
        } catch (IOException ignored) {}
    }

    private static CosmeticType modelType(String low) {
        if (low.contains("wing") || low.contains("wimg")) return CosmeticType.WING;
        if (low.contains("hat") || low.contains("turtle") || low.contains("helmet")) return CosmeticType.HAT;
        return CosmeticType.PET;
    }

    private static String stripExt(String file) {
        int dot = file.lastIndexOf('.');
        return dot > 0 ? file.substring(0, dot) : file;
    }

    private static String modelName(String file) {
        return stripExt(file).replaceAll("\\s+v?\\d+(\\.\\d+)*$", "").trim();
    }

    private static String capeName(String file) {
        String n = stripExt(file);
        if (n.matches("[0-9a-fA-F]{32}")) return "Cape " + n.substring(0, 4).toUpperCase(Locale.ROOT);
        StringBuilder sb = new StringBuilder();
        for (String part : n.replace('_', ' ').replace('-', ' ').split(" +")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    public synchronized List<Entry> catalog() { return catalog; }

    public synchronized Entry byId(String id) { return id == null ? null : byId.get(id); }

    // ------------------------------------------------------------------ selection
    public synchronized Entry selected(CosmeticType t) { return byId(selected.get(t)); }

    /** equips the entry, or unequips it if it is already equipped */
    public synchronized void toggle(Entry e) {
        if (e.id().equals(selected.get(e.type()))) selected.remove(e.type());
        else selected.put(e.type(), e.id());
        save();
    }

    /** used when a cosmetic fails to render: takes it off so the game never crash-loops */
    public synchronized void unequip(CosmeticType t) {
        if (selected.remove(t) != null) save();
    }

    public synchronized void clearAll() {
        selected.clear();
        save();
    }

    public synchronized boolean isSelected(Entry e) { return e.id().equals(selected.get(e.type())); }

    public synchronized boolean anySelected() { return !selected.isEmpty(); }

    /** what player [uuid] wears; you = local selection, others = synced loadout (if any) */
    public synchronized Entry selectedFor(UUID uuid, CosmeticType t) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.player.getUuid().equals(uuid)) return selected(t);
        Map<CosmeticType, String> m = remote.get(uuid);
        return m == null ? null : byId(m.get(t));
    }

    public synchronized void setRemote(UUID uuid, Map<CosmeticType, String> loadout) {
        if (loadout == null || loadout.isEmpty()) remote.remove(uuid); else remote.put(uuid, loadout);
    }

    /** current loadout as ids, for a future sync service */
    public synchronized Map<CosmeticType, String> localLoadout() { return new EnumMap<>(selected); }

    // ------------------------------------------------------------------ persistence
    private synchronized void load() {
        Path f = settingsFile();
        if (!Files.exists(f)) return;
        try (var in = Files.newInputStream(f)) {
            Properties p = new Properties();
            p.load(in);
            for (CosmeticType t : CosmeticType.values()) {
                String id = p.getProperty(t.name().toLowerCase(Locale.ROOT), "");
                if (!id.isEmpty() && byId.containsKey(id)) selected.put(t, id);
            }
            hideElytra = Boolean.parseBoolean(p.getProperty("hideElytra", "true"));
            wingMotion = parse(p.getProperty("wingMotion"), 1f, 0f, 2f);
            petFollow = parse(p.getProperty("petFollow"), 0.6f, 0f, 1f);
        } catch (Exception ignored) {}
    }

    private static float parse(String s, float def, float min, float max) {
        try { return Math.max(min, Math.min(max, Float.parseFloat(s))); } catch (Exception e) { return def; }
    }

    public synchronized void save() {
        try {
            Files.createDirectories(settingsFile().getParent());
            Properties p = new Properties();
            for (CosmeticType t : CosmeticType.values()) p.setProperty(t.name().toLowerCase(Locale.ROOT), selected.getOrDefault(t, ""));
            p.setProperty("hideElytra", String.valueOf(hideElytra));
            p.setProperty("wingMotion", String.valueOf(wingMotion));
            p.setProperty("petFollow", String.valueOf(petFollow));
            try (var out = Files.newOutputStream(settingsFile())) { p.store(out, "AlihVisuals cosmetics"); }
        } catch (Exception ignored) {}
    }
}
