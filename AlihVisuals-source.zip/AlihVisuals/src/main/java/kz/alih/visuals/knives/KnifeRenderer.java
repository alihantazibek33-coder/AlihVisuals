package kz.alih.visuals.knives;

import kz.alih.visuals.cosmetics.BBModel;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * Draws the chosen knife in the first-person hand.
 * Motions (all authored here): draw flourish, idle sway, slash (alternating direction), stab (right click),
 * and an inspect animation per knife. Push daggers use both hands.
 */
public final class KnifeRenderer {
    private static final Map<String, String> MODEL_JSON = new HashMap<>();
    private static final Map<String, byte[]> SKIN_BYTES = new HashMap<>();
    private static final float STAB_SECONDS = 0.55f;
    private static final float DRAW_SECONDS = 0.9f;

    private KnifeRenderer() {}

    // ------------------------------------------------------------------ resources
    private static byte[] read(String path) {
        try (InputStream in = MinecraftClient.getInstance().getResourceManager().open(Identifier.of("alihvisuals", path))) {
            return in.readAllBytes();
        } catch (Throwable t) {
            return null;
        }
    }

    public static BBModel model(KnifeData.Knife k, String skin) {
        String json = MODEL_JSON.get(k.id());
        if (json == null) {
            byte[] b = read("knives/models/" + k.id() + ".bbmodel");
            if (b == null) return null;
            json = new String(b, StandardCharsets.UTF_8);
            MODEL_JSON.put(k.id(), json);
        }
        String key = k.id() + "_" + skin;
        byte[] png = SKIN_BYTES.get(key);
        if (png == null) {
            png = read("knives/skins/" + key + ".png");
            if (png == null) return null;
            SKIN_BYTES.put(key, png);
        }
        return BBModel.loadSkinned("knife:" + key, json, png);
    }

    // ------------------------------------------------------------------ easing
    private static float clamp01(float v) { return v < 0f ? 0f : Math.min(1f, v); }
    private static float smooth(float v) { v = clamp01(v); return v * v * (3f - 2f * v); }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float easeOutBack(float v) {
        v = clamp01(v);
        float c1 = 1.70158f, c3 = c1 + 1f, u = v - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    // ------------------------------------------------------------------ view-space motion (translation in blocks, rotation in degrees)
    private static final class Move { float x, y, z, pitch, yaw, roll; }

    /** slash: dir = +1 right-to-left sweep, -1 the way back; alternates with every attack */
    private static void slash(KnifeData.Knife k, float p, int dir, Move m) {
        float e = (float) Math.sin(Math.PI * p), f = smooth(p);
        float heavy = switch (k.id()) {
            case "bowie", "gut", "falchion", "huntsman" -> 1.25f;
            case "butterfly", "karambit" -> 0.85f;
            default -> 1f;
        };
        switch (k.id()) {
            case "shadow" -> {                       // fist jab
                m.z += -0.50f * e; m.y += -0.04f * e; m.pitch += -8f * e; m.yaw += 10f * dir * e;
            }
            case "karambit" -> {                     // claw rake from above, downward
                m.x += dir * (0.14f - 0.28f * f); m.y += 0.14f - 0.34f * f; m.z += -0.14f * e;
                m.pitch += 55f * e; m.roll += dir * (30f - 60f * f);
            }
            default -> {
                m.x += dir * (0.32f - 0.64f * f) * heavy; m.y += -0.10f * e; m.z += -0.14f * e * heavy;
                m.yaw += dir * (-38f + 76f * f) * heavy; m.roll += dir * (28f - 56f * f); m.pitch += -22f * e;
            }
        }
    }

    /** right click: wind up, thrust, recover */
    private static void stab(float p, Move m) {
        float z;
        if (p < 0.3f) z = 0.12f * smooth(p / 0.3f);
        else if (p < 0.5f) z = lerp(0.12f, -0.55f, smooth((p - 0.3f) / 0.2f));
        else z = lerp(-0.55f, 0f, smooth((p - 0.5f) / 0.5f));
        m.z += z; m.y += -0.03f * (float) Math.sin(Math.PI * p); m.pitch += -6f * (float) Math.sin(Math.PI * p);
    }

    // ------------------------------------------------------------------ model-space animation (pixels / degrees)
    private static final class Anim {
        float x, y, z, rx, ry, rz;
        float py, pz;                       // pivot of the local rotation, relative to the grip centre
        Function<String, float[]> pose;
    }

    private static Function<String, float[]> handles(float a, float b) {
        return name -> switch (name) {
            case "handle_a" -> new float[]{a, 0f, 0f};
            case "handle_b" -> new float[]{b, 0f, 0f};
            default -> null;
        };
    }

    /** taking the knife out: each type has its own little flourish */
    private static void drawFlourish(KnifeData.Knife k, float t, Anim a) {
        if (t < 0f || t > DRAW_SECONDS + 0.4f) return;
        float p = clamp01(t / DRAW_SECONDS);
        switch (k.id()) {
            case "butterfly" -> {                 // comes out closed, handles flick open
                float hb = 180f - 180f * easeOutBack((t - 0.30f) / 0.20f);
                float ha = -180f + 180f * easeOutBack((t - 0.42f) / 0.20f);
                a.pose = handles(ha, hb);
                a.rx += 40f * (1f - smooth(p));
            }
            case "karambit" -> { a.py = -5.4f; a.rx += 360f * (1f - smooth(p / 0.9f)); }
            case "flip" -> a.rz += -160f * (1f - easeOutBack(p));
            case "falchion" -> a.rz += 160f * (1f - easeOutBack(p));
            case "shadow" -> a.rx += 90f * (1f - smooth(p));
            default -> { a.rx += 70f * (1f - smooth(p)); a.ry += -30f * (1f - smooth(p)); }
        }
    }

    /** inspect: follows how these knives are really handled (balisong open/close/rollover/fan, karambit ring spin ...) */
    private static void inspect(KnifeData.Knife k, float t, Anim a) {
        if (t < 0f || t > k.inspectSeconds()) return;
        float p = t / k.inspectSeconds();
        float lift = (float) Math.sin(Math.PI * p);
        switch (k.id()) {
            case "bayonet", "m9" -> {
                a.rx += 360f * smooth((p - 0.1f) / 0.45f); a.ry += 180f * smooth((p - 0.55f) / 0.35f); a.y += 4f * lift;
            }
            case "flip" -> {
                a.rz += 180f * easeOutBack((p - 0.1f) / 0.25f); a.ry += 360f * smooth((p - 0.45f) / 0.45f); a.y += 3f * lift;
            }
            case "gut" -> {
                float up = (float) Math.sin(Math.PI * smooth(p / 0.8f));
                a.y += 12f * up; a.rx += 720f * smooth(p / 0.8f); a.ry += 25f * (float) Math.sin(2 * Math.PI * p);
            }
            case "karambit" -> {
                a.py = -5.4f;
                a.rx += 720f * smooth((p - 0.08f) / 0.55f); a.ry += 180f * smooth((p - 0.65f) / 0.25f); a.y += 3f * lift;
            }
            case "huntsman" -> {
                a.ry += 720f * smooth((p - 0.05f) / 0.7f); a.rz += 25f * (float) Math.sin(2 * Math.PI * p); a.y += 3f * lift;
            }
            case "butterfly" -> {
                float hb = 180f * smooth((p - 0.08f) / 0.22f) - 180f * easeOutBack((p - 0.68f) / 0.12f);
                float ha = -180f * smooth((p - 0.20f) / 0.18f) + 180f * easeOutBack((p - 0.62f) / 0.10f);
                float fan = p > 0.82f ? (float) Math.sin((p - 0.82f) * 55f) * 28f * (1f - (p - 0.82f) / 0.18f) : 0f;
                a.rx += 360f * smooth((p - 0.38f) / 0.24f); a.ry += 20f * (float) Math.sin(2 * Math.PI * p); a.y += 2f * lift;
                a.pose = handles(ha + fan, hb - fan);
            }
            case "falchion" -> {
                a.rz += -200f * easeOutBack((p - 0.08f) / 0.25f); a.rx += 360f * smooth((p - 0.4f) / 0.4f); a.y += 3f * lift;
            }
            case "shadow" -> {
                float th = (float) Math.abs(Math.sin(Math.PI * 2f * clamp01(p / 0.5f)));
                a.z += -6f * th * (p < 0.5f ? 1f : 0f); a.rx += 360f * smooth((p - 0.55f) / 0.35f);
                a.ry += 12f * (float) Math.sin(4 * Math.PI * p);
            }
            case "bowie" -> {
                a.rx += -50f * (float) Math.sin(Math.PI * clamp01(p / 0.4f)); a.ry += 360f * smooth((p - 0.35f) / 0.5f); a.y += 3f * lift;
            }
            default -> {}
        }
    }

    // ------------------------------------------------------------------ drawing
    /**
     * @param swing  vanilla attack progress of the main hand (0 = not attacking)
     * @param role   0 = the knife in the main hand, 1 = the second push dagger
     * @param equip  vanilla equip progress (1 = just switched, 0 = fully raised)
     * @return true if a knife was drawn (so the vanilla item must not be drawn)
     */
    public static boolean draw(MatrixStack ms, VertexConsumerProvider vcp, int light, boolean mirror, float swing, int role, float equip) {
        KnifeState st = KnifeState.get();
        KnifeData.Knife k = st.knife();
        if (k == null) return false;
        BBModel m = model(k, st.skin(k.id()));
        if (m == null) return false;

        long now = System.currentTimeMillis();
        float sgn = mirror ? -1f : 1f;

        // ---- view-space motion: attack / stab / equip
        Move mv = new Move();
        int parity = st.swingId & 1;
        float p = k.dual() ? (role == 0 ? (parity == 0 ? swing : 0f) : (parity == 1 ? swing : 0f)) : swing;
        if (p > 0f) slash(k, p, k.dual() ? 1 : (parity == 0 ? 1 : -1), mv);
        float sp = (now - st.stabStart) / 1000f / STAB_SECONDS;
        if (sp >= 0f && sp <= 1f) stab(sp, mv);
        mv.yaw += -25f * equip; mv.roll += 40f * equip; mv.pitch += 20f * equip;

        ms.push();
        ms.translate(sgn * mv.x, mv.y, mv.z);
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sgn * mv.yaw));
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(mv.pitch));
        ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sgn * mv.roll));

        // ---- model-space motion: idle, draw flourish, inspect
        float idleT = (now % 3_600_000L) / 1000f;
        Anim a = new Anim();
        a.rx = 1.6f * (float) Math.sin(idleT * 0.9f);
        a.ry = 1.2f * (float) Math.sin(idleT * 1.1f);
        a.y = 0.12f * (float) Math.sin(idleT * 1.3f);
        drawFlourish(k, (now - st.drawStart) / 1000f, a);
        inspect(k, (now - st.inspectStart) / 1000f, a);

        float[] t = st.transform(k);
        Matrix4f chain = new Matrix4f();
        if (mirror) chain.scale(-1f, 1f, 1f);
        chain.translate(t[1], t[2], t[3])
                .rotateY((float) Math.toRadians(t[5]))
                .rotateX((float) Math.toRadians(t[4]))
                .rotateY((float) Math.toRadians(t[6]))
                .scale(t[0] / 16f)
                .translate(a.x, a.y, a.z)
                .translate(0f, a.py, a.pz)
                .rotateX((float) Math.toRadians(a.rx))
                .rotateY((float) Math.toRadians(a.ry))
                .rotateZ((float) Math.toRadians(a.rz))
                .translate(0f, -a.py, -a.pz)
                .translate(0f, k.grip(), 0f);
        m.render(ms, vcp, light, OverlayTexture.DEFAULT_UV, chain, a.pose);
        ms.pop();
        return true;
    }
}
