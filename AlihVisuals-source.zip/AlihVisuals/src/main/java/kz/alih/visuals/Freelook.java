package kz.alih.visuals;

import net.minecraft.util.math.MathHelper;

public final class Freelook {
    public static boolean active = false;
    public static float yaw, pitch;
    private Freelook() {}

    /** mouse movement while Alt is held: turns the CAMERA only, the body keeps its direction */
    public static void look(double dx, double dy) {
        yaw += (float) dx * 0.15f;
        pitch = MathHelper.clamp(pitch + (float) dy * 0.15f, -90f, 90f);
    }
}
