package kz.alih.visuals.replacer;

import kz.alih.visuals.AlihMenu;
import kz.alih.visuals.Colors;
import kz.alih.visuals.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.CustomModelDataComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** "Қылыштар": choose which weapon model replaces your swords (and which sword types it applies to). */
public class ReplacerScreen extends Screen {
    private static final int CYAN = 0xFF5CE1FF;
    private static final int CW = 56, CH = 56, GAP = 5;
    private static final ItemStack[] SWORD_ICONS = {
            new ItemStack(Items.WOODEN_SWORD), new ItemStack(Items.STONE_SWORD), new ItemStack(Items.IRON_SWORD),
            new ItemStack(Items.GOLDEN_SWORD), new ItemStack(Items.DIAMOND_SWORD), new ItemStack(Items.NETHERITE_SWORD)};

    private final long openedAt = System.currentTimeMillis();
    private float al = 1f;
    private int px, py, pw, ph, gx, gy, gw, gh, cols;
    private float scroll, maxScroll;
    private boolean pressActive, moved;
    private double pressY;
    private int pressIndex = -1;
    private final Map<String, ItemStack> previews = new HashMap<>();

    public ReplacerScreen() { super(Text.literal("Replacer")); }

    @Override protected void init() { layout(); }
    @Override public boolean shouldPause() { return false; }
    @Override public void close() { client.setScreen(new AlihMenu()); }
    @Override public void removed() { ReplacerConfig.get().save(); }

    private void layout() {
        pw = Math.min(width - 8, 520);
        ph = Math.min(height - 8, 330);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        gx = px + 10;
        gy = py + 76;
        gw = pw - 26;
        gh = py + ph - 10 - gy;
        cols = Math.max(1, (gw + GAP) / (CW + GAP));
        int rows = (WeaponModels.ALL.size() + 1 + cols - 1) / cols;
        maxScroll = Math.max(0, rows * (CH + GAP) - GAP - gh);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
    }

    private int A(int c) { return Colors.mulAlpha(c, al); }
    private void rr(DrawContext c, int x, int y, int w, int h, int r, int col) { Gfx.rrect(c, x, y, w, h, r, A(col)); }
    private void circ(DrawContext c, float x, float y, float r, int col) { Gfx.circle(c, x, y, r, A(col)); }
    private void text(DrawContext c, String s, int x, int y, int col) {
        col = A(col);
        if ((col >>> 24) < 8) return;
        c.drawTextWithShadow(textRenderer, s, x, y, col);
    }
    private void ctext(DrawContext c, String s, int cx, int y, int col) {
        col = A(col);
        if ((col >>> 24) < 8) return;
        c.drawCenteredTextWithShadow(textRenderer, s, cx, y, col);
    }
    private boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    private static float clamp01(float v) { return v < 0f ? 0f : Math.min(1f, v); }

    private ItemStack preview(String weapon) {
        return previews.computeIfAbsent(weapon, w -> {
            ItemStack s = new ItemStack(Items.IRON_SWORD);
            s.set(DataComponentTypes.CUSTOM_MODEL_DATA, new CustomModelDataComponent(List.of(), List.of(), List.of(w), List.of()));
            return s;
        });
    }

    /** draws an item scaled; the replacer is switched off meanwhile so previews show the real model */
    private void item(DrawContext c, ItemStack stack, int x, int y, float scale) {
        MatrixStack ms = c.getMatrices();
        ms.push();
        ms.translate(x, y, 0f);
        ms.scale(scale, scale, 1f);
        ReplacerSwap.bypass = true;
        try { c.drawItem(stack, 0, 0); } finally { ReplacerSwap.bypass = false; }
        ms.pop();
    }

    // ------------------------------------------------------------------ render
    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        float v = clamp01((System.currentTimeMillis() - openedAt) / 250f);
        c.fill(0, 0, width, height, Colors.mulAlpha(0xB0090B10, v));
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();
        float f = clamp01((System.currentTimeMillis() - openedAt) / 260f);
        al = 1f - (1f - f) * (1f - f);
        ReplacerConfig cfg = ReplacerConfig.get();

        rr(c, px - 1, py - 1, pw + 2, ph + 2, 11, 0xFF2C313C);
        rr(c, px, py, pw, ph, 10, 0xF01A1D24);
        ctext(c, "Қылыштар", px + pw / 2, py + 10, CYAN);

        boolean bh = in(mx, my, px + 8, py + 6, 62, 16);
        rr(c, px + 8, py + 6, 62, 16, 7, bh ? 0xFF343946 : 0xFF2A2E38);
        ctext(c, "‹ Артқа", px + 8 + 31, py + 10, 0xFFB8BFCC);

        boolean ih = in(mx, my, px + pw - 78, py + 6, 70, 16);
        rr(c, px + pw - 78, py + 6, 70, 16, 7, ih ? 0xFF343946 : (cfg.item.isEmpty() ? 0xFF2A2E38 : 0xFF2F6B82));
        ctext(c, "Предмет ›", px + pw - 78 + 35, py + 10, cfg.item.isEmpty() ? 0xFFB8BFCC : 0xFFFFFFFF);

        // ---- switches
        drawSwitch(c, px + 10, py + 30, cfg.enabled, "Қосулы");
        drawSwitch(c, px + 110, py + 30, cfg.selfOnly, "Тек өзімде көрінеді");

        // ---- which sword types are replaced
        text(c, "Қай қылыштар:", px + 10, py + 55, 0xFF8A90A0);
        int sx = px + 92;
        for (int i = 0; i < SWORD_ICONS.length; i++) {
            String id = WeaponModels.SWORDS.get(i);
            boolean on = cfg.swords.contains(id);
            boolean h = in(mx, my, sx, py + 50, 20, 20);
            rr(c, sx, py + 50, 20, 20, 5, on ? 0xFF4FC3F7 : (h ? 0xFF343946 : 0xFF2A2E38));
            item(c, SWORD_ICONS[i], sx + 2, py + 52, 1f);
            sx += 24;
        }

        // ---- grid
        String hoverName = null;
        c.enableScissor(gx - 2, gy, gx + gw + 2, gy + gh);
        int total = WeaponModels.ALL.size() + 1;
        for (int i = 0; i < total; i++) {
            int x = gx + (i % cols) * (CW + GAP);
            int y = gy - (int) scroll + (i / cols) * (CH + GAP);
            if (y + CH < gy || y > gy + gh) continue;
            boolean none = i == 0;
            String name = none ? "" : WeaponModels.ALL.get(i - 1);
            boolean sel = cfg.weapon.equals(name);
            boolean hov = in(mx, my, x, y, CW, CH) && my >= gy && my < gy + gh;
            if (hov) hoverName = none ? "Қарапайым қылыш" : name;
            rr(c, x, y, CW, CH, 7, sel ? 0xFF4FC3F7 : 0xFF2C313C);
            rr(c, x + 1, y + 1, CW - 2, CH - 2, 6, hov ? 0xFF2D323E : 0xFF23262E);
            if (none) item(c, new ItemStack(Items.IRON_SWORD), x + 12, y + 5, 2f);
            else item(c, preview(name), x + 12, y + 5, 2f);
            String label = none ? "Қарапайым" : name;
            ctext(c, textRenderer.trimToWidth(label, CW - 4), x + CW / 2, y + CH - 12, sel ? CYAN : 0xFFB8BFCC);
        }
        c.disableScissor();

        if (maxScroll > 0) {
            int barH = Math.max(18, (int) (gh * gh / (gh + maxScroll)));
            int barY = gy + (int) ((gh - barH) * (scroll / maxScroll));
            rr(c, px + pw - 8, barY, 3, barH, 1, 0xFF3FA9C9);
        }

        String shown = hoverName != null ? hoverName
                : (!cfg.item.isEmpty() ? "Предмет: " + cfg.item
                : (cfg.weapon.isEmpty() ? "Қарапайым қылыш" : cfg.weapon));
        ctext(c, textRenderer.trimToWidth(shown, pw - 40), px + pw / 2, py + 62 - 0, hoverName != null ? 0xFFE6E9EF : CYAN);
        al = 1f;
    }

    private void drawSwitch(DrawContext c, int x, int y, boolean on, String label) {
        rr(c, x, y, 30, 16, 8, on ? 0xFF4FC3F7 : 0xFF3A3F4B);
        circ(c, on ? x + 22 : x + 8, y + 8, 6f, 0xFFFFFFFF);
        text(c, label, x + 36, y + 4, 0xFFB8BFCC);
    }

    // ------------------------------------------------------------------ input
    private int cardAt(double mx, double my) {
        if (my < gy || my >= gy + gh) return -1;
        int total = WeaponModels.ALL.size() + 1;
        for (int i = 0; i < total; i++) {
            int x = gx + (i % cols) * (CW + GAP);
            int y = gy - (int) scroll + (i / cols) * (CH + GAP);
            if (in(mx, my, x, y, CW, CH)) return i;
        }
        return -1;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        ReplacerConfig cfg = ReplacerConfig.get();
        if (in(mx, my, px + 8, py + 6, 62, 16)) { close(); return true; }
        if (in(mx, my, px + pw - 78, py + 6, 70, 16)) { client.setScreen(new ItemPickerScreen()); return true; }
        if (in(mx, my, px + 10, py + 30, 30, 16)) { cfg.enabled = !cfg.enabled; cfg.save(); return true; }
        if (in(mx, my, px + 110, py + 30, 30, 16)) { cfg.selfOnly = !cfg.selfOnly; cfg.save(); return true; }
        int sx = px + 92;
        for (int i = 0; i < SWORD_ICONS.length; i++) {
            if (in(mx, my, sx, py + 50, 20, 20)) {
                String id = WeaponModels.SWORDS.get(i);
                if (!cfg.swords.remove(id)) cfg.swords.add(id);
                cfg.save();
                return true;
            }
            sx += 24;
        }
        if (my >= gy && my < gy + gh) {
            pressActive = true; moved = false; pressY = my; pressIndex = cardAt(mx, my);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (pressActive) {
            if (Math.abs(my - pressY) > 5) moved = true;
            if (moved) scroll = Math.max(0, Math.min(maxScroll, scroll - (float) dy));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (pressActive && !moved && pressIndex >= 0 && pressIndex == cardAt(mx, my)) {
            ReplacerConfig cfg = ReplacerConfig.get();
            cfg.weapon = pressIndex == 0 ? "" : WeaponModels.ALL.get(pressIndex - 1);
            cfg.item = "";   // a weapon model replaces the item texture choice
            if (pressIndex > 0) cfg.enabled = true;
            cfg.save();
        }
        pressActive = false; pressIndex = -1;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scroll = Math.max(0, Math.min(maxScroll, scroll - (float) vAmount * 28f));
        return true;
    }
}
