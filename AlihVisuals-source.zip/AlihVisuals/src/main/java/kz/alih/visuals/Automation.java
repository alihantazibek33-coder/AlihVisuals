package kz.alih.visuals;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.Set;

/** AutoSprint, AutoTool, AutoEat. */
public final class Automation {
    private Automation() {}

    // ---------------------------------------------------------------- AutoSprint (END tick)
    public static void sprint(MinecraftClient mc) {
        if (!Modules.AUTOSPRINT.enabled) return;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || Freecam.active) return;
        if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.isUsingItem() && !p.horizontalCollision
                && (p.getHungerManager().getFoodLevel() > 6 || p.getAbilities().allowFlying)) {
            p.setSprinting(true);
        }
    }

    // ---------------------------------------------------------------- AutoTool (START tick)
    public static void tool(MinecraftClient mc) {
        if (!Modules.AUTOTOOL.enabled || eating) return;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null || Freecam.active) return;
        if (p.isCreative() || p.isSpectator() || p.isUsingItem()) return;
        if (!mc.options.attackKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;

        BlockState state = mc.world.getBlockState(hit.getBlockPos());
        if (state.isAir() || state.getHardness(mc.world, hit.getBlockPos()) < 0f) return;

        PlayerInventory inv = p.getInventory();
        int bestSlot = inv.selectedSlot;
        float best = speed(inv.getStack(bestSlot), state);
        for (int i = 0; i < 9; i++) {
            float s = speed(inv.getStack(i), state);
            if (s > best + 0.01f) { best = s; bestSlot = i; }
        }
        if (bestSlot != inv.selectedSlot) inv.selectedSlot = bestSlot;
    }

    private static float speed(ItemStack s, BlockState st) {
        return s.isEmpty() ? 1f : s.getMiningSpeedMultiplier(st);
    }

    // ---------------------------------------------------------------- AutoEat (END tick)
    private static boolean eating;
    private static int prevSlot = -1;

    private static final Set<Item> BAD_FOOD = Set.of(Items.ROTTEN_FLESH, Items.SPIDER_EYE, Items.POISONOUS_POTATO,
            Items.PUFFERFISH, Items.CHICKEN, Items.CHORUS_FRUIT, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE,
            Items.SUSPICIOUS_STEW);

    public static void eat(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!Modules.AUTOEAT.enabled || p == null || mc.world == null || mc.currentScreen != null || Freecam.active
                || p.isCreative() || p.isSpectator() || p.isDead() || mc.interactionManager == null) {
            stopEating(mc);
            return;
        }
        HungerManager hm = p.getHungerManager();
        if (!eating) {
            int threshold = Math.round(Modules.AUTOEAT.value) * 2;   // value = drumsticks, food level = 2 per drumstick
            if (hm.getFoodLevel() > threshold) return;
            int slot = findFood(p);
            if (slot < 0) return;
            prevSlot = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = slot;
            eating = true;
            return;   // start using next tick, after the slot change is synced
        }

        ItemStack held = p.getMainHandStack();
        if (!isGoodFood(held) || !hm.isNotFull()) { stopEating(mc); return; }
        if (p.isUsingItem()) {
            mc.options.useKey.setPressed(true);
        } else {
            mc.options.useKey.setPressed(false);
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            if (p.isUsingItem()) mc.options.useKey.setPressed(true);
        }
    }

    private static void stopEating(MinecraftClient mc) {
        if (!eating) return;
        eating = false;
        mc.options.useKey.setPressed(false);
        if (mc.player != null && prevSlot >= 0) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
    }

    private static boolean isGoodFood(ItemStack s) {
        return !s.isEmpty() && s.contains(DataComponentTypes.FOOD) && !BAD_FOOD.contains(s.getItem());
    }

    private static int findFood(ClientPlayerEntity p) {
        int best = -1, bestN = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!isGoodFood(s)) continue;
            FoodComponent f = s.get(DataComponentTypes.FOOD);
            int n = f == null ? 0 : f.nutrition();
            if (n > bestN) { bestN = n; best = i; }
        }
        return best;
    }
}
