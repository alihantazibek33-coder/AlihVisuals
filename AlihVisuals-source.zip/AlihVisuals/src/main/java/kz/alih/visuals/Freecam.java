package kz.alih.visuals;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/** Detached camera: the body stays where it is, the camera flies around. */
public final class Freecam {
    private Freecam() {}

    public static boolean active;
    public static double x, y, z, px, py, pz;   // current / previous tick position
    public static float yaw, pitch;
    private static Perspective prevPerspective = Perspective.FIRST_PERSON;

    /** Called at the START of every client tick (before the player reads its input). */
    public static void tick(MinecraftClient mc) {
        boolean inWorld = mc.player != null && mc.world != null;
        if (!inWorld) {
            if (active) active = false;
            Modules.FREECAM.enabled = false;
            return;
        }
        boolean want = Modules.FREECAM.enabled;
        if (want && !active) {
            Vec3d cam = mc.gameRenderer.getCamera().getPos();
            x = px = cam.x; y = py = cam.y; z = pz = cam.z;
            yaw = mc.player.getYaw();
            pitch = mc.player.getPitch();
            prevPerspective = mc.options.getPerspective();
            if (prevPerspective.isFirstPerson()) mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            active = true;
        } else if (!want && active) {
            active = false;
            mc.options.setPerspective(prevPerspective);
            KeyBinding.updatePressedStates();
            return;
        }
        if (!active) return;

        px = x; py = y; pz = z;
        GameOptions o = mc.options;
        double fwd = 0, side = 0, up = 0;
        boolean fast = false;
        if (mc.currentScreen == null) {
            long w = mc.getWindow().getHandle();
            fwd = axis(w, o.forwardKey, o.backKey);
            side = axis(w, o.rightKey, o.leftKey);
            up = axis(w, o.jumpKey, o.sneakKey);
            fast = down(w, o.sprintKey);
        }

        // the body must not move / interact while the camera flies
        for (KeyBinding kb : new KeyBinding[]{o.forwardKey, o.backKey, o.leftKey, o.rightKey, o.jumpKey, o.sneakKey,
                o.sprintKey, o.attackKey, o.useKey, o.pickItemKey}) {
            kb.setPressed(false);
        }
        while (o.attackKey.wasPressed()) { }
        while (o.useKey.wasPressed()) { }
        while (o.pickItemKey.wasPressed()) { }

        double speed = 0.55 * Modules.FREECAM.value * (fast ? 2.5 : 1.0);
        Vec3d look = Vec3d.fromPolar(pitch, yaw);
        Vec3d right = Vec3d.fromPolar(0f, yaw + 90f);
        x += (look.x * fwd + right.x * side) * speed;
        y += (look.y * fwd + up) * speed;
        z += (look.z * fwd + right.z * side) * speed;
    }

    private static double axis(long win, KeyBinding pos, KeyBinding neg) {
        return (down(win, pos) ? 1 : 0) - (down(win, neg) ? 1 : 0);
    }

    private static boolean down(long win, KeyBinding kb) {
        if (kb.isUnbound()) return false;
        InputUtil.Key k = KeyBindingHelper.getBoundKeyOf(kb);
        if (k.getCategory() == InputUtil.Type.MOUSE) return GLFW.glfwGetMouseButton(win, k.getCode()) == GLFW.GLFW_PRESS;
        return InputUtil.isKeyPressed(win, k.getCode());
    }
}
