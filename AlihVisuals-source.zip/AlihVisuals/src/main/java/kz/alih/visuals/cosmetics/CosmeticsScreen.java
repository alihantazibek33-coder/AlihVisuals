package kz.alih.visuals.cosmetics;

import kz.alih.visuals.AlihMenu;
import kz.alih.visuals.Colors;
import kz.alih.visuals.Gfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Cosmetics picker: tabs + cards on the right, live preview of your character (drag to rotate) on the left. */
public class CosmeticsScreen extends Screen {
    private static final int CYAN = 0xFF5CE1FF, CARD_H = 40, GAP = 6;
    private static final String[] TABS = {"Барлығы", "Плащ", "Қалпақ", "Қанат", "Жануар"};

    private final long openedAt = System.currentTimeMillis();
    private long last = System.nanoTime();
    private float kk = 0.2f, al = 1f;

    private int px, py, pw, ph, prevW, gx, gw, gTop, gBottom, cols, cardW, setY;
    private int tab;
    private float scroll, maxScroll;
    private float yaw = 30f;
    private List<CosmeticsState.Entry> shown = new ArrayList<>();
    private final Map<String, float[]> anim = new HashMap<>();   // id -> {hover, selected}

    private boolean pressActive, moved, dragPreview;
    private int pressIndex = -1, dragSlider = -1;
    private double pressY;

    public CosmeticsScreen() { super(Text.literal("Cosmetics")); }

    @Override
    protected void init() {
        CosmeticsState.get().refresh();
        layout();
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void close() { client.setScreen(new AlihMenu()); }

    @Override
    public void removed() { CosmeticsState.get().save(); }

    // ------------------------------------------------------------------ helpers
    private int A(int color) { return Colors.mulAlpha(color, al); }
    private void rr(DrawContext c, int x, int y, int w, int h, int r, int color) { Gfx.rrect(c, x, y, w, h, r, A(color)); }
    private void circ(DrawContext c, float x, float y, float r, int color) { Gfx.circle(c, x, y, r, A(color)); }

    private void text(DrawContext c, String s, int x, int y, int color) {
        color = A(color);
        if ((color >>> 24) < 8) return;
        c.drawTextWithShadow(textRenderer, s, x, y, color);
    }

    private void ctext(DrawContext c, String s, int cx, int y, int color) {
        color = A(color);
        if ((color >>> 24) < 8) return;
        c.drawCenteredTextWithShadow(textRenderer, s, cx, y, color);
    }

    private static float clamp01(float v) { return v < 0f ? 0f : Math.min(1f, v); }

    private void layout() {
        pw = Math.min(width - 8, 500);
        ph = Math.min(height - 8, 320);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        prevW = (int) (pw * 0.30f);
        gx = px + prevW + 16;
        gw = pw - prevW - 16 - 12;
        gTop = py + 54;
        int settingsH = 58;
        gBottom = py + ph - settingsH - 8;
        setY = gBottom + 8;
        cols = Math.max(1, (gw + GAP) / (104 + GAP));
        cardW = (gw - (cols - 1) * GAP) / cols;
        rebuildList();
        int rows = (shown.size() + cols - 1) / cols;
        int content = rows * (CARD_H + GAP) - GAP;
        maxScroll = Math.max(0, content - (gBottom - gTop));
        scroll = Math.max(0, Math.min(maxScroll, scroll));
    }

    private void rebuildList() {
        shown = new ArrayList<>();
        for (CosmeticsState.Entry e : CosmeticsState.get().catalog()) {
            if (tab == 0 || e.type().ordinal() + 1 == tab) shown.add(e);
        }
    }

    private int typeColor(CosmeticType t) {
        return switch (t) {
            case CAPE -> 0xFFFF7C9A;
            case HAT -> 0xFFB07CFF;
            case WING -> 0xFF7CD6FF;
            case PET -> 0xFFFFB86B;
        };
    }

    // ------------------------------------------------------------------ rendering
    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        float v = clamp01((System.currentTimeMillis() - openedAt) / 250f);
        c.fill(0, 0, width, height, Colors.mulAlpha(0xB0090B10, v));
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        kk = 1f - (float) Math.exp(-dt * 14f);

        float fade = clamp01((System.currentTimeMillis() - openedAt) / 260f);
        float panelA = 1f - (1f - fade) * (1f - fade);
        al = panelA;

        CosmeticsState cs = CosmeticsState.get();

        rr(c, px - 1, py - 1, pw + 2, ph + 2, 11, 0xFF2C313C);
        rr(c, px, py, pw, ph, 10, 0xF01A1D24);
        ctext(c, "Косметика", px + pw / 2, py + 10, CYAN);

        // back button
        boolean backHover = in(mx, my, px + 8, py + 6, 62, 16);
        rr(c, px + 8, py + 6, 62, 16, 7, backHover ? 0xFF343946 : 0xFF2A2E38);
        ctext(c, "‹ Артқа", px + 8 + 31, py + 10, 0xFFB8BFCC);

        // tabs
        int tx = gx;
        for (int i = 0; i < TABS.length; i++) {
            int w = textRenderer.getWidth(TABS[i]) + 14;
            boolean sel = tab == i, hov = in(mx, my, tx, py + 28, w, 16);
            rr(c, tx, py + 28, w, 16, 7, sel ? 0xFF4FC3F7 : (hov ? 0xFF343946 : 0xFF2A2E38));
            ctext(c, TABS[i], tx + w / 2, py + 32, sel ? 0xFF0E1218 : 0xFFB8BFCC);
            tx += w + 4;
        }

        // ---- cards
        if (shown.isEmpty()) {
            ctext(c, "Бос. config/alihvisuals/cosmetics ішіне файл салыңыз", gx + gw / 2, gTop + 24, 0xFF7C8494);
        }
        c.enableScissor(gx - 2, gTop, gx + gw + 2, gBottom);
        for (int i = 0; i < shown.size(); i++) {
            int x = gx + (i % cols) * (cardW + GAP);
            int y = gTop - (int) scroll + (i / cols) * (CARD_H + GAP);
            if (y + CARD_H < gTop || y > gBottom) continue;
            CosmeticsState.Entry e = shown.get(i);
            boolean hov = in(mx, my, x, y, cardW, CARD_H) && my >= gTop && my < gBottom;
            drawCard(c, e, x, y, hov, cs.isSelected(e));
        }
        c.disableScissor();

        if (maxScroll > 0) {
            int trackH = gBottom - gTop;
            int barH = Math.max(18, (int) (trackH * trackH / (trackH + maxScroll)));
            int barY = gTop + (int) ((trackH - barH) * (scroll / maxScroll));
            rr(c, gx + gw + 4, barY, 3, barH, 1, 0xFF3FA9C9);
        }

        // ---- settings strip
        drawSwitch(c, gx, setY, cs.hideElytra, "Қанат кигенде элитраны жасыру");
        int sw = (gw - 14) / 2;
        drawSlider(c, gx, setY + 34, sw, cs.wingMotion / 2f, "Қанат қозғалысы  " + String.format("%.1f", cs.wingMotion));
        drawSlider(c, gx + sw + 14, setY + 34, sw, cs.petFollow, "Жануар қозғалысы  " + String.format("%.1f", cs.petFollow));

        // ---- preview
        int pvx = px + 10, pvy = py + 28, pvw = prevW, pvh = ph - 28 - 52;
        rr(c, pvx, pvy, pvw, pvh, 8, 0xFF14161B);
        drawPlayer(c, pvx + 1, pvy + 1, pvx + pvw - 1, pvy + pvh - 1);
        boolean flipHover = in(mx, my, pvx, pvy + pvh + 6, pvw, 16);
        rr(c, pvx, pvy + pvh + 6, pvw, 16, 7, flipHover ? 0xFF343946 : 0xFF2A2E38);
        ctext(c, "Бұру (алды/арты)", pvx + pvw / 2, pvy + pvh + 10, 0xFFB8BFCC);
        boolean clearHover = in(mx, my, pvx, pvy + pvh + 26, pvw, 16);
        rr(c, pvx, pvy + pvh + 26, pvw, 16, 7, clearHover ? 0xFF4A2A38 : 0xFF3A2430);
        ctext(c, "Барлығын алып тастау", pvx + pvw / 2, pvy + pvh + 30, 0xFFFFB4C0);
        ctext(c, "сүйреп айналдырыңыз", pvx + pvw / 2, pvy + 5, 0xFF5E6575);
        al = 1f;
    }

    private boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    private void drawCard(DrawContext c, CosmeticsState.Entry e, int x, int y, boolean hov, boolean sel) {
        float[] a = anim.computeIfAbsent(e.id(), k -> new float[2]);
        a[0] += ((hov ? 1f : 0f) - a[0]) * kk;
        a[1] += ((sel ? 1f : 0f) - a[1]) * kk;
        int border = Colors.lerp(0xFF2C313C, 0xFF4FC3F7, a[1]);
        int bg = Colors.lerp(0xFF23262E, 0xFF2B303B, a[0]);
        rr(c, x, y, cardW, CARD_H, 7, border);
        rr(c, x + 1, y + 1, cardW - 2, CARD_H - 2, 6, bg);

        int ix = x + 8, iy = y + (CARD_H - 26) / 2;
        if (e.type() == CosmeticType.CAPE) {
            Identifier id = CapeTextures.current(e);
            int[] sz = CapeTextures.size(e);
            if (id != null && sz != null) {
                float k = sz[0] / 64f;
                c.drawTexture(RenderLayer::getGuiTextured, id, ix + 2, iy, Math.round(k), Math.round(k), 16, 26,
                        Math.round(10 * k), Math.round(16 * k), sz[0], sz[1]);
            } else {
                rr(c, ix + 2, iy, 16, 26, 2, 0xFF3A3F4B);
            }
        } else {
            rr(c, ix, iy, 22, 26, 6, Colors.argb(70, typeColor(e.type()) & 0xFFFFFF));
            ctext(c, e.name().substring(0, 1).toUpperCase(), ix + 11, iy + 9, typeColor(e.type()));
        }
        int tx = x + 36;
        text(c, textRenderer.trimToWidth(e.name(), cardW - 44), tx, y + 9, 0xFFE6E9EF);
        text(c, e.type().label, tx, y + 22, Colors.lerp(0xFF7C8494, typeColor(e.type()), 0.6f));
        if (a[1] > 0.02f) circ(c, x + cardW - 10, y + 10, 3.5f * a[1] + 1f, Colors.argb((int) (255 * a[1]), 0x5CE1FF));
    }

    private void drawSwitch(DrawContext c, int x, int y, boolean on, String label) {
        rr(c, x, y, 30, 16, 8, on ? 0xFF4FC3F7 : 0xFF3A3F4B);
        circ(c, on ? x + 22 : x + 8, y + 8, 6f, 0xFFFFFFFF);
        text(c, label, x + 38, y + 4, 0xFFB8BFCC);
    }

    private void drawSlider(DrawContext c, int x, int y, int w, float norm, String label) {
        text(c, label, x, y - 12, 0xFFA0A7B6);
        norm = clamp01(norm);
        rr(c, x, y, w, 6, 3, 0xFF3A3F4B);
        rr(c, x, y, Math.max(6, (int) (w * norm)), 6, 3, 0xFF4FC3F7);
        circ(c, x + w * norm, y + 3, 5f, 0xFF12141A);
        circ(c, x + w * norm, y + 3, 4f, 0xFFFFFFFF);
    }

    /** renders the real player entity (so cape / hat / wings / pet come out exactly as in the world) */
    private void drawPlayer(DrawContext c, int x1, int y1, int x2, int y2) {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null) return;
        float bodyYaw = p.bodyYaw, prevBody = p.prevBodyYaw, head = p.headYaw, prevHead = p.prevHeadYaw;
        float yawV = p.getYaw(), prevYaw = p.prevYaw, pitch = p.getPitch(), prevPitch = p.prevPitch;
        float a = 180f + yaw;
        p.bodyYaw = a; p.prevBodyYaw = a; p.headYaw = a; p.prevHeadYaw = a;
        p.setYaw(a); p.prevYaw = a; p.setPitch(0f); p.prevPitch = 0f;

        float scale = p.getScale();
        Vector3f offset = new Vector3f(0f, p.getHeight() / 2f + 0.0625f * scale, 0f);
        float size = (y2 - y1) * 0.40f;
        c.enableScissor(x1, y1, x2, y2);
        InventoryScreen.drawEntity(c, (x1 + x2) / 2f, (y1 + y2) / 2f, size / scale, offset,
                new Quaternionf().rotateZ((float) Math.PI), null, p);
        c.disableScissor();

        p.bodyYaw = bodyYaw; p.prevBodyYaw = prevBody; p.headYaw = head; p.prevHeadYaw = prevHead;
        p.setYaw(yawV); p.prevYaw = prevYaw; p.setPitch(pitch); p.prevPitch = prevPitch;
    }

    // ------------------------------------------------------------------ input
    private int sliderAt(double mx, double my) {
        int sw = (gw - 14) / 2;
        if (my >= setY + 34 - 8 && my <= setY + 34 + 14) {
            if (mx >= gx - 5 && mx <= gx + sw + 5) return 0;
            if (mx >= gx + sw + 9 && mx <= gx + sw + 14 + sw + 5) return 1;
        }
        return -1;
    }

    private void setSlider(int which, double mx) {
        int sw = (gw - 14) / 2;
        CosmeticsState cs = CosmeticsState.get();
        if (which == 0) cs.wingMotion = clamp01((float) ((mx - gx) / sw)) * 2f;
        else cs.petFollow = clamp01((float) ((mx - (gx + sw + 14)) / sw));
    }

    private int cardAt(double mx, double my) {
        if (my < gTop || my >= gBottom) return -1;
        for (int i = 0; i < shown.size(); i++) {
            int x = gx + (i % cols) * (cardW + GAP);
            int y = gTop - (int) scroll + (i / cols) * (CARD_H + GAP);
            if (in(mx, my, x, y, cardW, CARD_H)) return i;
        }
        return -1;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        if (in(mx, my, px + 8, py + 6, 62, 16)) { close(); return true; }

        int tx = gx;
        for (int i = 0; i < TABS.length; i++) {
            int w = textRenderer.getWidth(TABS[i]) + 14;
            if (in(mx, my, tx, py + 28, w, 16)) { tab = i; scroll = 0; return true; }
            tx += w + 4;
        }

        int pvx = px + 10, pvy = py + 28, pvw = prevW, pvh = ph - 28 - 52;
        if (in(mx, my, pvx, pvy, pvw, pvh)) { dragPreview = true; return true; }
        if (in(mx, my, pvx, pvy + pvh + 6, pvw, 16)) { yaw = Math.abs(yaw) < 90f ? 155f : 30f; return true; }
        if (in(mx, my, pvx, pvy + pvh + 26, pvw, 16)) { CosmeticsState.get().clearAll(); return true; }

        if (in(mx, my, gx, setY, 30, 16)) {
            CosmeticsState cs = CosmeticsState.get();
            cs.hideElytra = !cs.hideElytra;
            cs.save();
            return true;
        }
        int s = sliderAt(mx, my);
        if (s >= 0) { dragSlider = s; setSlider(s, mx); return true; }

        if (my >= gTop && my < gBottom) {
            pressActive = true; moved = false; pressY = my; pressIndex = cardAt(mx, my);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragPreview) { yaw += (float) dx * 1.6f; return true; }
        if (dragSlider >= 0) { setSlider(dragSlider, mx); return true; }
        if (pressActive) {
            if (Math.abs(my - pressY) > 5) moved = true;
            if (moved) scroll = Math.max(0, Math.min(maxScroll, scroll - (float) dy));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (pressActive && !moved && pressIndex >= 0 && pressIndex == cardAt(mx, my) && pressIndex < shown.size()) {
            CosmeticsState.get().toggle(shown.get(pressIndex));
        }
        if (dragSlider >= 0) CosmeticsState.get().save();
        pressActive = false; pressIndex = -1; dragPreview = false; dragSlider = -1;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scroll = Math.max(0, Math.min(maxScroll, scroll - (float) vAmount * 24f));
        return true;
    }
}
