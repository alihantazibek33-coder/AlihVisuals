package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class ToggleSprintModule extends ClientModule {
    public ToggleSprintModule() { super("Toggle Sprint", "Lets you toggle sprint instead of holding the key.", ModuleCategory.PLAYER); }
}
