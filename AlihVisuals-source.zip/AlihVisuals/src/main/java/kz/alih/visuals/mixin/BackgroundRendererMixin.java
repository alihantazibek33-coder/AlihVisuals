package kz.alih.visuals.mixin;

import kz.alih.visuals.Modules;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Fog;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BackgroundRenderer.class)
public abstract class BackgroundRendererMixin {
    @Inject(method = "applyFog", at = @At("RETURN"), cancellable = true)
    private static void alih$noFluid(Camera camera, BackgroundRenderer.FogType fogType, Vector4f color,
                                     float viewDistance, boolean thickenFog, float tickDelta,
                                     CallbackInfoReturnable<Fog> cir) {
        if (!Modules.NOFLUID.enabled) return;
        String s = camera.getSubmersionType().name();
        if (s.equals("WATER") || s.equals("LAVA")) {
            Fog f = cir.getReturnValue();
            cir.setReturnValue(new Fog(viewDistance * 4f, viewDistance * 8f, f.shape(),
                    f.red(), f.green(), f.blue(), f.alpha()));
        }
    }
}
