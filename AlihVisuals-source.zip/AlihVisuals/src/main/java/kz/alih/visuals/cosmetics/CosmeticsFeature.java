package kz.alih.visuals.cosmetics;

import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

import java.util.UUID;
import java.util.function.Function;

/** Draws hat / wings / pet on a player. (The cape is swapped in by PlayerEntityRendererCosmeticsMixin.) */
public class CosmeticsFeature extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {

    public static void register() {
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, entityRenderer, helper, context) -> {
            if (entityRenderer instanceof PlayerEntityRenderer renderer) {
                helper.register(new CosmeticsFeature(renderer));
            }
        });
    }

    public CosmeticsFeature(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack ms, VertexConsumerProvider vcp, int light, PlayerEntityRenderState state,
                       float limbAngle, float limbDistance) {
        if (state.invisible) return;
        UUID id = CosmeticsState.boundUuid(state);
        if (id == null) return;

        CosmeticsState cs = CosmeticsState.get();
        PlayerEntityModel model = getContextModel();
        int overlay = OverlayTexture.DEFAULT_UV;
        float time = (System.currentTimeMillis() % 3_600_000L) / 1000f;

        // ---- hat: glued to the head
        CosmeticsState.Entry hat = cs.selectedFor(id, CosmeticType.HAT);
        if (hat != null) {
            BBModel m = BBModel.get(hat);
            if (m != null) {
                ms.push();
                model.head.rotate(ms);
                m.render(ms, vcp, light, overlay, BBModel.pre(), null);
                ms.pop();
            }
        }

        // ---- wings: glued to the body, flapping
        CosmeticsState.Entry wing = cs.selectedFor(id, CosmeticType.WING);
        if (wing != null) {
            BBModel m = BBModel.get(wing);
            if (m != null) {
                float motion = cs.wingMotion;
                float flap = (float) Math.sin(time * 2.6f) * 14f * motion;
                if (limbDistance > 0.1f) flap += (float) Math.sin(time * 6f) * 5f * motion * Math.min(1f, limbDistance);
                final float a = flap;
                // wings that are authored folded (no rotation) get an opening angle, posed ones just oscillate
                float[] lr = m.rot("leftwing");
                final float base = (lr != null && Math.abs(lr[1]) < 1f) ? 28f * motion : 0f;
                Function<String, float[]> pose = name -> switch (name) {
                    case "wings_root" -> new float[]{0f, a, 0f};
                    case "rightwing" -> new float[]{0f, base + a, 0f};
                    case "leftwing" -> new float[]{0f, -(base + a), 0f};
                    default -> null;
                };
                ms.push();
                model.body.rotate(ms);
                m.render(ms, vcp, light, overlay, BBModel.pre(), pose);
                if (m.has("wings_root") && !m.has("leftwing")) {
                    // one authored wing -> mirror it for the other side
                    m.render(ms, vcp, light, overlay, BBModel.pre().scale(-1f, 1f, 1f), pose);
                }
                ms.pop();
            }
        }

        // ---- pet: hovers next to the shoulder
        CosmeticsState.Entry pet = cs.selectedFor(id, CosmeticType.PET);
        if (pet != null) {
            BBModel m = BBModel.get(pet);
            if (m != null) {
                float follow = cs.petFollow;
                float[] b = m.bounds;
                float cx = (b[0] + b[3]) / 2f, cy = (b[1] + b[4]) / 2f, cz = (b[2] + b[5]) / 2f;
                float size = Math.max(0.01f, Math.max(b[3] - b[0], Math.max(b[4] - b[1], b[5] - b[2])));
                float scale = Math.max(0.7f, Math.min(3f, 8f / size));
                float bob = (float) Math.sin(time * 2.1f) * 1.6f * follow;
                float sway = (float) Math.sin(time * 1.3f) * 1.2f * follow + Math.min(1f, limbDistance) * 1.5f * follow;
                Matrix4f chain = BBModel.pre()
                        .translate(-13f + sway, 31f + bob, 3f)
                        .scale(scale)
                        .translate(-cx, -cy, -cz);
                ms.push();
                model.body.rotate(ms);
                m.render(ms, vcp, light, overlay, chain, null);
                ms.pop();
            }
        }
    }
}
