package kz.alih.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

public final class Hud {
    private Hud() {}

    private static LivingEntity target;
    private static long lastSeen, shownSince;
    private static float shownHp;

    public static void setTarget(Entity e) {
        if (e instanceof LivingEntity le && e != MinecraftClient.getInstance().player) {
            if (target != le) { shownHp = le.getHealth(); shownSince = System.currentTimeMillis(); }
            target = le;
            lastSeen = System.currentTimeMillis();
        }
    }

    /** current target (looked at / attacked within the last 2.5 s), or null */
    public static LivingEntity active() {
        if (target == null) return null;
        if (System.currentTimeMillis() - lastSeen > 2500 || target.isRemoved()) return null;
        return target;
    }

    public static void render(DrawContext c, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        if (mc.targetedEntity != null) setTarget(mc.targetedEntity);
        if (Modules.WATERMARK.enabled) watermark(c, mc);
        if (Modules.TARGETHUD.enabled) targetHud(c, mc);
        if (Modules.COORDINATES.enabled && !mc.getDebugHud().shouldShowDebugHud()) coordinates(c, mc);
        DeathMarker.hud(c, mc);
    }

    /** Bedrock style "Position: x, y, z" in the top-left corner */
    private static void coordinates(DrawContext c, MinecraftClient mc) {
        TextRenderer tr = mc.textRenderer;
        String s = "Position: " + mc.player.getBlockX() + ", " + mc.player.getBlockY() + ", " + mc.player.getBlockZ();
        int w = tr.getWidth(s) + 10, h = 15;
        Gfx.rrect(c, 4, 4, w, h, 3, 0x88000000);
        c.drawTextWithShadow(tr, s, 9, 8, 0xFFFFFFFF);
    }

    private static void watermark(DrawContext c, MinecraftClient mc) {
        TextRenderer tr = mc.textRenderer;
        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        String name = "AlihVisuals";
        String rest = "  |  " + ping + " ms  |  " + mc.getCurrentFps() + " FPS";
        int tw = tr.getWidth(name) + tr.getWidth(rest);
        int w = tw + 34, h = 20;
        int x = (c.getScaledWindowWidth() - w) / 2, y = 6;
        Gfx.rrect(c, x, y, w, h, 8, 0xC0101218);
        Gfx.rrect(c, x + 8, y + h - 2, w - 16, 1, 0, 0xFF5CE1FF);
        Gfx.circle(c, x + 13, y + 10, 4f, 0xFF5CE1FF);
        Gfx.circle(c, x + 13, y + 10, 2f, 0xFF101218);
        c.drawTextWithShadow(tr, name, x + 24, y + 6, 0xFF5CE1FF);
        c.drawTextWithShadow(tr, rest, x + 24 + tr.getWidth(name), y + 6, 0xFFB8BFCC);
    }

    private static void targetHud(DrawContext c, MinecraftClient mc) {
        Entity looked = mc.targetedEntity;
        if (looked != null) setTarget(looked);
        long now = System.currentTimeMillis();
        if (target == null) return;
        if (now - lastSeen > 2500 || target.isRemoved()) { target = null; return; }

        // fade in / out
        float in = Math.min(1f, (now - shownSince) / 200f);
        float out = Math.min(1f, (2500 - (now - lastSeen)) / 300f);
        float a = Math.max(0f, Math.min(in, out));

        float hp = target.getHealth();
        shownHp += (hp - shownHp) * 0.12f;
        float maxHp = Math.max(1f, target.getMaxHealth());
        float frac = Math.max(0f, Math.min(1f, shownHp / maxHp));

        TextRenderer tr = mc.textRenderer;
        int w = 170, h = 46;
        int x = (c.getScaledWindowWidth() - w) / 2;
        int y = c.getScaledWindowHeight() - 58 - h;

        Gfx.rrect(c, x, y, w, h, 8, Colors.mulAlpha(0xE0121218, a));
        Gfx.rrect(c, x + 7, y + 7, 28, 28, 5, Colors.mulAlpha(0xFF1B2733, a));
        if (target instanceof AbstractClientPlayerEntity p) {
            PlayerSkinDrawer.draw(c, p.getSkinTextures(), x + 7, y + 7, 28);
        } else {
            c.drawCenteredTextWithShadow(tr, "?", x + 21, y + 17, Colors.mulAlpha(0xFFB8BFCC, a));
        }
        String name = tr.trimToWidth(target.getName().getString(), w - 50);
        c.drawTextWithShadow(tr, name, x + 42, y + 9, Colors.mulAlpha(0xFFFFFFFF, a));
        c.drawTextWithShadow(tr, String.format("HP / %.1f", hp).replace(',', '.'), x + 42, y + 21,
                Colors.mulAlpha(0xFFB8BFCC, a));

        int bx = x + 8, by = y + h - 10, bw = w - 16;
        Gfx.rrect(c, bx, by, bw, 5, 2, Colors.mulAlpha(0xFF1B2733, a));
        int fw = Math.max(4, (int) (bw * frac));
        if (frac > 0.001f) Gfx.rrect(c, bx, by, fw, 5, 2, Colors.mulAlpha(0xFF4FC3F7, a));
    }
}
