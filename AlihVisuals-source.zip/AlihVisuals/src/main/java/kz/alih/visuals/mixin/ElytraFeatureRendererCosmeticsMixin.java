package kz.alih.visuals.mixin;

import kz.alih.visuals.cosmetics.CosmeticType;
import kz.alih.visuals.cosmetics.CosmeticsState;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.ElytraFeatureRenderer;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;

@Mixin(ElytraFeatureRenderer.class)
public abstract class ElytraFeatureRendererCosmeticsMixin {
    @Inject(method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void alih$hideElytra(MatrixStack matrices, VertexConsumerProvider vcp, int light,
                                 BipedEntityRenderState state, float limbAngle, float limbDistance, CallbackInfo ci) {
        CosmeticsState cs = CosmeticsState.get();
        if (!cs.hideElytra) return;
        UUID id = CosmeticsState.boundUuid(state);
        if (id != null && cs.selectedFor(id, CosmeticType.WING) != null) ci.cancel();
    }
}
