package kz.alih.visuals.music;

import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;
import net.fabricmc.loader.api.FabricLoader;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

/**
 * Simple music player. Tracks are the files in  config/alihvisuals/music  (shown by file name without extension).
 * mp3 and wav are played directly; other formats (mp4, m4a, ogg, flac ...) are converted with ffmpeg when it is installed.
 */
public final class MusicPlayer {
    private MusicPlayer() {}

    public static final class Track {
        public final String name;
        public final Path file;
        public volatile long durationMs = -1;
        public volatile boolean failed;
        Track(String name, Path file) { this.name = name; this.file = file; }
    }

    private interface Source { AudioFormat format(); int read(byte[] b) throws Exception; void close(); }

    private static final Set<String> EXT = Set.of("mp3", "wav", "ogg", "m4a", "mp4", "aac", "flac", "wma", "opus", "webm");
    private static final Set<String> NATIVE = Set.of("mp3", "wav");

    private static volatile List<Track> tracks = List.of();
    private static volatile int current = -1;
    private static volatile boolean playing, paused, loop;
    private static volatile float volume = 0.7f;
    private static volatile long posMs;
    private static volatile String status = "";
    private static final AtomicInteger GEN = new AtomicInteger();

    // ------------------------------------------------------------------ public state
    public static List<Track> tracks() { return tracks; }
    public static int current() { return current; }
    public static boolean isPlaying() { return playing; }
    public static boolean isPaused() { return paused; }
    public static boolean isLoop() { return loop; }
    public static float volume() { return volume; }
    public static long positionMs() { return posMs; }
    public static String status() { return status; }
    public static Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("alihvisuals").resolve("music"); }

    public static Track currentTrack() {
        List<Track> l = tracks;
        int c = current;
        return c >= 0 && c < l.size() ? l.get(c) : null;
    }

    // ------------------------------------------------------------------ settings
    private static Path settingsFile() { return FabricLoader.getInstance().getConfigDir().resolve("alihvisuals").resolve("music.properties"); }

    public static void init() {
        try {
            Files.createDirectories(dir());
            Path f = settingsFile();
            if (Files.exists(f)) {
                Properties p = new Properties();
                try (Reader r = Files.newBufferedReader(f)) { p.load(r); }
                volume = Math.max(0f, Math.min(1f, Float.parseFloat(p.getProperty("volume", "0.7"))));
                loop = Boolean.parseBoolean(p.getProperty("loop", "false"));
            }
        } catch (Exception ignored) {}
        refresh();
    }

    private static void saveSettings() {
        try {
            Properties p = new Properties();
            p.setProperty("volume", String.valueOf(volume));
            p.setProperty("loop", String.valueOf(loop));
            Files.createDirectories(settingsFile().getParent());
            try (Writer w = Files.newBufferedWriter(settingsFile())) { p.store(w, "AlihVisuals music"); }
        } catch (Exception ignored) {}
    }

    public static void setVolume(float v) { volume = Math.max(0f, Math.min(1f, v)); saveSettings(); }
    public static void toggleLoop() { loop = !loop; saveSettings(); }

    // ------------------------------------------------------------------ track list
    private static String ext(Path f) {
        String n = f.getFileName().toString();
        int i = n.lastIndexOf('.');
        return i < 0 ? "" : n.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    private static String baseName(Path f) {
        String n = f.getFileName().toString();
        int i = n.lastIndexOf('.');
        return i <= 0 ? n : n.substring(0, i);   // yarayara.mp4 -> yarayara
    }

    public static synchronized void refresh() {
        Path cur = currentTrack() == null ? null : currentTrack().file;
        List<Track> list = new ArrayList<>();
        try {
            Files.createDirectories(dir());
            try (Stream<Path> s = Files.list(dir())) {
                s.filter(Files::isRegularFile).filter(p -> EXT.contains(ext(p))).forEach(p -> list.add(new Track(baseName(p), p)));
            }
        } catch (IOException ignored) {}
        list.sort(Comparator.comparing(t -> t.name.toLowerCase(Locale.ROOT)));
        tracks = List.copyOf(list);
        current = -1;
        if (cur != null) for (int i = 0; i < list.size(); i++) if (list.get(i).file.equals(cur)) current = i;
        if (current < 0 && playing) stop();

        List<Track> snapshot = tracks;
        Thread t = new Thread(() -> { for (Track tr : snapshot) computeDuration(tr); }, "AlihVisuals-music-scan");
        t.setDaemon(true);
        t.start();
    }

    private static void computeDuration(Track t) {
        if (t.durationMs >= 0) return;
        try {
            String e = ext(t.file);
            if (e.equals("wav")) t.durationMs = wavDuration(t.file);
            else if (e.equals("mp3")) t.durationMs = mp3Duration(t.file);
        } catch (Throwable ignored) {}
    }

    private static long wavDuration(Path f) throws Exception {
        try (AudioInputStream in = AudioSystem.getAudioInputStream(f.toFile())) {
            long frames = in.getFrameLength();
            float rate = in.getFormat().getFrameRate();
            return frames > 0 && rate > 0 ? (long) (frames * 1000.0 / rate) : -1;
        }
    }

    private static long mp3Duration(Path f) throws Exception {
        double total = 0;
        try (InputStream is = new BufferedInputStream(Files.newInputStream(f))) {
            Bitstream bs = new Bitstream(is);
            Header h;
            while ((h = bs.readFrame()) != null) { total += h.ms_per_frame(); bs.closeFrame(); }
            bs.close();
        }
        return (long) total;
    }

    // ------------------------------------------------------------------ controls
    public static synchronized void play(int i) {
        List<Track> l = tracks;
        if (i < 0 || i >= l.size()) return;
        int gen = GEN.incrementAndGet();
        current = i;
        paused = false;
        playing = true;
        posMs = 0;
        status = "";
        Track t = l.get(i);
        Thread th = new Thread(() -> run(t, gen, i), "AlihVisuals-music");
        th.setDaemon(true);
        th.start();
    }

    public static synchronized void stop() {
        GEN.incrementAndGet();
        playing = false;
        paused = false;
        posMs = 0;
    }

    public static void togglePause() {
        if (!playing) {
            if (current >= 0) play(current);
            else if (!tracks.isEmpty()) play(0);
        } else {
            paused = !paused;
        }
    }

    public static void next() {
        int n = tracks.size();
        if (n == 0) return;
        play(current < 0 ? 0 : (current + 1) % n);
    }

    public static void prev() {
        int n = tracks.size();
        if (n == 0) return;
        play(current < 0 ? 0 : (current - 1 + n) % n);
    }

    private static synchronized void advance(int gen, int idx) {
        if (GEN.get() != gen) return;
        int n = tracks.size();
        if (n == 0) { stop(); return; }
        if (loop) { play(idx); return; }
        if (n == 1) { stop(); return; }
        play((idx + 1) % n);
    }

    // ------------------------------------------------------------------ playback thread
    private static void run(Track t, int gen, int idx) {
        SourceDataLine line = null;
        Source src = null;
        boolean natural = false;
        try {
            Path f = t.file;
            String e = ext(f);
            if (!NATIVE.contains(e)) {
                f = convert(t);
                if (f == null) { t.failed = true; return; }
                e = "wav";
            }
            src = e.equals("mp3") ? new Mp3Source(f) : new WavSource(f);
            AudioFormat fmt = src.format();
            line = AudioSystem.getSourceDataLine(fmt);
            line.open(fmt);
            line.start();

            byte[] buf = new byte[4096];
            boolean wasPaused = false;
            while (GEN.get() == gen) {
                if (paused) {
                    if (!wasPaused) { line.stop(); wasPaused = true; }
                    posMs = line.getMicrosecondPosition() / 1000;
                    Thread.sleep(40);
                    continue;
                }
                if (wasPaused) { line.start(); wasPaused = false; }
                int n = src.read(buf);
                if (n <= 0) { natural = true; break; }
                scale(buf, n, volume);
                int off = 0;
                while (off < n && GEN.get() == gen && !paused) off += line.write(buf, off, n - off);
                posMs = line.getMicrosecondPosition() / 1000;
            }
            if (natural) {   // wait until the buffered tail has been played
                while (GEN.get() == gen && line.available() < line.getBufferSize()) Thread.sleep(40);
            }
        } catch (Throwable ex) {
            if (GEN.get() == gen) { status = "Қате: " + ex.getClass().getSimpleName(); t.failed = true; natural = false; }
        } finally {
            if (line != null) { try { line.stop(); line.flush(); line.close(); } catch (Throwable ignored) {} }
            if (src != null) src.close();
        }
        if (GEN.get() == gen) {
            if (natural) advance(gen, idx);
            else { playing = false; paused = false; }
        }
    }

    private static void scale(byte[] b, int n, float vol) {
        float g = vol * vol;   // perceptual curve
        for (int i = 0; i + 1 < n; i += 2) {
            short s = (short) ((b[i] & 0xFF) | (b[i + 1] << 8));
            s = (short) (s * g);
            b[i] = (byte) s;
            b[i + 1] = (byte) (s >> 8);
        }
    }

    /** non mp3/wav -> wav through ffmpeg (cached in the music/.cache folder) */
    private static Path convert(Track t) {
        try {
            Path cacheDir = dir().resolve(".cache");
            Files.createDirectories(cacheDir);
            String key = Integer.toHexString((t.file.toString() + Files.size(t.file) + Files.getLastModifiedTime(t.file)).hashCode());
            Path out = cacheDir.resolve(key + ".wav");
            if (Files.exists(out) && Files.size(out) > 44) { t.durationMs = wavDuration(out); return out; }
            status = "Конвертация (ffmpeg)...";
            Process p = new ProcessBuilder("ffmpeg", "-y", "-loglevel", "error", "-i", t.file.toString(), "-vn",
                    "-acodec", "pcm_s16le", "-ar", "44100", "-ac", "2", out.toString()).redirectErrorStream(true).start();
            p.getInputStream().readAllBytes();
            if (p.waitFor() != 0 || !Files.exists(out)) {
                Files.deleteIfExists(out);
                status = "ffmpeg қатесі: файл оқылмады";
                return null;
            }
            t.durationMs = wavDuration(out);
            status = "";
            return out;
        } catch (IOException e) {
            status = "Бұл формат үшін ffmpeg керек. mp3 немесе wav қолданыңыз";
            return null;
        } catch (Exception e) {
            status = "Қате: " + e.getClass().getSimpleName();
            return null;
        }
    }

    // ------------------------------------------------------------------ decoders
    private static final class WavSource implements Source {
        private AudioInputStream in;
        private final AudioFormat fmt;
        WavSource(Path f) throws Exception {
            AudioInputStream a = AudioSystem.getAudioInputStream(f.toFile());
            AudioFormat base = a.getFormat();
            if (base.getEncoding() != AudioFormat.Encoding.PCM_SIGNED || base.getSampleSizeInBits() != 16 || base.isBigEndian()) {
                AudioFormat target = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, base.getSampleRate(), 16,
                        base.getChannels(), base.getChannels() * 2, base.getSampleRate(), false);
                a = AudioSystem.getAudioInputStream(target, a);
            }
            in = a;
            fmt = a.getFormat();
        }
        public AudioFormat format() { return fmt; }
        public int read(byte[] b) throws Exception { return in.read(b, 0, b.length); }
        public void close() { try { in.close(); } catch (IOException ignored) {} }
    }

    private static final class Mp3Source implements Source {
        private final InputStream is;
        private final Bitstream bs;
        private final Decoder dec = new Decoder();
        private final AudioFormat fmt;
        private byte[] pending;
        private int pos;

        Mp3Source(Path f) throws Exception {
            is = new BufferedInputStream(Files.newInputStream(f));
            bs = new Bitstream(is);
            Header h = bs.readFrame();
            if (h == null) throw new IOException("empty mp3");
            SampleBuffer out = (SampleBuffer) dec.decodeFrame(h, bs);
            fmt = new AudioFormat(dec.getOutputFrequency(), 16, dec.getOutputChannels(), true, false);
            pending = bytes(out);
            bs.closeFrame();
        }

        private static byte[] bytes(SampleBuffer o) {
            short[] s = o.getBuffer();
            int len = o.getBufferLength();
            byte[] r = new byte[len * 2];
            for (int i = 0; i < len; i++) { r[2 * i] = (byte) s[i]; r[2 * i + 1] = (byte) (s[i] >> 8); }
            return r;
        }

        public AudioFormat format() { return fmt; }

        public int read(byte[] b) throws Exception {
            int total = 0;
            while (total < b.length) {
                if (pos >= pending.length) {
                    Header h = bs.readFrame();
                    if (h == null) break;
                    pending = bytes((SampleBuffer) dec.decodeFrame(h, bs));
                    pos = 0;
                    bs.closeFrame();
                }
                int n = Math.min(pending.length - pos, b.length - total);
                System.arraycopy(pending, pos, b, total, n);
                pos += n;
                total += n;
            }
            return total == 0 ? -1 : total;
        }

        public void close() { try { bs.close(); is.close(); } catch (Exception ignored) {} }
    }
}
