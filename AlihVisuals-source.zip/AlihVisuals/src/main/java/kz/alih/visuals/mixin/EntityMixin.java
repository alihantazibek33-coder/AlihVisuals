package kz.alih.visuals.mixin;

import kz.alih.visuals.Freecam;
import kz.alih.visuals.Freelook;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void alih$look(double dx, double dy, CallbackInfo ci) {
        if (Freecam.active && (Object) this == MinecraftClient.getInstance().player) {
            Freecam.yaw += (float) dx * 0.15f;
            Freecam.pitch = MathHelper.clamp(Freecam.pitch + (float) dy * 0.15f, -90f, 90f);
            ci.cancel();
            return;
        }
        if (Freelook.active && (Object) this == MinecraftClient.getInstance().player) {
            Freelook.look(dx, dy);
            ci.cancel();
        }
    }
}
