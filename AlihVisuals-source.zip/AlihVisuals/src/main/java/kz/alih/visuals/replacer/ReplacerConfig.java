package kz.alih.visuals.replacer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

/** Which weapon model replaces your swords. Saved in config/alihvisuals/itemreplacer.json */
public final class ReplacerConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static ReplacerConfig instance;

    public boolean enabled = true;
    public boolean selfOnly = true;                         // true = only you see the replacement
    public String weapon = "";                              // "" = normal swords
    public Set<String> swords = new HashSet<>(WeaponModels.SWORDS);

    public static ReplacerConfig get() {
        if (instance == null) instance = load();
        return instance;
    }

    public boolean replaces(String itemId) { return swords.contains(itemId); }

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("alihvisuals").resolve("itemreplacer.json"); }

    private static ReplacerConfig load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                ReplacerConfig c = GSON.fromJson(Files.readString(f), ReplacerConfig.class);
                if (c != null) {
                    if (c.weapon == null || !WeaponModels.ALL.contains(c.weapon)) c.weapon = "";
                    if (c.swords == null) c.swords = new HashSet<>(WeaponModels.SWORDS);
                    c.swords.retainAll(WeaponModels.SWORDS);
                    return c;
                }
            }
        } catch (Exception ignored) {}
        return new ReplacerConfig();
    }

    public void save() {
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            Files.writeString(f, GSON.toJson(this));
        } catch (Exception ignored) {}
    }
}
