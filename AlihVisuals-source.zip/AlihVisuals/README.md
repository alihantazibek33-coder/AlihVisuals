# AlihVisuals (Fabric 1.21.4)
Меню: **0** пернесі. Freelook: **Left Alt** ұстап тұр (модуль қосулы болса).
Build: `gradle build` (Java 21) -> build/libs/alihvisuals-1.0.0.jar
Немесе GitHub-қа жүктеп, Actions -> build -> Artifacts.
