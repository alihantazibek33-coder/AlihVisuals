import json, base64, uuid, os, sys, math, glob
SRC = '/home/claude/cs2/assets/cs2_wt'
# helper bones that only exist for TACZ (arms, camera, positioning nodes)
SKIP = {'righthand','righthand_pos','lefthand','lefthand_pos','constraint','camera','view','refit_view','iron_view',
        'idle_view','positioning','ground','thirdperson_hand','fixed','bone38','bone39'}
SWAP_EW = False   # swap east/west face uv (tested visually)

def uid(): return str(uuid.uuid4())

def face_uv(c, tw, th):
    """per-face uv dict -> {name:[u1,v1,u2,v2]} in geo texture units"""
    out = {}
    uv = c['uv']
    for k in ('north','east','south','west','up','down'):
        f = uv.get(k)
        if not f: continue
        u, v = f['uv']; w, h = f['uv_size']
        out[k] = [u, v, u + w, v + h]
    return out

def convert(name, swap_ew=SWAP_EW):
    geo = json.load(open(f'{SRC}/geo_models/melee/{name}_geo.json'))['minecraft:geometry'][0]
    anim = json.load(open(f'{SRC}/animations/melee/{name}.animation.json'))['animations']
    tw, th = geo['description']['texture_width'], geo['description']['texture_height']
    png = open(f'{SRC}/textures/melee/{name}_uv.png','rb').read()
    bones = {b['name']: b for b in geo['bones']}
    kids = {}
    for b in geo['bones']:
        kids.setdefault(b.get('parent'), []).append(b['name'])
    elements = []; outliner = []; guids = {}
    def build(bn):
        b = bones[bn]
        g = {'name': bn, 'uuid': uid(), 'origin': [-b['pivot'][0], b['pivot'][1], b['pivot'][2]],
             'rotation': [-b.get('rotation',[0,0,0])[0], -b.get('rotation',[0,0,0])[1], b.get('rotation',[0,0,0])[2]],
             'children': []}
        guids[bn] = g['uuid']
        for c in b.get('cubes', []):
            infl = c.get('inflate', 0)
            o, s = c['origin'], c['size']
            fr = [-(o[0]+s[0]) - infl, o[1] - infl, o[2] - infl]
            to = [-o[0] + infl, o[1] + s[1] + infl, o[2] + s[2] + infl]
            pv = c.get('pivot', [(o[0]+s[0]/2),(o[1]+s[1]/2),(o[2]+s[2]/2)])
            rot = c.get('rotation', [0,0,0])
            fu = face_uv(c, tw, th)
            faces = {}
            for k, uvr in fu.items():
                kk = {'east':'west','west':'east'}.get(k,k) if swap_ew else k
                faces[kk] = {'uv': uvr, 'texture': 0}
            e = {'name': f'{bn}_{len(elements)}', 'type': 'cube', 'uuid': uid(), 'from': fr, 'to': to,
                 'origin': [-pv[0], pv[1], pv[2]], 'rotation': [-rot[0], -rot[1], rot[2]], 'faces': faces}
            elements.append(e); g['children'].append(e['uuid'])
        for k in kids.get(bn, []):
            if k in SKIP: continue
            g['children'].append(build(k))
        return g
    for r in kids.get(None, []):
        if r in SKIP: continue
        outliner.append(build(r))
    animations = []
    for an, a in anim.items():
        L = float(a.get('animation_length', 0))
        animators = {}
        for bn, bd in a.get('bones', {}).items():
            if bn not in guids: continue
            kfs = []
            for ch in ('rotation','position'):
                val = bd.get(ch)
                if isinstance(val, dict):
                    for t, x in val.items():
                        if isinstance(x, dict): x = x.get('post', x.get('pre'))
                        try: vec = [float(i) for i in x]
                        except Exception: continue
                        kfs.append({'channel': ch, 'time': float(t), 'data_points': [{'x': vec[0], 'y': vec[1], 'z': vec[2]}]})
                elif isinstance(val, list):
                    try: vec = [float(i) for i in val]
                    except Exception: continue
                    kfs.append({'channel': ch, 'time': 0.0, 'data_points': [{'x': vec[0], 'y': vec[1], 'z': vec[2]}]})
            if kfs: animators[guids[bn]] = {'name': bn, 'type': 'bone', 'keyframes': kfs}
        animations.append({'name': an, 'length': L, 'loop': 'loop' if a.get('loop') is True else 'once', 'linear': True, 'animators': animators})
    return {'meta': {'format_version': '4.10', 'model_format': 'free'}, 'name': name,
            'resolution': {'width': tw, 'height': th},
            'elements': elements, 'outliner': outliner,
            'textures': [{'name': name + '.png', 'uv_width': tw, 'uv_height': th,
                          'source': 'data:image/png;base64,' + base64.b64encode(png).decode()}],
            'animations': animations}

if __name__ == '__main__':
    n = sys.argv[1]
    d = convert(n)
    print(n, 'elements', len(d['elements']), 'anims', [(a['name'], len(a['animators'])) for a in d['animations']])
