package kz.alih.visuals;

import net.minecraft.client.render.VertexConsumer;

/** Wraps a vertex consumer: multiplies vertex colour by a tint and alpha by a factor. */
public class GlowConsumer implements VertexConsumer {
    private final VertexConsumer d;
    private final int tr, tg, tb;
    private final float ta;

    public GlowConsumer(VertexConsumer delegate, int rgb, float alpha) {
        this.d = delegate;
        this.tr = rgb >> 16 & 255; this.tg = rgb >> 8 & 255; this.tb = rgb & 255;
        this.ta = alpha;
    }

    @Override public VertexConsumer vertex(float x, float y, float z) { d.vertex(x, y, z); return this; }
    @Override public VertexConsumer color(int r, int g, int b, int a) {
        d.color(r * tr / 255, g * tg / 255, b * tb / 255, (int) (a * ta)); return this;
    }
    @Override public VertexConsumer texture(float u, float v) { d.texture(u, v); return this; }
    @Override public VertexConsumer overlay(int u, int v) { d.overlay(u, v); return this; }
    @Override public VertexConsumer light(int u, int v) { d.light(u, v); return this; }
    @Override public VertexConsumer normal(float x, float y, float z) { d.normal(x, y, z); return this; }
}
