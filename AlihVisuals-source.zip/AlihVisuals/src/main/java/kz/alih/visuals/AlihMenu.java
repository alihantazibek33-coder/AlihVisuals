package kz.alih.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class AlihMenu extends Screen {
    private static final int PAD = 14, GAP = 10, RGAP = 6, HEAD = 58, FOOT = 24, CARD_H = 40;
    private static final int CYAN = 0xFF5CE1FF, CYAN_DIM = 0xFF3FA9C9;
    private static final long LONG_PRESS_MS = 450;

    // ---- animation timings (ms)
    private static final long OPEN_MS = 320, CLOSE_MS = 190, TOGGLE_MS = 520;

    private static float savedScroll = 0f;

    private int px, py, pw, ph, cardW, gx, viewTop, viewBottom;
    private int cbX, cbY, cbW = 78, cbH = 16;   // cosmetics button
    private int kbX, kbY, kbW = 66, kbH = 16;    // knives button
    private float scroll, maxScroll;
    private long last = System.nanoTime();
    private final long openedAt = System.currentTimeMillis();

    // open / close animation
    private boolean closing;
    private long closeAt;
    private float closeFrom = 1f;

    // per-frame helpers
    private float kk = 0.2f;   // smoothing factor for this frame
    private float al = 1f;     // current alpha multiplier (applied to every colour we draw)

    // per-card animation state
    private final long[] toggledAt = new long[Modules.ALL.size()];
    private final float[] hover = new float[Modules.ALL.size()];
    private final float[] press = new float[Modules.ALL.size()];

    // grid press / drag-scroll / long press
    private boolean pressActive, moved;
    private int pressCard = -1;
    private double pressY;
    private long pressTime;

    // settings popup (right click / long press on a card)
    private int popFor = -1;      // logical state (input)
    private int popShown = -1;    // what is drawn (stays while fading out)
    private float popT = 0f;      // 0..1 popup visibility
    private int popX, popY, popW, popH;
    private final List<W> widgets = new ArrayList<>();
    private W dragW;

    private static final int T_PRIMARY = 0, T_EXTRA = 1, T_MODE = 2, T_RESET = 3, T_CLOSE = 4;

    private static final class W {
        final int type, k, x, y, w, h;   // x,y relative to popup origin
        W(int type, int k, int x, int y, int w, int h) { this.type = type; this.k = k; this.x = x; this.y = y; this.w = w; this.h = h; }
    }

    public AlihMenu() { super(Text.literal("AlihVisuals")); scroll = savedScroll; }

    @Override
    protected void init() { layout(); }

    // ---------------------------------------------------------------- easing + alpha helpers
    private static float clamp01(float v) { return v < 0f ? 0f : Math.min(1f, v); }
    private static float easeOutCubic(float t) { t = clamp01(t); float u = 1f - t; return 1f - u * u * u; }
    private static float easeOutBack(float t) {
        t = clamp01(t);
        final float c1 = 1.70158f, c3 = c1 + 1f;
        float u = t - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    /** colour with the current alpha multiplier applied */
    private int A(int color) { return Colors.mulAlpha(color, al); }

    private void rr(DrawContext c, int x, int y, int w, int h, int r, int color) { Gfx.rrect(c, x, y, w, h, r, A(color)); }
    private void circ(DrawContext c, float x, float y, float r, int color) { Gfx.circle(c, x, y, r, A(color)); }
    private void fill(DrawContext c, int x1, int y1, int x2, int y2, int color) { c.fill(x1, y1, x2, y2, A(color)); }

    // vanilla treats text with alpha < 4 as opaque, so tiny alphas must be skipped
    private void text(DrawContext c, String s, int x, int y, int color) {
        color = A(color);
        if ((color >>> 24) < 8) return;
        c.drawTextWithShadow(textRenderer, s, x, y, color);
    }

    private void ctext(DrawContext c, String s, int cx, int y, int color) {
        color = A(color);
        if ((color >>> 24) < 8) return;
        c.drawCenteredTextWithShadow(textRenderer, s, cx, y, color);
    }

    /** 0..1 menu visibility (open: rises, close: falls) */
    private float visibility(long now) {
        if (closing) return closeFrom * (1f - clamp01((now - closeAt) / (float) CLOSE_MS));
        return clamp01((now - openedAt) / (float) OPEN_MS);
    }

    @Override
    public void close() {
        if (closing) return;
        long now = System.currentTimeMillis();
        closeFrom = visibility(now);
        closeAt = now;
        closing = true;
        popFor = -1;
    }

    private void layout() {
        pw = Math.min(width - 10, Math.max(340, (int) (width * 0.55)));
        ph = Math.min(height - 10, Math.max(300, (int) (height * 0.72)));
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cardW = (pw - PAD * 2 - GAP) / 2;
        gx = px + PAD;
        viewTop = py + HEAD - 4;
        viewBottom = py + ph - FOOT;
        int rows = (Modules.ALL.size() + 1) / 2;
        int content = rows * CARD_H + (rows - 1) * RGAP;
        maxScroll = Math.max(0, content - (viewBottom - (py + HEAD)) + 4);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        if (popFor >= 0) buildPopup(Modules.ALL.get(popFor));
    }

    private int cx(int i) { return gx + (i % 2) * (cardW + GAP); }
    private int cy(int i) { return py + HEAD - (int) scroll + (i / 2) * (CARD_H + RGAP); }
    private boolean inView(double my) { return my >= viewTop && my < viewBottom; }

    // ---------------------------------------------------------------- popup layout
    private void buildPopup(Modules.Module m) {
        widgets.clear();
        int sliders = (m.hasSetting() ? 1 : 0) + m.extras.size();
        boolean two = sliders >= 5;
        popW = Math.min(pw - 16, two ? 330 : 270);
        int inner = popW - 24;
        int colW = two ? (inner - 12) / 2 : inner;
        int y = 34, idx = 0;
        if (m.hasSetting()) {
            int col = two ? idx % 2 : 0, row = two ? idx / 2 : idx;
            widgets.add(new W(T_PRIMARY, -1, 12 + col * (colW + 12), y + row * 30 + 12, colW, 6));
            idx++;
        }
        for (int k = 0; k < m.extras.size(); k++, idx++) {
            int col = two ? idx % 2 : 0, row = two ? idx / 2 : idx;
            widgets.add(new W(T_EXTRA, k, 12 + col * (colW + 12), y + row * 30 + 12, colW, 6));
        }
        int rowsUsed = two ? (sliders + 1) / 2 : sliders;
        y += rowsUsed * 30 + (sliders > 0 ? 4 : 0);
        if (m.modes != null) {
            int n = m.modes.length, gap = 6;
            int cw = (inner - gap * (n - 1)) / n;
            for (int k = 0; k < n; k++) widgets.add(new W(T_MODE, k, 12 + k * (cw + gap), y + 12, cw, 18));
            y += 40;
        }
        if (m.resettable) {
            widgets.add(new W(T_RESET, 0, 12, y, inner, 20));
            y += 26;
        }
        widgets.add(new W(T_CLOSE, 0, popW - 24, 6, 16, 16));
        popH = y + 8;
        popX = px + (pw - popW) / 2;
        popY = Math.max(py + 6, py + (ph - popH) / 2);
    }

    private W widgetAt(double mx, double my) {
        for (W w : widgets) {
            int x = popX + w.x, y = popY + w.y;
            if (w.type == T_PRIMARY || w.type == T_EXTRA) {
                if (mx >= x - 5 && mx <= x + w.w + 5 && my >= y - 8 && my <= y + w.h + 8) return w;
            } else if (mx >= x && mx < x + w.w && my >= y && my < y + w.h) return w;
        }
        return null;
    }

    private void sliderTo(W w, double mx) {
        Modules.Module m = Modules.ALL.get(popFor);
        float t = (float) ((mx - (popX + w.x)) / w.w);
        if (w.type == T_PRIMARY) m.setNorm(t); else m.extras.get(w.k).setNorm(t);
    }

    // ---------------------------------------------------------------- rendering
    @Override public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        float v = easeOutCubic(visibility(System.currentTimeMillis()));
        int col = Colors.mulAlpha(0xB0090B10, v);
        if ((col >>> 24) > 0) c.fill(0, 0, width, height, col);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        final long nowMs = System.currentTimeMillis();
        final float vis = visibility(nowMs);
        if (closing && vis <= 0f) { super.close(); return; }   // close animation finished -> really close

        super.render(c, mx, my, delta);
        layout();
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        kk = 1f - (float) Math.exp(-dt * 14f);

        // popup fade
        popT += ((popFor >= 0 ? 1f : 0f) - popT) * (1f - (float) Math.exp(-dt * 18f));
        if (popFor >= 0) popShown = popFor;
        if (popFor < 0 && popT < 0.01f) { popT = 0f; popShown = -1; }

        // long press on a card -> settings (touch screens)
        if (!closing && pressActive && !moved && pressCard >= 0 && popFor < 0
                && System.currentTimeMillis() - pressTime > LONG_PRESS_MS) {
            if (Modules.ALL.get(pressCard).hasAnySettings()) openPopup(pressCard);
            pressActive = false; pressCard = -1;
        }

        // ---- whole-panel transform (scale + slide + fade)
        final float panelA = easeOutCubic(vis);
        final float scale = closing ? 0.94f + 0.06f * easeOutCubic(vis) : 0.90f + 0.10f * easeOutBack(vis);
        final float offY = (1f - easeOutCubic(vis)) * 14f;
        final float pcx = px + pw / 2f, pcy = py + ph / 2f;

        MatrixStack ms = c.getMatrices();
        ms.push();
        ms.translate(pcx, pcy + offY, 0);
        ms.scale(scale, scale, 1f);
        ms.translate(-pcx, -pcy, 0);
        al = panelA;

        rr(c, px - 1, py - 1, pw + 2, ph + 2, 11, 0xFF2C313C);
        rr(c, px, py, pw, ph, 10, 0xF01A1D24);
        c.fillGradient(px + 6, py + 2, px + pw - 6, py + 34, A(0x2A5CE1FF), 0x00000000);

        ms.push();
        ms.translate(px + pw / 2f, py + 11, 0);
        ms.scale(2f, 2f, 1f);
        ctext(c, "AlihVisuals", 0, 0, CYAN);
        ms.pop();
        ctext(c, "visual client", px + pw / 2, py + 32, 0xFF7C8494);

        // header line with a moving shimmer
        int lw = pw - 60, n = 60;
        float sweep = ((nowMs % 2600L) / 2600f) * 1.5f - 0.25f;
        for (int i = 0; i < n; i++) {
            float pos = (i + 0.5f) / n;
            float a = (float) Math.sin(Math.PI * pos);
            float g = (float) Math.exp(-Math.pow((pos - sweep) * 7.0, 2));
            int x1 = px + 30 + lw * i / n, x2 = px + 30 + lw * (i + 1) / n;
            int rgb = Colors.lerp(0xFF5CE1FF, 0xFFFFFFFF, g * 0.75f) & 0xFFFFFF;
            fill(c, x1, py + 46, x2, py + 47, Colors.argb((int) (255 * a * (0.55f + 0.45f * g)), rgb));
        }
        // knives button (top left)
        kbX = px + 8; kbY = py + 8;
        boolean kbHover = mx >= kbX && mx < kbX + kbW && my >= kbY && my < kbY + kbH && popFor < 0 && !closing;
        rr(c, kbX, kbY, kbW, kbH, 7, kbHover ? 0xFF3FA9C9 : 0xFF2A2E38);
        ctext(c, "Қылыштар", kbX + kbW / 2, kbY + 4, kbHover ? 0xFF0E1218 : CYAN);
        // cosmetics button (top right)
        cbX = px + pw - cbW - 8; cbY = py + 8;
        boolean cbHover = mx >= cbX && mx < cbX + cbW && my >= cbY && my < cbY + cbH && popFor < 0 && !closing;
        rr(c, cbX, cbY, cbW, cbH, 7, cbHover ? 0xFF3FA9C9 : 0xFF2A2E38);
        ctext(c, "Косметика", cbX + cbW / 2, cbY + 4, cbHover ? 0xFF0E1218 : CYAN);

        // ---- cards (scissor rect follows the panel transform)
        int sx0 = (int) Math.floor(pcx + (px + 2 - pcx) * scale);
        int sx1 = (int) Math.ceil(pcx + (px + pw - 2 - pcx) * scale);
        int sy0 = (int) Math.floor(pcy + offY + (viewTop - pcy) * scale);
        int sy1 = (int) Math.ceil(pcy + offY + (viewBottom - pcy) * scale);
        c.enableScissor(sx0, sy0, sx1, sy1);
        List<Modules.Module> all = Modules.ALL;
        for (int i = 0; i < all.size(); i++) {
            Modules.Module m = all.get(i);
            m.anim += ((m.enabled ? 1f : 0f) - m.anim) * kk;
            int y = cy(i);
            if (y + CARD_H < viewTop || y > viewBottom) continue;

            // staggered entrance: row by row
            float cardA = 1f, slide = 0f;
            if (!closing) {
                long delay = 70L + (i / 2) * 45L + (i % 2) * 25L;
                float lt = clamp01((nowMs - openedAt - delay) / 300f);
                cardA = easeOutCubic(lt);
                slide = (1f - easeOutCubic(lt)) * 18f;
            }
            al = panelA;
            drawCard(c, m, i, cx(i), y, popFor < 0 && !closing ? mx : -1, my, nowMs, cardA, slide);
        }
        c.disableScissor();
        al = panelA;

        if (maxScroll > 0) {
            int trackH = viewBottom - viewTop;
            int barH = Math.max(20, (int) (trackH * trackH / (trackH + maxScroll)));
            int barY = viewTop + (int) ((trackH - barH) * (scroll / maxScroll));
            rr(c, px + pw - 8, barY, 3, barH, 1, 0xFF3FA9C9);
        }

        ctext(c, "ПКМ / ұстап тұру - баптау   |   0 / ESC - жабу", px + pw / 2, py + ph - 15, 0xFF5E6575);

        if (popShown >= 0 && popT > 0.01f) drawPopup(c, mx, my);

        al = 1f;
        ms.pop();
    }

    private void drawCard(DrawContext c, Modules.Module m, int i, int x, int y, int mx, int my,
                          long nowMs, float cardA, float slide) {
        int w = cardW, h = CARD_H;
        boolean hov = inView(my) && mx >= x && mx < x + w && my >= y && my < y + h;
        hover[i] += ((hov ? 1f : 0f) - hover[i]) * kk;
        boolean pressing = pressActive && !moved && pressCard == i && popFor < 0;
        press[i] += ((pressing ? 1f : 0f) - press[i]) * kk;

        // toggle "pop" + ripple progress
        float tp = toggledAt[i] == 0L ? 1f : clamp01((nowMs - toggledAt[i]) / (float) TOGGLE_MS);
        float pop = (float) Math.sin(Math.PI * tp) * (1f - tp);
        float sc = (1f - 0.04f * press[i]) + 0.08f * pop;

        float prevAl = al;
        al = prevAl * cardA;
        if ((A(0xFF000000) >>> 24) < 2) { al = prevAl; return; }

        MatrixStack ms = c.getMatrices();
        float ccx = x + w / 2f, ccy = y + h / 2f;
        ms.push();
        ms.translate(ccx, ccy + slide, 0);
        ms.scale(sc, sc, 1f);
        ms.translate(-ccx, -ccy, 0);

        int border = Colors.lerp(0xFF2C313C, 0xFF3FA9C9, m.anim * 0.8f);
        float flash = tp < 1f ? (1f - tp) * (1f - tp) : 0f;
        if (flash > 0f) border = Colors.lerp(border, m.enabled ? 0xFFFFFFFF : 0xFF8A90A0, flash * 0.6f);
        int bg = Colors.lerp(0xFF23262E, 0xFF2B303B, hover[i]);
        rr(c, x, y, w, h, 7, border);
        rr(c, x + 1, y + 1, w - 2, h - 2, 6, bg);

        // ripple expanding from the switch
        if (tp < 1f) {
            float r = easeOutCubic(tp) * (w * 0.95f);
            int rc = m.enabled ? 0x4FC3F7 : 0xA0A8BA;
            int a = (int) (80 * (1f - tp) * (1f - tp * 0.4f));
            clippedCircle(c, x + w - 27, y + 14, r, x + 2, y + 1, x + w - 2, y + h - 1, A(Colors.argb(a, rc)));
        }

        // accent bar grows from the middle
        int bh = (int) ((h - 12) * m.anim);
        if (bh > 1) rr(c, x + 1, y + h / 2 - bh / 2, 2, bh, 1, Colors.argb(255, 0x5CE1FF));

        text(c, m.name, x + 10, y + 8, Colors.lerp(0xFFE6E9EF, 0xFFFFFFFF, m.anim));
        text(c, textRenderer.trimToWidth(m.desc, w - 64), x + 10, y + 21, Colors.lerp(0xFF8A90A0, 0xFFA9B8C8, m.anim));

        // switch: stretchy knob while it moves
        int tx = x + w - 10 - 34, ty = y + 6;
        rr(c, tx, ty, 34, 16, 8, Colors.lerp(0xFF3A3F4B, 0xFF4FC3F7, m.anim));
        float mv = 4f * m.anim * (1f - m.anim);
        int kw = 12 + (int) (8 * mv);
        float kc = tx + 8 + 18 * m.anim;
        if (m.anim > 0.05f) circ(c, kc, ty + 8, 10f, Colors.argb((int) (45 * m.anim), 0x4FC3F7));
        rr(c, (int) (kc - kw / 2f), ty + 2, kw, 12, 6, 0xFFFFFFFF);

        if (m.hasAnySettings()) {          // three dots = "has settings"
            for (int d = 0; d < 3; d++) circ(c, tx + 11 + d * 6, y + h - 9, 1.6f, 0xFF6F7788);
        }

        ms.pop();
        al = prevAl;
    }

    /** filled circle clipped to a rectangle (colour already has alpha applied) */
    private void clippedCircle(DrawContext c, float cx, float cy, float r, int x0, int y0, int x1, int y1, int color) {
        if ((color >>> 24) == 0) return;
        int top = Math.max(y0, (int) Math.floor(cy - r)), bot = Math.min(y1, (int) Math.ceil(cy + r));
        for (int yy = top; yy < bot; yy++) {
            double dy = yy + 0.5 - cy;
            double v = (double) r * r - dy * dy;
            if (v <= 0) continue;
            int hw = (int) Math.round(Math.sqrt(v));
            int l = Math.max(x0, (int) cx - hw), rgt = Math.min(x1, (int) cx + hw);
            if (rgt > l) c.fill(l, yy, rgt, yy + 1, color);
        }
    }

    private void drawSlider(DrawContext c, int x, int y, int w, float norm, boolean hue, int knobRgb, String label, boolean drag) {
        text(c, label, x, y - 12, 0xFFA0A7B6);
        if (hue) {
            for (int i = 0; i < w; i += 2)
                fill(c, x + i, y, Math.min(x + i + 2, x + w), y + 6, 0xFF000000 | Colors.hsb(i / (float) w, 0.85f, 1f));
        } else {
            rr(c, x, y, w, 6, 3, 0xFF3A3F4B);
            rr(c, x, y, Math.max(6, (int) (w * norm)), 6, 3, 0xFF4FC3F7);
        }
        float kx = x + w * norm;
        if (drag) circ(c, kx, y + 3, 8f, Colors.argb(60, knobRgb & 0xFFFFFF));
        circ(c, kx, y + 3, drag ? 6f : 5f, 0xFF12141A);
        circ(c, kx, y + 3, drag ? 5f : 4f, knobRgb);
    }

    private void drawPopup(DrawContext c, int mx, int my) {
        Modules.Module m = Modules.ALL.get(popShown);
        float prevAl = al;
        float e = clamp01(popT);

        // dim the grid behind the popup
        al = prevAl * e;
        fill(c, px, py, px + pw, py + ph, 0xA0000000);

        MatrixStack ms = c.getMatrices();
        float pcx = popX + popW / 2f, pcy = popY + popH / 2f;
        float s = 0.90f + 0.10f * easeOutBack(e);
        ms.push();
        ms.translate(pcx, pcy + (1f - e) * 8f, 0);
        ms.scale(s, s, 1f);
        ms.translate(-pcx, -pcy, 0);

        rr(c, popX - 1, popY - 1, popW + 2, popH + 2, 9, 0xFF3FA9C9);
        rr(c, popX, popY, popW, popH, 8, 0xFF1D2028);
        text(c, m.name, popX + 12, popY + 11, CYAN);

        boolean modeLabelDrawn = false;
        for (W w : widgets) {
            int x = popX + w.x, y = popY + w.y;
            switch (w.type) {
                case T_PRIMARY -> {
                    boolean hue = m.settingName.equals("Color");
                    String label = hue ? "Color" : String.format("%s  %.2f", m.settingName, m.value);
                    drawSlider(c, x, y, w.w, m.norm(), hue, hue ? 0xFF000000 | m.rgb() : 0xFFFFFFFF, label, dragW == w);
                }
                case T_EXTRA -> {
                    Modules.Setting st = m.extras.get(w.k);
                    drawSlider(c, x, y, w.w, st.norm(), false, 0xFFFFFFFF, String.format("%s  %.2f", st.name, st.value), dragW == w);
                }
                case T_MODE -> {
                    if (!modeLabelDrawn) { text(c, "Style", x, y - 12, 0xFFA0A7B6); modeLabelDrawn = true; }
                    boolean sel = m.mode == w.k;
                    boolean hov = mx >= x && mx < x + w.w && my >= y && my < y + w.h;
                    rr(c, x, y, w.w, w.h, 6, sel ? 0xFF4FC3F7 : (hov ? 0xFF343946 : 0xFF2A2E38));
                    ctext(c, m.modes[w.k], x + w.w / 2, y + 5, sel ? 0xFF0E1218 : 0xFFB8BFCC);
                }
                case T_RESET -> {
                    boolean hov = mx >= x && mx < x + w.w && my >= y && my < y + w.h;
                    rr(c, x, y, w.w, w.h, 6, hov ? 0xFF4A2A38 : 0xFF3A2430);
                    ctext(c, "Reset - қалыпты қолға қайтару", x + w.w / 2, y + 6, 0xFFFFB4C0);
                }
                case T_CLOSE -> ctext(c, "x", x + 8, y + 4, 0xFF8A90A0);
                default -> {}
            }
        }
        ms.pop();
        al = prevAl;
    }

    // ---------------------------------------------------------------- input
    private void openPopup(int i) {
        popFor = i;
        popShown = i;
        dragW = null;
        buildPopup(Modules.ALL.get(i));
    }

    private int cardAt(double mx, double my) {
        if (!inView(my)) return -1;
        for (int i = 0; i < Modules.ALL.size(); i++) {
            int x = cx(i), y = cy(i);
            if (mx >= x && mx < x + cardW && my >= y && my < y + CARD_H) return i;
        }
        return -1;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (closing) return true;
        if (popFor >= 0) {
            boolean inside = mx >= popX && mx < popX + popW && my >= popY && my < popY + popH;
            if (!inside) { popFor = -1; return true; }
            W w = widgetAt(mx, my);
            if (w != null && button == 0) {
                Modules.Module m = Modules.ALL.get(popFor);
                switch (w.type) {
                    case T_PRIMARY, T_EXTRA -> { dragW = w; sliderTo(w, mx); }
                    case T_MODE -> m.mode = w.k;
                    case T_RESET -> m.resetExtras();
                    case T_CLOSE -> popFor = -1;
                    default -> {}
                }
            }
            return true;
        }
        if (button == 0 && mx >= kbX && mx < kbX + kbW && my >= kbY && my < kbY + kbH) {
            client.setScreen(new kz.alih.visuals.knives.KnifeScreen());
            return true;
        }
        if (button == 0 && mx >= cbX && mx < cbX + cbW && my >= cbY && my < cbY + cbH) {
            client.setScreen(new kz.alih.visuals.cosmetics.CosmeticsScreen());
            return true;
        }
        int ci = cardAt(mx, my);
        if (button == 1) {
            if (ci >= 0 && Modules.ALL.get(ci).hasAnySettings()) openPopup(ci);
            return true;
        }
        if (button == 0 && inView(my)) {
            pressActive = true; moved = false; pressY = my; pressCard = ci; pressTime = System.currentTimeMillis();
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (closing) return true;
        if (popFor >= 0) {
            if (dragW != null) sliderTo(dragW, mx);
            return true;
        }
        if (pressActive) {
            if (Math.abs(my - pressY) > 5) moved = true;
            if (moved) scroll = Math.max(0, Math.min(maxScroll, scroll - (float) dy));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragW = null;
        if (!closing && pressActive && !moved && pressCard >= 0 && pressCard == cardAt(mx, my) && popFor < 0) {
            Modules.Module m = Modules.ALL.get(pressCard);
            m.enabled = !m.enabled;
            toggledAt[pressCard] = System.currentTimeMillis();   // starts the ripple / pop animation
        }
        pressActive = false; pressCard = -1;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (closing || popFor >= 0) return true;
        scroll = Math.max(0, Math.min(maxScroll, scroll - (float) vAmount * 24f));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (closing) return true;
        if (key == GLFW.GLFW_KEY_ESCAPE && popFor >= 0) { popFor = -1; return true; }
        if ((key == GLFW.GLFW_KEY_0 || key == GLFW.GLFW_KEY_KP_0) && System.currentTimeMillis() - openedAt > 200) {
            if (popFor >= 0) popFor = -1; else close();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void removed() { savedScroll = scroll; Modules.save(); }
}
