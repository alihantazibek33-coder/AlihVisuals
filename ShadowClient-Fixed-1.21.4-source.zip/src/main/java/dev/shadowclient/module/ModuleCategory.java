package dev.shadowclient.module;

public enum ModuleCategory {
    VISUALS("Visuals"), HUD("HUD"), QUALITY("Quality of Life"), PLAYER("Player");
    private final String title;
    ModuleCategory(String title) { this.title = title; }
    public String title() { return title; }
}
