package dev.shadowclient;

import dev.shadowclient.gui.ClickGuiScreen;
import dev.shadowclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class ShadowClient implements ClientModInitializer {
    private static KeyBinding openGuiKey;
    private static boolean rightShiftWasDown = false;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.shadowclient.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.shadowclient"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean rightShiftDown = InputUtil.isKeyPressed(
                    client.getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT
            );
            boolean pressedByFallback = rightShiftDown && !rightShiftWasDown;
            rightShiftWasDown = rightShiftDown;

            boolean pressedByBinding = false;
            while (openGuiKey.wasPressed()) {
                pressedByBinding = true;
            }

            if ((pressedByBinding || pressedByFallback) && client.player != null) {
                if (client.currentScreen instanceof ClickGuiScreen) {
                    client.setScreen(null);
                } else if (client.currentScreen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }
        });
    }
}
