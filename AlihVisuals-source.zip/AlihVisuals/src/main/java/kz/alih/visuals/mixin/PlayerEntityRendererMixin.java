package kz.alih.visuals.mixin;

import kz.alih.visuals.GlowConsumer;
import kz.alih.visuals.Modules;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {

    private static final float[][] PASSES = {{1.05f, 0.30f}, {1.10f, 0.18f}};

    // Shader Hands (bare hand / arm in first person)
    @Redirect(method = "renderArm",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/model/ModelPart;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;II)V"),
            require = 0)
    private void alih$glowArm(ModelPart part, MatrixStack ms, VertexConsumer vc, int light, int overlay) {
        part.render(ms, vc, light, overlay);
        if (!Modules.SHADERHANDS.enabled) return;
        int rgb = Modules.SHADERHANDS.rgb();
        for (float[] ps : PASSES) {
            ms.push();
            ms.scale(ps[0], ps[0], ps[0]);
            part.render(ms, new GlowConsumer(vc, rgb, ps[1]), LightmapTextureManager.MAX_LIGHT_COORDINATE, overlay);
            ms.pop();
        }
    }
}
