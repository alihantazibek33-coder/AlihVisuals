package kz.alih.visuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class WorldRender {
    private WorldRender() {}

    private static final class Circle {
        final double x, y, z; final long start;
        Circle(double x, double y, double z) { this.x = x; this.y = y; this.z = z; this.start = System.currentTimeMillis(); }
    }

    private static final class TP {
        final double x, y, z; final long t;
        TP(double x, double y, double z, long t) { this.x = x; this.y = y; this.z = z; this.t = t; }
    }

    /** snapshot of the trail used by the Trails styles (index n-1 = current position) */
    private static final class TrailData {
        double[] x, y, z; float[] life; long[] age; int n; boolean first; long now; float base;
        Vector3f right, up;
    }

    private static final List<TP> TRAIL = new ArrayList<>();
    private static final long TRAIL_MS = 1100;
    private static final List<Circle> CIRCLES = new ArrayList<>();
    private static final long CIRCLE_MS = 1100;
    private static boolean wasGround = true;

    private static final class HitFx {
        final double x, y, z; final long start, seed; final int mode; final float hue;
        HitFx(double x, double y, double z, long seed, int mode, float hue) {
            this.x = x; this.y = y; this.z = z; this.start = System.currentTimeMillis(); this.seed = seed; this.mode = mode; this.hue = hue;
        }
    }
    private static final List<HitFx> HITS = new ArrayList<>();

    /** called when the player attacks an entity */
    public static void spawnHit(LivingEntity e) {
        if (!Modules.HITPARTICLES.enabled) return;
        HITS.add(new HitFx(e.getX(), e.getY() + e.getHeight() * 0.55, e.getZ(), (long) (Math.random() * 1.0e9),
                Modules.HITPARTICLES.mode, Modules.HITPARTICLES.value));
        if (HITS.size() > 24) HITS.remove(0);
    }

    public static void register() { WorldRenderEvents.AFTER_ENTITIES.register(WorldRender::render); }

    /** called every client tick */
    public static void tick(MinecraftClient mc) {
        PlayerEntity p = mc.player;
        if (p == null) { wasGround = true; TRAIL.clear(); return; }
        if (Modules.TRAILS.enabled) {
            final long now = System.currentTimeMillis();
            TP last = TRAIL.isEmpty() ? null : TRAIL.get(TRAIL.size() - 1);
            double dx = last == null ? 1 : p.getX() - last.x, dy = last == null ? 0 : p.getY() - last.y,
                    dz = last == null ? 0 : p.getZ() - last.z;
            if (dx * dx + dy * dy + dz * dz > 0.0025) TRAIL.add(new TP(p.getX(), p.getY(), p.getZ(), now));
            TRAIL.removeIf(t -> now - t.t > TRAIL_MS);
        } else {
            TRAIL.clear();
        }
        if (Modules.JUMPCIRCLES.enabled && wasGround && !p.isOnGround() && p.getVelocity().y > 0.1) {
            CIRCLES.add(new Circle(p.prevX, p.prevY, p.prevZ));
        }
        wasGround = p.isOnGround();
    }

    // ---------------------------------------------------------------- vertex helpers (quads are emitted double-sided)
    private static void v(VertexConsumer vc, Matrix4f m, float x, float y, float z, int argb) {
        vc.vertex(m, x, y, z).color(argb);
    }

    private static void quad(VertexConsumer vc, Matrix4f m,
                             float x1, float y1, float z1, int c1, float x2, float y2, float z2, int c2,
                             float x3, float y3, float z3, int c3, float x4, float y4, float z4, int c4) {
        v(vc, m, x1, y1, z1, c1); v(vc, m, x2, y2, z2, c2); v(vc, m, x3, y3, z3, c3); v(vc, m, x4, y4, z4, c4);
        v(vc, m, x4, y4, z4, c4); v(vc, m, x3, y3, z3, c3); v(vc, m, x2, y2, z2, c2); v(vc, m, x1, y1, z1, c1);
    }

    private static void tri(VertexConsumer vc, Matrix4f m,
                            float x1, float y1, float z1, int c1, float x2, float y2, float z2, int c2,
                            float x3, float y3, float z3, int c3) {
        quad(vc, m, x1, y1, z1, c1, x2, y2, z2, c2, x3, y3, z3, c3, x3, y3, z3, c3);
    }

    private static void box(VertexConsumer vc, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2, int c) {
        quad(vc, m, x1, y1, z1, c, x2, y1, z1, c, x2, y1, z2, c, x1, y1, z2, c); // bottom
        quad(vc, m, x1, y2, z1, c, x2, y2, z1, c, x2, y2, z2, c, x1, y2, z2, c); // top
        quad(vc, m, x1, y1, z1, c, x2, y1, z1, c, x2, y2, z1, c, x1, y2, z1, c); // north
        quad(vc, m, x1, y1, z2, c, x2, y1, z2, c, x2, y2, z2, c, x1, y2, z2, c); // south
        quad(vc, m, x1, y1, z1, c, x1, y1, z2, c, x1, y2, z2, c, x1, y2, z1, c); // west
        quad(vc, m, x2, y1, z1, c, x2, y1, z2, c, x2, y2, z2, c, x2, y2, z1, c); // east
    }

    private static void glow(VertexConsumer vc, Matrix4f m, float x, float y, float z, Vector3f r, Vector3f u,
                             float rad, int n, int cIn, int cOut) {
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            float x0 = x + (r.x * c0 + u.x * s0) * rad, y0 = y + (r.y * c0 + u.y * s0) * rad, z0 = z + (r.z * c0 + u.z * s0) * rad;
            float x1 = x + (r.x * c1 + u.x * s1) * rad, y1 = y + (r.y * c1 + u.y * s1) * rad, z1 = z + (r.z * c1 + u.z * s1) * rad;
            tri(vc, m, x, y, z, cIn, x0, y0, z0, cOut, x1, y1, z1, cOut);
        }
    }

    private static void ring(VertexConsumer vc, Matrix4f m, float x, float y, float z, float rIn, float rOut, int cIn, int cOut) {
        arc(vc, m, x, y, z, rIn, rOut, 0f, (float) (Math.PI * 2), 64, cIn, cOut, cIn, cOut);
    }

    /** flat arc; t=0 (tail) -> t=1 (head); colours given as {tailIn, tailOut, headIn, headOut} */
    private static void arc(VertexConsumer vc, Matrix4f m, float x, float y, float z, float rIn, float rOut,
                            float a0, float len, int segs, int tIn, int tOut, int hIn, int hOut) {
        for (int i = 0; i < segs; i++) {
            float f0 = i / (float) segs, f1 = (i + 1) / (float) segs;
            float aa = a0 + len * f0, ab = a0 + len * f1;
            float c0 = (float) Math.cos(aa), s0 = (float) Math.sin(aa), c1 = (float) Math.cos(ab), s1 = (float) Math.sin(ab);
            int i0 = Colors.lerp(tIn, hIn, f0), o0 = Colors.lerp(tOut, hOut, f0);
            int i1 = Colors.lerp(tIn, hIn, f1), o1 = Colors.lerp(tOut, hOut, f1);
            quad(vc, m, x + c0 * rIn, y, z + s0 * rIn, i0, x + c1 * rIn, y, z + s1 * rIn, i1,
                    x + c1 * rOut, y, z + s1 * rOut, o1, x + c0 * rOut, y, z + s0 * rOut, o0);
        }
    }

    // ---------------------------------------------------------------- main render hook
    private static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (ms == null || vcp == null) return;
        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(false);
        boolean first = mc.options.getPerspective().isFirstPerson();

        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLightning());
        ms.push();
        Matrix4f m = ms.peek().getPositionMatrix();

        if (Modules.CHINAHAT.enabled && !first) chinaHat(vc, m, mc.player, cam, td);
        if (Modules.BLOCKOVERLAY.enabled) blockOverlay(vc, m, mc, cam);
        if (Modules.HITBOX.enabled) hitBoxes(vc, m, mc, cam, td);
        if (Modules.TARGETRENDER.enabled) targetRender(vc, m, cam, ctx.camera(), td);
        if (Modules.TRAILS.enabled) trails(vc, m, cam, ctx.camera(), mc.player, td, first);
        if (Modules.JUMPCIRCLES.enabled) jumpCircles(vc, m, cam);
        else CIRCLES.clear();
        if (Modules.HITPARTICLES.enabled) hitFx(vc, m, cam, ctx.camera());
        else HITS.clear();
        if (Modules.WORLDPARTICLES.enabled) worldParticles(vc, m, cam, ctx.camera());
        if (Modules.PREDICTION.enabled) prediction(vc, m, mc, cam, ctx.camera(), td);

        ms.pop();
    }

    // ---------------------------------------------------------------- ChinaHat
    private static void chinaHat(VertexConsumer vc, Matrix4f m, PlayerEntity p, Vec3d cam, float td) {
        float x = (float) (MathHelper.lerp(td, p.prevX, p.getX()) - cam.x);
        float y = (float) (MathHelper.lerp(td, p.prevY, p.getY()) - cam.y + p.getHeight() - 0.03);
        float z = (float) (MathHelper.lerp(td, p.prevZ, p.getZ()) - cam.z);
        final int n = 48;
        final float r = 0.62f, hgt = 0.34f;
        float h = Modules.CHINAHAT.value;
        int apex = Colors.argb(235, Colors.hsb(h, 0.38f, 1f));
        int base = Colors.argb(170, Colors.hsb(h, 0.85f, 1f));
        int rimRgb = Colors.hsb(h, 0.5f, 1f);
        int ringIn = Colors.argb(255, rimRgb), ringOut = Colors.argb(0, rimRgb);
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            tri(vc, m, x + c0 * r, y, z + s0 * r, base, x + c1 * r, y, z + s1 * r, base, x, y + hgt, z, apex);
            float ro = r + 0.05f;
            quad(vc, m, x + c0 * r, y, z + s0 * r, ringIn, x + c1 * r, y, z + s1 * r, ringIn,
                    x + c1 * ro, y, z + s1 * ro, ringOut, x + c0 * ro, y, z + s0 * ro, ringOut);
        }
    }

    // ---------------------------------------------------------------- Block overlay
    private static void blockOverlay(VertexConsumer vc, Matrix4f m, MinecraftClient mc, Vec3d cam) {
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = hit.getBlockPos();
        VoxelShape shape = mc.world.getBlockState(pos).getOutlineShape(mc.world, pos);
        if (shape.isEmpty()) return;
        int col = Colors.argb(85, Modules.BLOCKOVERLAY.rgb());
        final float e = 0.002f;
        float ox = (float) (pos.getX() - cam.x), oy = (float) (pos.getY() - cam.y), oz = (float) (pos.getZ() - cam.z);
        shape.forEachBox((x1, y1, z1, x2, y2, z2) ->
                box(vc, m, ox + (float) x1 - e, oy + (float) y1 - e, oz + (float) z1 - e,
                        ox + (float) x2 + e, oy + (float) y2 + e, oz + (float) z2 + e, col));
    }

    // ---------------------------------------------------------------- HitBox
    private static void edges(VertexConsumer vc, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2,
                              float t, int c) {
        for (int a = 0; a < 2; a++) {
            float y = a == 0 ? y1 : y2;
            for (int b = 0; b < 2; b++) {
                float z = b == 0 ? z1 : z2;
                box(vc, m, x1 - t, y - t, z - t, x2 + t, y + t, z + t, c);          // along X
            }
        }
        for (int a = 0; a < 2; a++) {
            float x = a == 0 ? x1 : x2;
            for (int b = 0; b < 2; b++) {
                float z = b == 0 ? z1 : z2;
                box(vc, m, x - t, y1 - t, z - t, x + t, y2 + t, z + t, c);          // along Y
            }
        }
        for (int a = 0; a < 2; a++) {
            float x = a == 0 ? x1 : x2;
            for (int b = 0; b < 2; b++) {
                float y = b == 0 ? y1 : y2;
                box(vc, m, x - t, y - t, z1 - t, x + t, y + t, z2 + t, c);          // along Z
            }
        }
    }

    private static void corners(VertexConsumer vc, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2,
                                float t, int c) {
        float lx = Math.min(0.28f, (x2 - x1) * 0.4f), ly = Math.min(0.40f, (y2 - y1) * 0.25f), lz = Math.min(0.28f, (z2 - z1) * 0.4f);
        for (int i = 0; i < 8; i++) {
            float x = (i & 1) == 0 ? x1 : x2, y = (i & 2) == 0 ? y1 : y2, z = (i & 4) == 0 ? z1 : z2;
            float sx = (i & 1) == 0 ? 1 : -1, sy = (i & 2) == 0 ? 1 : -1, sz = (i & 4) == 0 ? 1 : -1;
            box(vc, m, Math.min(x, x + sx * lx) - t, y - t, z - t, Math.max(x, x + sx * lx) + t, y + t, z + t, c);
            box(vc, m, x - t, Math.min(y, y + sy * ly) - t, z - t, x + t, Math.max(y, y + sy * ly) + t, z + t, c);
            box(vc, m, x - t, y - t, Math.min(z, z + sz * lz) - t, x + t, y + t, Math.max(z, z + sz * lz) + t, c);
        }
    }

    private static void hitBoxes(VertexConsumer vc, Matrix4f m, MinecraftClient mc, Vec3d cam, float td) {
        Modules.Module hb = Modules.HITBOX;
        int rgb = Colors.hsb(hb.value, 0.75f, 1f);
        int white = Colors.hsb(hb.value, 0.15f, 1f);
        float fill = hb.extras.get(0).value;
        for (PlayerEntity pl : mc.world.getPlayers()) {
            if (pl == mc.player || pl.isSpectator()) continue;
            if (pl.squaredDistanceTo(mc.player) > 4096) continue;
            Box b = pl.getBoundingBox();
            double ox = MathHelper.lerp(td, pl.prevX, pl.getX()) - pl.getX();
            double oy = MathHelper.lerp(td, pl.prevY, pl.getY()) - pl.getY();
            double oz = MathHelper.lerp(td, pl.prevZ, pl.getZ()) - pl.getZ();
            float x1 = (float) (b.minX + ox - cam.x), y1 = (float) (b.minY + oy - cam.y), z1 = (float) (b.minZ + oz - cam.z);
            float x2 = (float) (b.maxX + ox - cam.x), y2 = (float) (b.maxY + oy - cam.y), z2 = (float) (b.maxZ + oz - cam.z);
            float eye = (float) (pl.getEyeY() + oy - cam.y);

            // soft translucent body
            int fillA = (int) (fill * 90);
            if (hb.mode == 1) fillA = Math.max(fillA, 30);
            if (fillA > 0) box(vc, m, x1, y1, z1, x2, y2, z2, Colors.argb(fillA, rgb));

            if (hb.mode == 2) corners(vc, m, x1, y1, z1, x2, y2, z2, 0.014f, Colors.argb(255, white));
            else edges(vc, m, x1, y1, z1, x2, y2, z2, 0.010f, Colors.argb(hb.mode == 1 ? 200 : 255, rgb));

            // eye line
            box(vc, m, x1, eye - 0.006f, z1, x2, eye + 0.006f, z2, Colors.argb(220, white));
        }
    }

    // ---------------------------------------------------------------- Jump circles
    private static void jumpCircles(VertexConsumer vc, Matrix4f m, Vec3d cam) {
        long now = System.currentTimeMillis();
        int rgb = Modules.JUMPCIRCLES.rgb();
        int rgb2 = Colors.hsb(Modules.JUMPCIRCLES.value + 0.08f, 0.6f, 1f);
        for (Iterator<Circle> it = CIRCLES.iterator(); it.hasNext(); ) {
            Circle c = it.next();
            float t = (now - c.start) / (float) CIRCLE_MS;
            if (t >= 1f) { it.remove(); continue; }
            float ease = 1f - (float) Math.pow(1f - t, 3);
            float fade = 1f - t;
            float x = (float) (c.x - cam.x), y = (float) (c.y - cam.y) + 0.03f, z = (float) (c.z - cam.z);
            float r = 0.3f + ease * 1.9f;
            ring(vc, m, x, y, z, r - 0.22f, r, Colors.argb(0, rgb), Colors.argb((int) (240 * fade), rgb));
            ring(vc, m, x, y, z, 0f, r - 0.22f, Colors.argb((int) (40 * fade), rgb), Colors.argb(0, rgb));
            ring(vc, m, x, y + 0.001f, z, r, r + 0.05f, Colors.argb((int) (255 * fade), 0xFFFFFF), Colors.argb(0, 0xFFFFFF));
            float t2 = Math.max(0f, t - 0.15f) / 0.85f;
            if (t2 > 0f) {
                float r2 = 0.2f + (1f - (float) Math.pow(1f - t2, 3)) * 1.1f;
                ring(vc, m, x, y + 0.002f, z, r2 - 0.12f, r2, Colors.argb(0, rgb2), Colors.argb((int) (200 * (1f - t2)), rgb2));
            }
        }
    }

    // ---------------------------------------------------------------- Trails (4 styles)
    private static void trails(VertexConsumer vc, Matrix4f m, Vec3d cam, Camera camera, PlayerEntity p, float td, boolean first) {
        final long now = System.currentTimeMillis();
        TRAIL.removeIf(t -> now - t.t > TRAIL_MS);
        int n = TRAIL.size() + 1;
        if (n < 2) return;
        TrailData d = new TrailData();
        d.n = n; d.first = first; d.now = now; d.base = Modules.TRAILS.value;
        d.x = new double[n]; d.y = new double[n]; d.z = new double[n];
        d.life = new float[n]; d.age = new long[n];
        d.right = new Vector3f(1, 0, 0).rotate(camera.getRotation());
        d.up = new Vector3f(0, 1, 0).rotate(camera.getRotation());
        for (int i = 0; i < n - 1; i++) {
            TP t = TRAIL.get(i);
            d.x[i] = t.x - cam.x; d.y[i] = t.y - cam.y; d.z[i] = t.z - cam.z;
            d.age[i] = now - t.t;
            d.life[i] = 1f - d.age[i] / (float) TRAIL_MS;
        }
        d.x[n - 1] = MathHelper.lerp(td, p.prevX, p.getX()) - cam.x;
        d.y[n - 1] = MathHelper.lerp(td, p.prevY, p.getY()) - cam.y;
        d.z[n - 1] = MathHelper.lerp(td, p.prevZ, p.getZ()) - cam.z;
        d.life[n - 1] = 1f;

        switch (Modules.TRAILS.mode) {
            case 1 -> trailWave(vc, m, d);
            case 2 -> trailSparks(vc, m, d);
            case 3 -> trailHelix(vc, m, d);
            default -> trailRibbon(vc, m, d);
        }
    }

    private static void trailRibbon(VertexConsumer vc, Matrix4f m, TrailData d) {
        final float[] heights = {0.40f, 0.90f, 1.40f};
        final float w = 0.09f;
        for (int j = 0; j < heights.length; j++) {
            for (int k = 1; k < d.n; k++) {
                if (d.first && d.age[k - 1] < 250) continue;
                float fa = Math.max(0f, d.life[k - 1]), fb = Math.max(0f, d.life[k]);
                int ca = Colors.argb((int) (200 * fa * fa), Colors.hsb(d.base + 0.06f * j + 0.10f * (1f - fa), 0.75f, 1f));
                int cb = Colors.argb((int) (200 * fb * fb), Colors.hsb(d.base + 0.06f * j + 0.10f * (1f - fb), 0.75f, 1f));
                float wa = (float) Math.sin(d.now / 220.0 + k * 0.55 + j) * 0.05f * (1f - fa);
                float wb = (float) Math.sin(d.now / 220.0 + (k + 1) * 0.55 + j) * 0.05f * (1f - fb);
                float ax = (float) d.x[k - 1], ay = (float) d.y[k - 1] + heights[j] + wa, az = (float) d.z[k - 1];
                float bx = (float) d.x[k], by = (float) d.y[k] + heights[j] + wb, bz = (float) d.z[k];
                quad(vc, m, ax, ay - w, az, ca, bx, by - w, bz, cb, bx, by + w, bz, cb, ax, ay + w, az, ca);
            }
        }
    }

    private static void trailWave(VertexConsumer vc, Matrix4f m, TrailData d) {
        for (int k = 1; k < d.n; k++) {
            if (d.first && d.age[k - 1] < 250) continue;
            float fa = Math.max(0f, d.life[k - 1]), fb = Math.max(0f, d.life[k]);
            float pa = (float) (d.now / 170.0 + (k - 1) * 0.55), pb = (float) (d.now / 170.0 + k * 0.55);
            float ya = 0.95f + (float) Math.sin(pa) * 0.34f * (1f - fa * 0.4f);
            float yb = 0.95f + (float) Math.sin(pb) * 0.34f * (1f - fb * 0.4f);
            float ax = (float) d.x[k - 1], ay = (float) d.y[k - 1] + ya, az = (float) d.z[k - 1];
            float bx = (float) d.x[k], by = (float) d.y[k] + yb, bz = (float) d.z[k];
            int rgbA = Colors.hsb(d.base + 0.12f * (1f - fa), 0.7f, 1f), rgbB = Colors.hsb(d.base + 0.12f * (1f - fb), 0.7f, 1f);
            // broad soft band + thin white core
            quad(vc, m, ax, ay - 0.13f, az, Colors.argb(0, rgbA), bx, by - 0.13f, bz, Colors.argb(0, rgbB),
                    bx, by, bz, Colors.argb((int) (210 * fb * fb), rgbB), ax, ay, az, Colors.argb((int) (210 * fa * fa), rgbA));
            quad(vc, m, ax, ay, az, Colors.argb((int) (210 * fa * fa), rgbA), bx, by, bz, Colors.argb((int) (210 * fb * fb), rgbB),
                    bx, by + 0.13f, bz, Colors.argb(0, rgbB), ax, ay + 0.13f, az, Colors.argb(0, rgbA));
            quad(vc, m, ax, ay - 0.018f, az, Colors.argb((int) (255 * fa * fa), 0xFFFFFF), bx, by - 0.018f, bz, Colors.argb((int) (255 * fb * fb), 0xFFFFFF),
                    bx, by + 0.018f, bz, Colors.argb((int) (255 * fb * fb), 0xFFFFFF), ax, ay + 0.018f, az, Colors.argb((int) (255 * fa * fa), 0xFFFFFF));
        }
    }

    private static float rnd(long seed, int i) {
        long h = seed * 0x9E3779B97F4A7C15L + i * 0xBF58476D1CE4E5B9L;
        h ^= h >>> 31; h *= 0x94D049BB133111EBL; h ^= h >>> 29;
        return ((h >>> 40) & 0xFFFFFF) / (float) 0x1000000;
    }

    private static void trailSparks(VertexConsumer vc, Matrix4f m, TrailData d) {
        for (int k = 0; k < d.n - 1; k++) {
            if (d.first && d.age[k] < 250) continue;
            float life = Math.max(0f, d.life[k]);
            long seed = d.now - d.age[k];
            float ox = (rnd(seed, 1) - 0.5f) * 0.9f, oz = (rnd(seed, 2) - 0.5f) * 0.9f;
            float oy = 0.15f + rnd(seed, 3) * 1.5f + d.age[k] * 0.00035f;
            float size = (0.05f + 0.06f * rnd(seed, 4)) * (0.35f + 0.65f * life);
            int rgb = Colors.hsb(d.base + 0.12f * rnd(seed, 5), 0.6f, 1f);
            float x = (float) d.x[k] + ox, y = (float) d.y[k] + oy, z = (float) d.z[k] + oz;
            int a = (int) (255 * (float) Math.pow(life, 1.2));
            glow(vc, m, x, y, z, d.right, d.up, size * 2.6f, 8, Colors.argb(a / 2, rgb), Colors.argb(0, rgb));
            glow(vc, m, x, y, z, d.right, d.up, size, 8, Colors.argb(a, 0xFFFFFF), Colors.argb(a / 2, rgb));
        }
    }

    private static void trailHelix(VertexConsumer vc, Matrix4f m, TrailData d) {
        for (int s = 0; s < 2; s++) {
            float ph = s * (float) Math.PI;
            for (int k = 1; k < d.n; k++) {
                if (d.first && d.age[k - 1] < 250) continue;
                float[][] pts = new float[2][3];
                for (int e = 0; e < 2; e++) {
                    int i = k - 1 + e;
                    int a = Math.max(0, i - 1), b = Math.min(d.n - 1, i + 1);
                    float dx = (float) (d.x[b] - d.x[a]), dz = (float) (d.z[b] - d.z[a]);
                    float len = (float) Math.sqrt(dx * dx + dz * dz);
                    float px = len < 1e-5f ? 1f : -dz / len, pz = len < 1e-5f ? 0f : dx / len;
                    float phi = (float) ((d.now - d.age[i]) / 150.0) + ph;
                    pts[e][0] = (float) d.x[i] + px * (float) Math.cos(phi) * 0.5f;
                    pts[e][1] = (float) d.y[i] + 0.95f + (float) Math.sin(phi) * 0.6f;
                    pts[e][2] = (float) d.z[i] + pz * (float) Math.cos(phi) * 0.5f;
                }
                float fa = Math.max(0f, d.life[k - 1]), fb = Math.max(0f, d.life[k]);
                int rgbA = Colors.hsb(d.base + 0.14f * s + 0.08f * (1f - fa), 0.7f, 1f);
                int rgbB = Colors.hsb(d.base + 0.14f * s + 0.08f * (1f - fb), 0.7f, 1f);
                int ca = Colors.argb((int) (230 * fa * fa), rgbA), cb = Colors.argb((int) (230 * fb * fb), rgbB);
                float w = 0.06f;
                quad(vc, m, pts[0][0], pts[0][1] - w, pts[0][2], ca, pts[1][0], pts[1][1] - w, pts[1][2], cb,
                        pts[1][0], pts[1][1] + w, pts[1][2], cb, pts[0][0], pts[0][1] + w, pts[0][2], ca);
            }
        }
    }

    // ---------------------------------------------------------------- TargetRender (4 styles)
    /** soft glowing ribbon facing the camera; edgeFactor 0 = fully feathered, 1 = hard edges */
    private static void ribbon(VertexConsumer vc, Matrix4f m, float[] x, float[] y, float[] z, int n,
                               float width, float alpha, float edgeFactor, int rgbHead, int rgbTail) {
        float[] sx = new float[n + 1], sy = new float[n + 1], sz = new float[n + 1];
        for (int k = 0; k <= n; k++) {
            int a = Math.max(0, k - 1), b = Math.min(n, k + 1);
            float tx = x[b] - x[a], ty = y[b] - y[a], tz = z[b] - z[a];
            float cx = ty * z[k] - tz * y[k], cy = tz * x[k] - tx * z[k], cz = tx * y[k] - ty * x[k];
            float len = (float) Math.sqrt(cx * cx + cy * cy + cz * cz);
            if (len < 1e-6f) { cx = 0; cy = 1; cz = 0; len = 1; }
            sx[k] = cx / len; sy[k] = cy / len; sz[k] = cz / len;
        }
        for (int k = 0; k < n; k++) {
            float f0 = 1f - k / (float) n, f1 = 1f - (k + 1) / (float) n;
            float w0 = width * (0.2f + 0.8f * f0), w1 = width * (0.2f + 0.8f * f1);
            int rgb0 = Colors.lerp(0xFF000000 | rgbTail, 0xFF000000 | rgbHead, f0) & 0xFFFFFF;
            int rgb1 = Colors.lerp(0xFF000000 | rgbTail, 0xFF000000 | rgbHead, f1) & 0xFFFFFF;
            float a0 = alpha * (float) Math.pow(f0, 1.2), a1 = alpha * (float) Math.pow(f1, 1.2);
            int c0 = Colors.argb((int) a0, rgb0), c1 = Colors.argb((int) a1, rgb1);
            int e0 = Colors.argb((int) (a0 * edgeFactor), rgb0), e1 = Colors.argb((int) (a1 * edgeFactor), rgb1);
            float lx0 = x[k] - sx[k] * w0, ly0 = y[k] - sy[k] * w0, lz0 = z[k] - sz[k] * w0;
            float lx1 = x[k + 1] - sx[k + 1] * w1, ly1 = y[k + 1] - sy[k + 1] * w1, lz1 = z[k + 1] - sz[k + 1] * w1;
            float rx0 = x[k] + sx[k] * w0, ry0 = y[k] + sy[k] * w0, rz0 = z[k] + sz[k] * w0;
            float rx1 = x[k + 1] + sx[k + 1] * w1, ry1 = y[k + 1] + sy[k + 1] * w1, rz1 = z[k + 1] + sz[k + 1] * w1;
            quad(vc, m, lx0, ly0, lz0, e0, lx1, ly1, lz1, e1, x[k + 1], y[k + 1], z[k + 1], c1, x[k], y[k], z[k], c0);
            quad(vc, m, x[k], y[k], z[k], c0, x[k + 1], y[k + 1], z[k + 1], c1, rx1, ry1, rz1, e1, rx0, ry0, rz0, e0);
        }
    }

    private static void targetRender(VertexConsumer vc, Matrix4f m, Vec3d cam, Camera camera, float td) {
        LivingEntity e = Hud.active();
        if (e == null) return;
        Vector3f right = new Vector3f(1, 0, 0).rotate(camera.getRotation());
        Vector3f up = new Vector3f(0, 1, 0).rotate(camera.getRotation());
        float ex = (float) (MathHelper.lerp(td, e.prevX, e.getX()) - cam.x);
        float ey = (float) (MathHelper.lerp(td, e.prevY, e.getY()) - cam.y);
        float ez = (float) (MathHelper.lerp(td, e.prevZ, e.getZ()) - cam.z);
        float hgt = e.getHeight(), wid = e.getWidth();
        double now = System.currentTimeMillis();
        float h = Modules.TARGETRENDER.value;
        int tint = Colors.hsb(h, 0.55f, 1f);
        int white = Colors.hsb(h, 0.10f, 1f);

        switch (Modules.TARGETRENDER.mode) {
            case 1 -> trCircle(vc, m, ex, ey, ez, wid, now, h, tint, white);
            case 2 -> trJello(vc, m, ex, ey, ez, hgt, wid, now, tint, white);
            case 3 -> trCrystal(vc, m, ex, ey, ez, hgt, now, tint, white, right, up);
            default -> trGhost(vc, m, ex, ey + hgt * 0.5f, ez, wid, now, tint, white, right, up);
        }
    }

    // crisp comet orbs (like the reference video)
    private static void trGhost(VertexConsumer vc, Matrix4f m, float cxp, float cyp, float czp, float wid, double now,
                                int tint, int white, Vector3f right, Vector3f up) {
        float rad = 0.72f + wid * 0.3f;
        float base = (float) (now / 1000.0 * Math.PI * 2);
        float psi = (float) (now / 3800.0 * Math.PI * 2);
        float tilt = (float) Math.toRadians(52);
        float sinT = (float) Math.sin(tilt), cosT = (float) Math.cos(tilt);
        float cp = (float) Math.cos(psi), sp = (float) Math.sin(psi);
        final int n = 22;
        for (int o = 0; o < 2; o++) {
            float phase = base + o * (float) Math.PI;
            float[] tx = new float[n + 1], ty = new float[n + 1], tz = new float[n + 1];
            for (int k = 0; k <= n; k++) {
                float a = phase - k * 0.07f;
                float lx = rad * (float) Math.cos(a), l0 = rad * (float) Math.sin(a);
                float ly = l0 * sinT, lz = l0 * cosT;
                tx[k] = cxp + lx * cp + lz * sp;
                ty[k] = cyp + ly;
                tz[k] = czp - lx * sp + lz * cp;
            }
            ribbon(vc, m, tx, ty, tz, n, 0.13f, 235f, 0.30f, tint, tint);     // defined band
            ribbon(vc, m, tx, ty, tz, n, 0.045f, 255f, 0.85f, white, white);  // bright core line
            float ox = tx[0], oy = ty[0], oz = tz[0];
            glow(vc, m, ox, oy, oz, right, up, 0.20f, 16, Colors.argb(110, tint), Colors.argb(0, tint));
            glow(vc, m, ox, oy, oz, right, up, 0.11f, 16, Colors.argb(235, white), Colors.argb(0, tint));
            glow(vc, m, ox, oy, oz, right, up, 0.05f, 16, 0xFFFFFFFF, Colors.argb(255, white));
        }
    }

    // rotating ring with two comet arcs on the ground
    private static void trCircle(VertexConsumer vc, Matrix4f m, float x, float y, float z, float wid, double now, float h,
                                 int tint, int white) {
        float r = wid * 0.5f + 0.55f + (float) Math.sin(now / 350.0) * 0.04f;
        float yy = y + 0.03f;
        float spin = (float) (now / 700.0 * Math.PI * 2);
        ring(vc, m, x, yy, z, r - 0.02f, r + 0.02f, Colors.argb(70, tint), Colors.argb(70, tint));
        for (int i = 0; i < 2; i++) {
            float head = spin + i * (float) Math.PI;
            float len = 2.1f;
            arc(vc, m, x, yy + 0.002f, z, r - 0.07f, r + 0.07f, head - len, len, 40,
                    Colors.argb(0, tint), Colors.argb(0, tint), Colors.argb(235, white), Colors.argb(200, tint));
        }
        ring(vc, m, x, yy, z, r + 0.07f, r + 0.30f, Colors.argb(55, tint), Colors.argb(0, tint));
    }

    // ring sweeping up and down the body, leaving a glowing curtain behind it
    private static void trJello(VertexConsumer vc, Matrix4f m, float x, float y, float z, float hgt, float wid, double now,
                                int tint, int white) {
        float r = wid * 0.5f + 0.32f;
        float ph = (float) (now / 1000.0 * 2.4);
        float f = 0.5f + 0.5f * (float) Math.sin(ph);            // 0..1
        float dir = (float) Math.cos(ph) >= 0 ? 1f : -1f;         // +1 moving up
        float ry = y + 0.05f + f * (hgt - 0.1f);
        float trail = 0.65f;
        final int n = 40;
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0) * r, s0 = (float) Math.sin(a0) * r, c1 = (float) Math.cos(a1) * r, s1 = (float) Math.sin(a1) * r;
            float yt = ry - dir * trail;
            quad(vc, m, x + c0, ry, z + s0, Colors.argb(150, tint), x + c1, ry, z + s1, Colors.argb(150, tint),
                    x + c1, yt, z + s1, Colors.argb(0, tint), x + c0, yt, z + s0, Colors.argb(0, tint));
        }
        ring(vc, m, x, ry, z, r - 0.045f, r + 0.045f, Colors.argb(255, white), Colors.argb(255, white));
        ring(vc, m, x, ry, z, r + 0.045f, r + 0.15f, Colors.argb(120, tint), Colors.argb(0, tint));
    }

    // spinning crystal above the head
    private static void trCrystal(VertexConsumer vc, Matrix4f m, float x, float y, float z, float hgt, double now,
                                  int tint, int white, Vector3f right, Vector3f up) {
        float cy = y + hgt + 0.55f + (float) Math.sin(now / 420.0) * 0.06f;
        float spin = (float) (now / 1000.0 * 2.4);
        float rw = 0.17f, hh = 0.30f;
        float[] px = new float[4], pz = new float[4];
        for (int i = 0; i < 4; i++) {
            px[i] = x + (float) Math.cos(spin + i * Math.PI / 2) * rw;
            pz[i] = z + (float) Math.sin(spin + i * Math.PI / 2) * rw;
        }
        int top = Colors.argb(235, white), mid = Colors.argb(190, tint), bot = Colors.argb(150, tint);
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            int shade = (i % 2 == 0) ? mid : Colors.argb(140, tint);
            tri(vc, m, x, cy + hh, z, top, px[i], cy, pz[i], shade, px[j], cy, pz[j], shade);
            tri(vc, m, x, cy - hh, z, bot, px[i], cy, pz[i], shade, px[j], cy, pz[j], shade);
        }
        glow(vc, m, x, cy, z, right, up, 0.45f, 18, Colors.argb(70, tint), Colors.argb(0, tint));
        glow(vc, m, x, cy, z, right, up, 0.12f, 12, Colors.argb(200, white), Colors.argb(0, tint));
    }

    // ================================================================ shared billboard helpers
    private static void bring(VertexConsumer vc, Matrix4f m, float x, float y, float z, Vector3f r, Vector3f u,
                              float rIn, float rOut, int n, int cIn, int cOut) {
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            quad(vc, m,
                    x + (r.x * c0 + u.x * s0) * rIn, y + (r.y * c0 + u.y * s0) * rIn, z + (r.z * c0 + u.z * s0) * rIn, cIn,
                    x + (r.x * c1 + u.x * s1) * rIn, y + (r.y * c1 + u.y * s1) * rIn, z + (r.z * c1 + u.z * s1) * rIn, cIn,
                    x + (r.x * c1 + u.x * s1) * rOut, y + (r.y * c1 + u.y * s1) * rOut, z + (r.z * c1 + u.z * s1) * rOut, cOut,
                    x + (r.x * c0 + u.x * s0) * rOut, y + (r.y * c0 + u.y * s0) * rOut, z + (r.z * c0 + u.z * s0) * rOut, cOut);
        }
    }

    /** 4-point star facing the camera */
    private static void star(VertexConsumer vc, Matrix4f m, float x, float y, float z, Vector3f r, Vector3f u,
                             float size, float rot, int cCenter, int cEdge) {
        float[] px = new float[8], py = new float[8], pz = new float[8];
        for (int i = 0; i < 8; i++) {
            float a = rot + i * (float) Math.PI / 4f;
            float rad = (i % 2 == 0) ? size : size * 0.28f;
            float c = (float) Math.cos(a) * rad, s = (float) Math.sin(a) * rad;
            px[i] = x + r.x * c + u.x * s; py[i] = y + r.y * c + u.y * s; pz[i] = z + r.z * c + u.z * s;
        }
        for (int i = 0; i < 8; i++) {
            int j = (i + 1) % 8;
            tri(vc, m, x, y, z, cCenter, px[i], py[i], pz[i], cEdge, px[j], py[j], pz[j], cEdge);
        }
    }

    private static Vector3f camRight(Camera c) { return new Vector3f(1, 0, 0).rotate(c.getRotation()); }
    private static Vector3f camUp(Camera c) { return new Vector3f(0, 1, 0).rotate(c.getRotation()); }

    // ================================================================ Hit Particles (Burst / Stars / Ring)
    private static void hitFx(VertexConsumer vc, Matrix4f m, Vec3d cam, Camera camera) {
        Vector3f right = camRight(camera), up = camUp(camera);
        long now = System.currentTimeMillis();
        for (Iterator<HitFx> it = HITS.iterator(); it.hasNext(); ) {
            HitFx h = it.next();
            long life = h.mode == 0 ? 700 : (h.mode == 1 ? 950 : 600);
            long age = now - h.start;
            if (age >= life) { it.remove(); continue; }
            float t = age / (float) life, ts = age / 1000f;
            float cx = (float) (h.x - cam.x), cy = (float) (h.y - cam.y), cz = (float) (h.z - cam.z);

            if (h.mode == 0) {                       // Burst: radial glowing sparks with gravity
                for (int i = 0; i < 18; i++) {
                    float u1 = rnd(h.seed, i * 5) * 2f - 1f, phi = rnd(h.seed, i * 5 + 1) * (float) (Math.PI * 2);
                    float rr = (float) Math.sqrt(1f - u1 * u1);
                    float speed = 2.2f + 2.4f * rnd(h.seed, i * 5 + 2);
                    float px = cx + rr * (float) Math.cos(phi) * speed * ts;
                    float py = cy + u1 * speed * ts - 3.2f * ts * ts;
                    float pz = cz + rr * (float) Math.sin(phi) * speed * ts;
                    int rgb = Colors.hsb(h.hue + 0.08f * rnd(h.seed, i * 5 + 3), 0.65f, 1f);
                    float size = 0.075f * (1f - t) + 0.012f;
                    int a = (int) (255 * Math.pow(1f - t, 1.1));
                    glow(vc, m, px, py, pz, right, up, size * 2.6f, 8, Colors.argb(a / 3, rgb), Colors.argb(0, rgb));
                    glow(vc, m, px, py, pz, right, up, size, 8, Colors.argb(a, 0xFFFFFF), Colors.argb(a / 2, rgb));
                }
            } else if (h.mode == 1) {                // Stars: spinning 4-point stars floating up
                for (int i = 0; i < 7; i++) {
                    float u1 = 0.35f + rnd(h.seed, i * 5) * 0.65f, phi = rnd(h.seed, i * 5 + 1) * (float) (Math.PI * 2);
                    float rr = (float) Math.sqrt(1f - u1 * u1);
                    float speed = 1.2f + 1.4f * rnd(h.seed, i * 5 + 2);
                    float px = cx + rr * (float) Math.cos(phi) * speed * ts;
                    float py = cy + u1 * speed * ts - 0.8f * ts * ts;
                    float pz = cz + rr * (float) Math.sin(phi) * speed * ts;
                    int rgb = Colors.hsb(h.hue + 0.10f * rnd(h.seed, i * 5 + 3), 0.55f, 1f);
                    float size = 0.17f * (1f - 0.55f * t);
                    float rot = rnd(h.seed, i * 5 + 4) * 6.28f + ts * (2f + 3f * rnd(h.seed, i * 5 + 4));
                    int a = (int) (255 * Math.pow(1f - t, 0.9));
                    glow(vc, m, px, py, pz, right, up, size * 1.4f, 10, Colors.argb(a / 4, rgb), Colors.argb(0, rgb));
                    star(vc, m, px, py, pz, right, up, size, rot, Colors.argb(a, 0xFFFFFF), Colors.argb(a * 3 / 4, rgb));
                }
            } else {                                  // Ring: expanding shockwave + flash + sparks
                float ease = 1f - (float) Math.pow(1f - t, 3);
                float rad = 0.15f + 1.1f * ease;
                int rgb = Colors.hsb(h.hue, 0.6f, 1f);
                int a = (int) (240 * (1f - t));
                float w = 0.09f * (1f - t) + 0.02f;
                bring(vc, m, cx, cy, cz, right, up, rad - w, rad, 40, Colors.argb(0, rgb), Colors.argb(a, rgb));
                bring(vc, m, cx, cy, cz, right, up, rad, rad + w * 0.6f, 40, Colors.argb(a, 0xFFFFFF), Colors.argb(0, rgb));
                if (t < 0.3f) {
                    float f = 1f - t / 0.3f;
                    glow(vc, m, cx, cy, cz, right, up, 0.55f * f, 16, Colors.argb((int) (230 * f), 0xFFFFFF), Colors.argb(0, rgb));
                }
                for (int i = 0; i < 8; i++) {
                    float ang = i * (float) Math.PI / 4f + rnd(h.seed, i) * 0.4f;
                    float d = (0.3f + 1.6f * ease) * (0.8f + 0.4f * rnd(h.seed, i + 20));
                    float px = cx + (right.x * (float) Math.cos(ang) + up.x * (float) Math.sin(ang)) * d;
                    float py = cy + (right.y * (float) Math.cos(ang) + up.y * (float) Math.sin(ang)) * d;
                    float pz = cz + (right.z * (float) Math.cos(ang) + up.z * (float) Math.sin(ang)) * d;
                    glow(vc, m, px, py, pz, right, up, 0.045f * (1f - t) + 0.01f, 6, Colors.argb(a, 0xFFFFFF), Colors.argb(a / 2, rgb));
                }
            }
        }
    }

    // ================================================================ World Particles (Snow / Fireflies / Magic)
    private static void worldParticles(VertexConsumer vc, Matrix4f m, Vec3d cam, Camera camera) {
        Modules.Module wp = Modules.WORLDPARTICLES;
        Vector3f right = camRight(camera), up = camUp(camera);
        final int mode = wp.mode;
        final int n = mode == 0 ? 260 : (mode == 1 ? 80 : 140);
        final float rx = mode == 0 ? 16f : (mode == 1 ? 11f : 12f);
        final float ry = mode == 0 ? 10f : (mode == 1 ? 6f : 7f);
        final double sx = rx * 2, sy = ry * 2;
        final double t = System.currentTimeMillis() / 1000.0;
        for (int i = 0; i < n; i++) {
            long seed = i * 7919L + 13;
            double bx = rnd(seed, 0) * sx, by = rnd(seed, 1) * sy, bz = rnd(seed, 2) * sx;
            double vx, vy, vz, wob, ph = rnd(seed, 4) * 6.2832;
            if (mode == 0) {            // snow
                vx = (rnd(seed, 5) - 0.5) * 0.5; vy = -(0.7 + 0.9 * rnd(seed, 3)); vz = (rnd(seed, 6) - 0.5) * 0.5; wob = 0.35;
            } else if (mode == 1) {     // fireflies
                vx = (rnd(seed, 5) - 0.5) * 0.35; vy = (rnd(seed, 3) - 0.5) * 0.2; vz = (rnd(seed, 6) - 0.5) * 0.35; wob = 0.7;
            } else {                    // magic
                vx = (rnd(seed, 5) - 0.5) * 0.3; vy = 0.25 + 0.45 * rnd(seed, 3); vz = (rnd(seed, 6) - 0.5) * 0.3; wob = 0.4;
            }
            double px = bx + vx * t + Math.sin(t * 0.8 + ph) * wob;
            double py = by + vy * t + Math.cos(t * 0.6 + ph) * wob * 0.6;
            double pz = bz + vz * t + Math.sin(t * 0.7 + ph * 1.3) * wob;
            double ax = px - cam.x + rx, ay = py - cam.y + ry, az = pz - cam.z + rx;
            float relx = (float) (ax - sx * Math.floor(ax / sx) - rx);
            float rely = (float) (ay - sy * Math.floor(ay / sy) - ry);
            float relz = (float) (az - sx * Math.floor(az / sx) - rx);

            float edge = Math.max(Math.max(Math.abs(relx) / rx, Math.abs(relz) / rx), Math.abs(rely) / ry);
            float fade = Math.min(1f, (1f - edge) * 4f);
            float dist = (float) Math.sqrt(relx * relx + rely * rely + relz * relz);
            if (dist < 1.6f) fade *= dist / 1.6f;
            if (fade <= 0.02f) continue;

            if (mode == 0) {
                float size = 0.03f + 0.04f * rnd(seed, 7);
                int a = (int) (235 * fade);
                int rgb = Colors.hsb(wp.value, 0.08f, 1f);
                glow(vc, m, relx, rely, relz, right, up, size, 6, Colors.argb(a, 0xFFFFFF), Colors.argb(a * 3 / 4, rgb));
            } else if (mode == 1) {
                float blink = 0.3f + 0.7f * (0.5f + 0.5f * (float) Math.sin(t * 2.0 + ph * 3.0));
                int rgb = Colors.hsb(wp.value, 0.7f, 1f);
                glow(vc, m, relx, rely, relz, right, up, 0.28f * blink + 0.05f, 10, Colors.argb((int) (80 * fade * blink), rgb), Colors.argb(0, rgb));
                glow(vc, m, relx, rely, relz, right, up, 0.045f, 8, Colors.argb((int) (255 * fade * blink), 0xFFFFFF), Colors.argb((int) (200 * fade * blink), rgb));
            } else {
                float tw = 0.5f + 0.5f * (float) Math.sin(t * 3.0 + ph * 2.0);
                float size = 0.05f + 0.06f * rnd(seed, 7);
                int rgb = Colors.hsb(wp.value + 0.18f * rnd(seed, 8), 0.6f, 1f);
                int a = (int) (255 * fade * (0.4f + 0.6f * tw));
                glow(vc, m, relx, rely, relz, right, up, size * 2.4f, 8, Colors.argb(a / 3, rgb), Colors.argb(0, rgb));
                star(vc, m, relx, rely, relz, right, up, size * 1.3f, (float) (t * 1.5 + ph), Colors.argb(a, 0xFFFFFF), Colors.argb(a * 2 / 3, rgb));
            }
        }
    }

    // ================================================================ Prediction (bow / crossbow / trident / pearls / potions ...)
    /** returns {speed, gravity, pitchOffset} or null when nothing to predict */
    private static float[] projectileParams(PlayerEntity p) {
        ItemStack active = p.isUsingItem() ? p.getActiveItem() : ItemStack.EMPTY;
        if (!active.isEmpty()) {
            if (active.isOf(Items.BOW)) {
                int use = active.getMaxUseTime(p) - p.getItemUseTimeLeft();
                float pw = BowItem.getPullProgress(use);
                if (pw < 0.1f) return null;
                return new float[]{pw * 3.0f, 0.05f, 0f};
            }
            if (active.isOf(Items.TRIDENT)) {
                int use = active.getMaxUseTime(p) - p.getItemUseTimeLeft();
                if (use < 10) return null;
                return new float[]{2.5f, 0.05f, 0f};
            }
            return null;
        }
        for (ItemStack s : new ItemStack[]{p.getMainHandStack(), p.getOffHandStack()}) {
            if (s.isEmpty()) continue;
            if (s.isOf(Items.CROSSBOW) && CrossbowItem.isCharged(s)) return new float[]{3.15f, 0.05f, 0f};
            if (s.isOf(Items.ENDER_PEARL) || s.isOf(Items.SNOWBALL) || s.isOf(Items.EGG)) return new float[]{1.5f, 0.03f, 0f};
            if (s.isOf(Items.SPLASH_POTION) || s.isOf(Items.LINGERING_POTION)) return new float[]{0.5f, 0.05f, -20f};
            if (s.isOf(Items.EXPERIENCE_BOTTLE)) return new float[]{0.7f, 0.07f, -20f};
        }
        return null;
    }

    private static void prediction(VertexConsumer vc, Matrix4f m, MinecraftClient mc, Vec3d cam, Camera camera, float td) {
        PlayerEntity p = mc.player;
        float[] pr = projectileParams(p);
        if (pr == null) return;
        float speed = pr[0], grav = pr[1];
        float pitch = MathHelper.lerp(td, p.prevPitch, p.getPitch()) + pr[2];
        float yaw = MathHelper.lerp(td, p.prevYaw, p.getYaw());
        Vec3d dir = Vec3d.fromPolar(pitch, yaw);
        Vec3d pos = new Vec3d(MathHelper.lerp(td, p.prevX, p.getX()),
                MathHelper.lerp(td, p.prevY, p.getY()) + p.getStandingEyeHeight() - 0.1, MathHelper.lerp(td, p.prevZ, p.getZ()));
        Vec3d pv = p.getVelocity();
        Vec3d vel = new Vec3d(dir.x * speed + pv.x, dir.y * speed + (p.isOnGround() ? 0 : pv.y), dir.z * speed + pv.z);

        final int max = 300;
        float[] x = new float[max + 1], y = new float[max + 1], z = new float[max + 1];
        int n = 0;
        x[0] = (float) (pos.x - cam.x); y[0] = (float) (pos.y - cam.y); z[0] = (float) (pos.z - cam.z);
        boolean hit = false;
        for (int i = 0; i < max; i++) {
            Vec3d next = pos.add(vel);
            BlockHitResult br = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, p));
            if (br.getType() != HitResult.Type.MISS) {
                next = br.getPos();
                hit = true;
            }
            n++;
            x[n] = (float) (next.x - cam.x); y[n] = (float) (next.y - cam.y); z[n] = (float) (next.z - cam.z);
            if (hit) break;
            pos = next;
            vel = new Vec3d(vel.x * 0.99, vel.y * 0.99 - grav, vel.z * 0.99);
        }
        if (n < 1) return;

        Vector3f right = camRight(camera), up = camUp(camera);
        float h = Modules.PREDICTION.value;
        int rgb = Colors.hsb(h, 0.6f, 1f);
        int white = Colors.hsb(h, 0.12f, 1f);

        if (Modules.PREDICTION.mode == 0) {
            predLine(vc, m, x, y, z, n, 0.022f, rgb, white);
        } else {
            for (int i = 2; i <= n; i += 2) {
                float f = i / (float) n;
                glow(vc, m, x[i], y[i], z[i], right, up, 0.06f, 8, Colors.argb((int) (240 * (0.5f + 0.5f * f)), white), Colors.argb(120, rgb));
            }
        }
        // landing marker
        if (hit) {
            float pulse = 1f + 0.12f * (float) Math.sin(System.currentTimeMillis() / 160.0);
            float r0 = 0.22f * pulse;
            bring(vc, m, x[n], y[n], z[n], right, up, r0 - 0.035f, r0, 28, Colors.argb(0, rgb), Colors.argb(255, rgb));
            bring(vc, m, x[n], y[n], z[n], right, up, r0, r0 + 0.02f, 28, Colors.argb(255, white), Colors.argb(0, rgb));
            glow(vc, m, x[n], y[n], z[n], right, up, 0.08f, 10, 0xFFFFFFFF, Colors.argb(200, rgb));
        }
    }

    private static void predLine(VertexConsumer vc, Matrix4f m, float[] x, float[] y, float[] z, int n, float w, int rgb, int white) {
        float[] sx = new float[n + 1], sy = new float[n + 1], sz = new float[n + 1];
        for (int k = 0; k <= n; k++) {
            int a = Math.max(0, k - 1), b = Math.min(n, k + 1);
            float tx = x[b] - x[a], ty = y[b] - y[a], tz = z[b] - z[a];
            float cx = ty * z[k] - tz * y[k], cy = tz * x[k] - tx * z[k], cz = tx * y[k] - ty * x[k];
            float len = (float) Math.sqrt(cx * cx + cy * cy + cz * cz);
            if (len < 1e-6f) { cx = 0; cy = 1; cz = 0; len = 1; }
            sx[k] = cx / len; sy[k] = cy / len; sz[k] = cz / len;
        }
        for (int k = 0; k < n; k++) {
            float f0 = k / (float) n, f1 = (k + 1) / (float) n;
            int c0 = Colors.lerp(Colors.argb(235, rgb), Colors.argb(255, white), f0);
            int c1 = Colors.lerp(Colors.argb(235, rgb), Colors.argb(255, white), f1);
            int e0 = c0 & 0xFFFFFF, e1 = c1 & 0xFFFFFF;                 // transparent feathered edges
            float w0 = w * 2.4f, w1 = w * 2.4f;
            quad(vc, m, x[k] - sx[k] * w0, y[k] - sy[k] * w0, z[k] - sz[k] * w0, e0,
                    x[k + 1] - sx[k + 1] * w1, y[k + 1] - sy[k + 1] * w1, z[k + 1] - sz[k + 1] * w1, e1,
                    x[k + 1], y[k + 1], z[k + 1], c1, x[k], y[k], z[k], c0);
            quad(vc, m, x[k], y[k], z[k], c0, x[k + 1], y[k + 1], z[k + 1], c1,
                    x[k + 1] + sx[k + 1] * w1, y[k + 1] + sy[k + 1] * w1, z[k + 1] + sz[k + 1] * w1, e1,
                    x[k] + sx[k] * w0, y[k] + sy[k] * w0, z[k] + sz[k] * w0, e0);
        }
    }
}
