package kz.alih.visuals.mixin;

import kz.alih.visuals.replacer.ReplacerSwap;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ItemModelManager.class)
public abstract class ItemModelManagerMixin {
    @ModifyVariable(method = "update", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private ItemStack alih$replaceSword(ItemStack stack) {
        return ReplacerSwap.swap(stack);
    }
}
