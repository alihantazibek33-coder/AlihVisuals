package kz.alih.visuals.knives;

import java.util.List;

public final class KnifeData {
    /** defaults = {scale, x, y, z, pitch, yaw, roll} */
    public record Knife(String id, String name, boolean dual, float grip, float inspectSeconds, float[] defaults) {}
    public record Skin(String id, String name, int rgb) {}

    private static float[] d(float scale, float pitch, float yaw, float roll) {
        return new float[]{scale, 0.04f, 0.02f, 0f, pitch, yaw, roll};
    }

    public static final List<Knife> KNIVES = List.of(
            new Knife("bayonet", "Штык-нож", false, 4.6f, 3.2f, d(0.5f, -80f, 22f, 180f)),
            new Knife("flip", "Складной нож", false, 5.0f, 3.4f, d(0.5f, -80f, 22f, 180f)),
            new Knife("gut", "Нож с лезвием-крюком", false, 4.8f, 3.0f, d(0.5f, -80f, 22f, 180f)),
            new Knife("karambit", "Керамбит", false, 3.6f, 3.6f, d(0.5f, -120f, 18f, 180f)),
            new Knife("m9", "Штык-нож M9", false, 4.7f, 3.4f, d(0.5f, -80f, 22f, 180f)),
            new Knife("huntsman", "Охотничий нож", false, 4.8f, 3.2f, d(0.5f, -80f, 22f, 180f)),
            new Knife("butterfly", "Нож-бабочка", false, 4.8f, 5.0f, d(0.5f, -80f, 22f, 180f)),
            new Knife("falchion", "Фальшион", false, 5.0f, 3.4f, d(0.5f, -80f, 22f, 180f)),
            new Knife("shadow", "Тычковые ножи", true, 2.0f, 3.2f, d(0.55f, -90f, 12f, 180f)),
            new Knife("bowie", "Нож Боуи", false, 5.2f, 3.2f, d(0.5f, -80f, 22f, 180f)));

    public static final List<Skin> SKINS = List.of(
            new Skin("stainless", "Тот баспайтын болат", 0xFFB8BEC8), new Skin("blue", "Көк болат", 0xFF3C5888),
            new Skin("fade", "Градиент", 0xFFEC468C), new Skin("marble", "Мәрмәр", 0xFF8A46C8),
            new Skin("tiger", "Жолбарыс", 0xFFD6A83E), new Skin("web", "Қызыл тор", 0xFFB41E2A),
            new Skin("slaughter", "Қанды", 0xFFE06428), new Skin("damascus", "Дамаск", 0xFF9CA2B0),
            new Skin("case", "Шыңдалған", 0xFF4678BE), new Skin("camo", "Камуфляж", 0xFF5C6C3C),
            new Skin("night", "Түн", 0xFF1C1C26), new Skin("gold", "Алтын", 0xFFE6B648));

    public static Knife byId(String id) {
        for (Knife k : KNIVES) if (k.id().equals(id)) return k;
        return null;
    }

    private KnifeData() {}
}
