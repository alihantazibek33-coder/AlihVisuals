package kz.alih.visuals.knives;

import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/** Which CS-style knife replaces your swords (only you see it), its skin and its position in the hand. */
public final class KnifeState {
    private static final KnifeState I = new KnifeState();
    public static KnifeState get() { return I; }

    public boolean enabled = true;
    public String selected = "";                       // "" = normal swords
    public long inspectStart = -100_000L;
    public long stabStart = -100_000L;                 // right click = stab (visual only)
    public long drawStart = -100_000L;                 // set when the knife is taken into the hand
    public int swingId = 0;                            // counts attacks: even / odd = which slash direction (or which dagger)
    private float lastSwing = 0f, lastEquip = 0f;
    private final Map<String, String> skins = new HashMap<>();
    private final Map<String, float[]> transforms = new HashMap<>();

    private KnifeState() {}

    private Path file() { return FabricLoader.getInstance().getConfigDir().resolve("alihvisuals").resolve("knives.properties"); }

    public boolean active() { return enabled && !selected.isEmpty() && KnifeData.byId(selected) != null; }

    public KnifeData.Knife knife() { return active() ? KnifeData.byId(selected) : null; }

    public String skin(String knifeId) { return skins.getOrDefault(knifeId, "stainless"); }

    public void setSkin(String knifeId, String skinId) { skins.put(knifeId, skinId); }

    public float[] transform(KnifeData.Knife k) {
        return transforms.computeIfAbsent(k.id(), id -> k.defaults().clone());
    }

    public void resetTransform(KnifeData.Knife k) { transforms.put(k.id(), k.defaults().clone()); }

    public void inspect() { inspectStart = System.currentTimeMillis(); }

    public void stab() { stabStart = System.currentTimeMillis(); }

    /** called once per frame for the main hand: detects a new attack and the moment the knife is drawn */
    public void observe(float swing, float equip) {
        if (swing > 0f && lastSwing <= 0f) swingId++;
        lastSwing = swing;
        if (lastEquip > 0.9f && equip < 0.9f) drawStart = System.currentTimeMillis();
        lastEquip = equip;
    }

    public void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Properties p = new Properties();
            try (var in = Files.newInputStream(f)) { p.load(in); }
            enabled = Boolean.parseBoolean(p.getProperty("enabled", "true"));
            selected = p.getProperty("selected", "");
            for (KnifeData.Knife k : KnifeData.KNIVES) {
                String s = p.getProperty("skin." + k.id());
                if (s != null) skins.put(k.id(), s);
                String t = p.getProperty("t." + k.id());
                if (t != null) {
                    String[] parts = t.split(",");
                    float[] v = k.defaults().clone();
                    for (int i = 0; i < v.length && i < parts.length; i++) v[i] = Float.parseFloat(parts[i].trim());
                    transforms.put(k.id(), v);
                }
            }
        } catch (Exception ignored) {}
    }

    public void save() {
        try {
            Files.createDirectories(file().getParent());
            Properties p = new Properties();
            p.setProperty("enabled", String.valueOf(enabled));
            p.setProperty("selected", selected);
            skins.forEach((k, v) -> p.setProperty("skin." + k, v));
            transforms.forEach((k, v) -> {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < v.length; i++) sb.append(i == 0 ? "" : ",").append(v[i]);
                p.setProperty("t." + k, sb.toString());
            });
            try (var out = Files.newOutputStream(file())) { p.store(out, "AlihVisuals knives"); }
        } catch (Exception ignored) {}
    }
}
