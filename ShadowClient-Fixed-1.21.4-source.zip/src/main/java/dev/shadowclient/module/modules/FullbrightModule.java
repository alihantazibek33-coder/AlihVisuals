package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class FullbrightModule extends ClientModule {
    public FullbrightModule() { super("Fullbright", "Raises client gamma for improved visibility.", ModuleCategory.VISUALS); }
}
