package dev.shadowclient.module;

import dev.shadowclient.module.modules.*;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<ClientModule> MODULES = new ArrayList<>();
    private ModuleManager() {}

    public static void init() {
        if (!MODULES.isEmpty()) return;
        MODULES.add(new CoordinatesModule());
        MODULES.add(new FpsModule());
        MODULES.add(new ClockModule());
        MODULES.add(new ArmorStatusModule());
        MODULES.add(new PotionStatusModule());
        MODULES.add(new KeystrokesModule());
        MODULES.add(new CrosshairModule());
        MODULES.add(new FullbrightModule());
        MODULES.add(new ZoomModule());
        MODULES.add(new FreelookModule());
        MODULES.add(new ClearChatModule());
        MODULES.add(new AutoSprintModule());
        MODULES.add(new ToggleSprintModule());
        MODULES.add(new ItemCountModule());
        MODULES.add(new DirectionModule());
        MODULES.add(new WeatherInfoModule());
        MODULES.add(new WorldTimeModule());
        MODULES.add(new PingModule());
        MODULES.add(new ScreenshotToastModule());
        MODULES.add(new ThemeModule());
    }

    public static List<ClientModule> all() { return List.copyOf(MODULES); }
    public static List<ClientModule> inCategory(ModuleCategory category) {
        return MODULES.stream().filter(m -> m.category() == category).toList();
    }
    public static <T extends ClientModule> T get(Class<T> type) {
        for (ClientModule module : MODULES) if (type.isInstance(module)) return type.cast(module);
        return null;
    }
}
