package kz.alih.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class AlihMenu extends Screen {
    private static final int PAD = 14, GAP = 10, RGAP = 6, HEAD = 58, FOOT = 24, CARD_H = 40;
    private static final int CYAN = 0xFF5CE1FF, CYAN_DIM = 0xFF3FA9C9;
    private static final long LONG_PRESS_MS = 450;

    private static float savedScroll = 0f;

    private int px, py, pw, ph, cardW, gx, viewTop, viewBottom;
    private float scroll, maxScroll;
    private long last = System.nanoTime();
    private final long openedAt = System.currentTimeMillis();

    // grid press / drag-scroll / long press
    private boolean pressActive, moved;
    private int pressCard = -1;
    private double pressY;
    private long pressTime;

    // settings popup (right click / long press on a card)
    private int popFor = -1;
    private int popX, popY, popW, popH;
    private final List<W> widgets = new ArrayList<>();
    private W dragW;

    private static final int T_PRIMARY = 0, T_EXTRA = 1, T_MODE = 2, T_RESET = 3, T_CLOSE = 4;

    private static final class W {
        final int type, k, x, y, w, h;   // x,y relative to popup origin
        W(int type, int k, int x, int y, int w, int h) { this.type = type; this.k = k; this.x = x; this.y = y; this.w = w; this.h = h; }
    }

    public AlihMenu() { super(Text.literal("AlihVisuals")); scroll = savedScroll; }

    @Override
    protected void init() { layout(); }

    private void layout() {
        pw = Math.min(width - 10, Math.max(340, (int) (width * 0.55)));
        ph = Math.min(height - 10, Math.max(300, (int) (height * 0.72)));
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cardW = (pw - PAD * 2 - GAP) / 2;
        gx = px + PAD;
        viewTop = py + HEAD - 4;
        viewBottom = py + ph - FOOT;
        int rows = (Modules.ALL.size() + 1) / 2;
        int content = rows * CARD_H + (rows - 1) * RGAP;
        maxScroll = Math.max(0, content - (viewBottom - (py + HEAD)) + 4);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        if (popFor >= 0) buildPopup(Modules.ALL.get(popFor));
    }

    private int cx(int i) { return gx + (i % 2) * (cardW + GAP); }
    private int cy(int i) { return py + HEAD - (int) scroll + (i / 2) * (CARD_H + RGAP); }
    private boolean inView(double my) { return my >= viewTop && my < viewBottom; }

    // ---------------------------------------------------------------- popup layout
    private void buildPopup(Modules.Module m) {
        widgets.clear();
        int sliders = (m.hasSetting() ? 1 : 0) + m.extras.size();
        boolean two = sliders >= 5;
        popW = Math.min(pw - 16, two ? 330 : 270);
        int inner = popW - 24;
        int colW = two ? (inner - 12) / 2 : inner;
        int y = 34, idx = 0;
        if (m.hasSetting()) {
            int col = two ? idx % 2 : 0, row = two ? idx / 2 : idx;
            widgets.add(new W(T_PRIMARY, -1, 12 + col * (colW + 12), y + row * 30 + 12, colW, 6));
            idx++;
        }
        for (int k = 0; k < m.extras.size(); k++, idx++) {
            int col = two ? idx % 2 : 0, row = two ? idx / 2 : idx;
            widgets.add(new W(T_EXTRA, k, 12 + col * (colW + 12), y + row * 30 + 12, colW, 6));
        }
        int rowsUsed = two ? (sliders + 1) / 2 : sliders;
        y += rowsUsed * 30 + (sliders > 0 ? 4 : 0);
        if (m.modes != null) {
            int n = m.modes.length, gap = 6;
            int cw = (inner - gap * (n - 1)) / n;
            for (int k = 0; k < n; k++) widgets.add(new W(T_MODE, k, 12 + k * (cw + gap), y + 12, cw, 18));
            y += 40;
        }
        if (m.resettable) {
            widgets.add(new W(T_RESET, 0, 12, y, inner, 20));
            y += 26;
        }
        widgets.add(new W(T_CLOSE, 0, popW - 24, 6, 16, 16));
        popH = y + 8;
        popX = px + (pw - popW) / 2;
        popY = Math.max(py + 6, py + (ph - popH) / 2);
    }

    private W widgetAt(double mx, double my) {
        for (W w : widgets) {
            int x = popX + w.x, y = popY + w.y;
            if (w.type == T_PRIMARY || w.type == T_EXTRA) {
                if (mx >= x - 5 && mx <= x + w.w + 5 && my >= y - 8 && my <= y + w.h + 8) return w;
            } else if (mx >= x && mx < x + w.w && my >= y && my < y + w.h) return w;
        }
        return null;
    }

    private void sliderTo(W w, double mx) {
        Modules.Module m = Modules.ALL.get(popFor);
        float t = (float) ((mx - (popX + w.x)) / w.w);
        if (w.type == T_PRIMARY) m.setNorm(t); else m.extras.get(w.k).setNorm(t);
    }

    // ---------------------------------------------------------------- rendering
    @Override public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, 0xB0090B10);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();
        long now = System.nanoTime();
        float dt = (now - last) / 1e9f;
        last = now;
        float k = 1f - (float) Math.exp(-dt * 14f);

        // long press on a card -> settings (touch screens)
        if (pressActive && !moved && pressCard >= 0 && popFor < 0
                && System.currentTimeMillis() - pressTime > LONG_PRESS_MS) {
            if (Modules.ALL.get(pressCard).hasAnySettings()) openPopup(pressCard);
            pressActive = false; pressCard = -1;
        }

        Gfx.rrect(c, px - 1, py - 1, pw + 2, ph + 2, 11, 0xFF2C313C);
        Gfx.rrect(c, px, py, pw, ph, 10, 0xF01A1D24);
        c.fillGradient(px + 6, py + 2, px + pw - 6, py + 34, 0x2A5CE1FF, 0x00000000);

        MatrixStack ms = c.getMatrices();
        ms.push();
        ms.translate(px + pw / 2f, py + 11, 0);
        ms.scale(2f, 2f, 1f);
        c.drawCenteredTextWithShadow(textRenderer, "AlihVisuals", 0, 0, CYAN);
        ms.pop();
        c.drawCenteredTextWithShadow(textRenderer, "visual client", px + pw / 2, py + 32, 0xFF7C8494);

        int lw = pw - 60, n = 60;
        for (int i = 0; i < n; i++) {
            float a = (float) Math.sin(Math.PI * (i + 0.5) / n);
            int x1 = px + 30 + lw * i / n, x2 = px + 30 + lw * (i + 1) / n;
            c.fill(x1, py + 46, x2, py + 47, Colors.argb((int) (255 * a), 0x5CE1FF));
        }
        Gfx.circle(c, px + 14, py + 14, 2.5f, CYAN_DIM);
        Gfx.circle(c, px + pw - 14, py + 14, 2.5f, CYAN_DIM);

        List<Modules.Module> all = Modules.ALL;
        c.enableScissor(px + 2, viewTop, px + pw - 2, viewBottom);
        for (int i = 0; i < all.size(); i++) {
            Modules.Module m = all.get(i);
            m.anim += ((m.enabled ? 1f : 0f) - m.anim) * k;
            int y = cy(i);
            if (y + CARD_H < viewTop || y > viewBottom) continue;
            drawCard(c, m, cx(i), y, popFor < 0 ? mx : -1, my);
        }
        c.disableScissor();

        if (maxScroll > 0) {
            int trackH = viewBottom - viewTop;
            int barH = Math.max(20, (int) (trackH * trackH / (trackH + maxScroll)));
            int barY = viewTop + (int) ((trackH - barH) * (scroll / maxScroll));
            Gfx.rrect(c, px + pw - 8, barY, 3, barH, 1, 0xFF3FA9C9);
        }

        c.drawCenteredTextWithShadow(textRenderer, "ПКМ / ұстап тұру - баптау   |   0 / ESC - жабу",
                px + pw / 2, py + ph - 15, 0xFF5E6575);

        if (popFor >= 0) drawPopup(c, mx, my);
    }

    private void drawCard(DrawContext c, Modules.Module m, int x, int y, int mx, int my) {
        int w = cardW, h = CARD_H;
        boolean hover = inView(my) && mx >= x && mx < x + w && my >= y && my < y + h;
        int bg = hover ? 0xFF2A2E38 : 0xFF23262E;
        Gfx.rrect(c, x, y, w, h, 7, Colors.lerp(0xFF2C313C, 0xFF3FA9C9, m.anim * 0.8f));
        Gfx.rrect(c, x + 1, y + 1, w - 2, h - 2, 6, bg);
        if (m.anim > 0.02f) Gfx.rrect(c, x + 1, y + 6, 2, h - 12, 1, Colors.argb((int) (255 * m.anim), 0x5CE1FF));

        c.drawTextWithShadow(textRenderer, m.name, x + 10, y + 8, 0xFFE6E9EF);
        c.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(m.desc, w - 64), x + 10, y + 21, 0xFF8A90A0);

        int tx = x + w - 10 - 34, ty = y + 6;
        Gfx.rrect(c, tx, ty, 34, 16, 8, Colors.lerp(0xFF3A3F4B, 0xFF4FC3F7, m.anim));
        Gfx.circle(c, tx + 8 + 18 * m.anim, ty + 8, 6f, 0xFFFFFFFF);

        if (m.hasAnySettings()) {          // three dots = "has settings"
            for (int i = 0; i < 3; i++) Gfx.circle(c, tx + 11 + i * 6, y + h - 9, 1.6f, 0xFF6F7788);
        }
    }

    private void drawSlider(DrawContext c, int x, int y, int w, float norm, boolean hue, int knobRgb, String label) {
        c.drawTextWithShadow(textRenderer, label, x, y - 12, 0xFFA0A7B6);
        if (hue) {
            for (int i = 0; i < w; i += 2)
                c.fill(x + i, y, Math.min(x + i + 2, x + w), y + 6, 0xFF000000 | Colors.hsb(i / (float) w, 0.85f, 1f));
        } else {
            Gfx.rrect(c, x, y, w, 6, 3, 0xFF3A3F4B);
            Gfx.rrect(c, x, y, Math.max(6, (int) (w * norm)), 6, 3, 0xFF4FC3F7);
        }
        float kx = x + w * norm;
        Gfx.circle(c, kx, y + 3, 5f, 0xFF12141A);
        Gfx.circle(c, kx, y + 3, 4f, knobRgb);
    }

    private void drawPopup(DrawContext c, int mx, int my) {
        Modules.Module m = Modules.ALL.get(popFor);
        c.fill(px, py, px + pw, py + ph, 0xA0000000);
        Gfx.rrect(c, popX - 1, popY - 1, popW + 2, popH + 2, 9, 0xFF3FA9C9);
        Gfx.rrect(c, popX, popY, popW, popH, 8, 0xFF1D2028);
        c.drawTextWithShadow(textRenderer, m.name, popX + 12, popY + 11, CYAN);

        boolean modeLabelDrawn = false;
        for (W w : widgets) {
            int x = popX + w.x, y = popY + w.y;
            switch (w.type) {
                case T_PRIMARY -> {
                    boolean hue = m.settingName.equals("Color");
                    String label = hue ? "Color" : String.format("%s  %.2f", m.settingName, m.value);
                    drawSlider(c, x, y, w.w, m.norm(), hue, hue ? 0xFF000000 | m.rgb() : 0xFFFFFFFF, label);
                }
                case T_EXTRA -> {
                    Modules.Setting st = m.extras.get(w.k);
                    drawSlider(c, x, y, w.w, st.norm(), false, 0xFFFFFFFF, String.format("%s  %.2f", st.name, st.value));
                }
                case T_MODE -> {
                    if (!modeLabelDrawn) { c.drawTextWithShadow(textRenderer, "Style", x, y - 12, 0xFFA0A7B6); modeLabelDrawn = true; }
                    boolean sel = m.mode == w.k;
                    boolean hov = mx >= x && mx < x + w.w && my >= y && my < y + w.h;
                    Gfx.rrect(c, x, y, w.w, w.h, 6, sel ? 0xFF4FC3F7 : (hov ? 0xFF343946 : 0xFF2A2E38));
                    c.drawCenteredTextWithShadow(textRenderer, m.modes[w.k], x + w.w / 2, y + 5, sel ? 0xFF0E1218 : 0xFFB8BFCC);
                }
                case T_RESET -> {
                    boolean hov = mx >= x && mx < x + w.w && my >= y && my < y + w.h;
                    Gfx.rrect(c, x, y, w.w, w.h, 6, hov ? 0xFF4A2A38 : 0xFF3A2430);
                    c.drawCenteredTextWithShadow(textRenderer, "Reset - қалыпты қолға қайтару", x + w.w / 2, y + 6, 0xFFFFB4C0);
                }
                case T_CLOSE -> c.drawCenteredTextWithShadow(textRenderer, "x", x + 8, y + 4, 0xFF8A90A0);
                default -> {}
            }
        }
    }

    // ---------------------------------------------------------------- input
    private void openPopup(int i) {
        popFor = i;
        dragW = null;
        buildPopup(Modules.ALL.get(i));
    }

    private int cardAt(double mx, double my) {
        if (!inView(my)) return -1;
        for (int i = 0; i < Modules.ALL.size(); i++) {
            int x = cx(i), y = cy(i);
            if (mx >= x && mx < x + cardW && my >= y && my < y + CARD_H) return i;
        }
        return -1;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (popFor >= 0) {
            boolean inside = mx >= popX && mx < popX + popW && my >= popY && my < popY + popH;
            if (!inside) { popFor = -1; return true; }
            W w = widgetAt(mx, my);
            if (w != null && button == 0) {
                Modules.Module m = Modules.ALL.get(popFor);
                switch (w.type) {
                    case T_PRIMARY, T_EXTRA -> { dragW = w; sliderTo(w, mx); }
                    case T_MODE -> m.mode = w.k;
                    case T_RESET -> m.resetExtras();
                    case T_CLOSE -> popFor = -1;
                    default -> {}
                }
            }
            return true;
        }
        int ci = cardAt(mx, my);
        if (button == 1) {
            if (ci >= 0 && Modules.ALL.get(ci).hasAnySettings()) openPopup(ci);
            return true;
        }
        if (button == 0 && inView(my)) {
            pressActive = true; moved = false; pressY = my; pressCard = ci; pressTime = System.currentTimeMillis();
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (popFor >= 0) {
            if (dragW != null) sliderTo(dragW, mx);
            return true;
        }
        if (pressActive) {
            if (Math.abs(my - pressY) > 5) moved = true;
            if (moved) scroll = Math.max(0, Math.min(maxScroll, scroll - (float) dy));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragW = null;
        if (pressActive && !moved && pressCard >= 0 && pressCard == cardAt(mx, my) && popFor < 0) {
            Modules.Module m = Modules.ALL.get(pressCard);
            m.enabled = !m.enabled;
        }
        pressActive = false; pressCard = -1;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (popFor >= 0) return true;
        scroll = Math.max(0, Math.min(maxScroll, scroll - (float) vAmount * 24f));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE && popFor >= 0) { popFor = -1; return true; }
        if ((key == GLFW.GLFW_KEY_0 || key == GLFW.GLFW_KEY_KP_0) && System.currentTimeMillis() - openedAt > 200) {
            if (popFor >= 0) popFor = -1; else close();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void removed() { savedScroll = scroll; Modules.save(); }
}
