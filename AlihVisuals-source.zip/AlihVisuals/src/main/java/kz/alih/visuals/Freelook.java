package kz.alih.visuals;

public final class Freelook {
    public static boolean active = false;
    public static float yaw, pitch;
    private Freelook() {}
}
