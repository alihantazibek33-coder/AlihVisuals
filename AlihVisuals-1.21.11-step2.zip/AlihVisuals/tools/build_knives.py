"""Converts the CS2 Knives pack (TACZ / Bedrock geo) into assets for AlihVisuals.
usage: python3 tools/build_knives.py   (reads the extracted pack from $CS2_PACK, writes into src/main/resources)"""
import os, sys, json, shutil, glob
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
import cs2conv
cs2conv.SRC = os.environ.get('CS2_PACK', '/home/claude/cs2/assets/cs2_wt')
from cs2conv import convert
from bbsim import Model

RES = os.path.join(HERE, '..', 'src', 'main', 'resources', 'assets')
KN = os.path.join(RES, 'alihvisuals', 'knives')
NAMES = {'karambit': 'CS2 Karambit', 'butterfly': 'CS2 Butterfly Knife', 'm9': 'CS2 M9 Bayonet', 'bayonet': 'CS2 Bayonet',
         'talon': 'CS2 Talon Knife', 'stiletto': 'CS2 Stiletto Knife', 'push': 'CS2 Shadow Daggers',
         'skeleton': 'CS2 Skeleton Knife', 'tactical': 'CS2 Huntsman Knife', 'css': 'CS2 Seal Knife'}

os.makedirs(KN, exist_ok=True)
index = []
for kid, name in NAMES.items():
    d = convert(kid)
    m = Model(d)
    pose = {}
    for nm in ('static_idle', 'idle'):
        if nm in m.anims and m.anims[nm]['animators']:
            pose = m.pose(nm, 0.0); break
    q = m.quads(pose)
    P = np.vstack([p for p, _ in q]); P[:, 0] *= -1          # back to Bedrock space
    ctr = ((P.min(0) + P.max(0)) / 2).round(3).tolist()
    ext = (P.max(0) - P.min(0)).round(2).tolist()
    with open(os.path.join(KN, kid + '.bbmodel'), 'w') as f: json.dump(d, f, separators=(',', ':'))
    index.append({'id': kid, 'name': name, 'center': ctr, 'size': ext,
                  'anims': [a['name'] for a in d['animations']]})
    # inventory / third-person icon (flat item) + model + sword definition cases
    shutil.copy(f'{cs2conv.SRC}/textures/melee/slot/{kid}.png', os.path.join(RES, 'minecraft', 'textures', 'item', f'cs2_{kid}.png')) \
        if os.path.isdir(os.path.join(RES, 'minecraft', 'textures', 'item')) else None
    mp = os.path.join(RES, 'minecraft', 'models', 'item', f'cs2_{kid}.json')
    with open(mp, 'w') as f:
        json.dump({'parent': 'minecraft:item/handheld', 'textures': {'layer0': f'minecraft:item/cs2_{kid}'}}, f, indent=2)
    print(kid, 'elements', len(d['elements']), 'center', ctr, 'size', ext)
json.dump(index, open(os.path.join(KN, 'index.json'), 'w'), indent=1)

# sword item definitions: add one case per knife (idempotent)
for sw in ('wooden', 'stone', 'iron', 'golden', 'diamond', 'netherite'):
    p = os.path.join(RES, 'minecraft', 'items', f'{sw}_sword.json')
    j = json.load(open(p, encoding='utf-8'))
    cases = j['model']['cases']
    have = {c['when'] for c in cases}
    for kid, name in NAMES.items():
        if name not in have:
            cases.append({'when': name, 'model': {'type': 'minecraft:model', 'model': f'minecraft:item/cs2_{kid}'}})
    json.dump(j, open(p, 'w', encoding='utf-8'), ensure_ascii=False)
print('names for WeaponModels:', list(NAMES.values()))
