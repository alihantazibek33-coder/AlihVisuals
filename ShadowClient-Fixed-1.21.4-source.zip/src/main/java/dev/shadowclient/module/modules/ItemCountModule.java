package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class ItemCountModule extends ClientModule {
    public ItemCountModule() { super("Item Count", "Shows selected stack count and durability.", ModuleCategory.HUD); }
}
