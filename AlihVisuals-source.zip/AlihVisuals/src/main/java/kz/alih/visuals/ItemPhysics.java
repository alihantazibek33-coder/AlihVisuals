package kz.alih.visuals;

import java.util.Map;
import java.util.WeakHashMap;

public final class ItemPhysics {
    private ItemPhysics() {}
    private static final Map<Object, float[]> DATA = new WeakHashMap<>();

    /** returns {blend} where 1 = flying/tumbling, 0 = lying flat */
    public static float[] data(Object entity, boolean onGround) {
        float[] d = DATA.computeIfAbsent(entity, e -> new float[]{onGround ? 0f : 1f});
        float target = onGround ? 0f : 1f;
        d[0] += (target - d[0]) * 0.25f;
        if (Math.abs(d[0] - target) < 0.02f) d[0] = target;
        return d;
    }
}
