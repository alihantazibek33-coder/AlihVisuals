package kz.alih.visuals;

import net.minecraft.client.MinecraftClient;

/** Client-side sky: visual time, clear weather and custom sky / cloud colours (4 styles). */
public final class Ambience {
    private Ambience() {}

    private static boolean active = false;

    // style: 0 Sunset, 1 Night, 2 Dawn, 3 Neon
    private static final int[] SKY = {0xF28C6B, 0x0B1445, 0xF4A6C9, 0};
    private static final int[] CLOUD = {0xFFD2B8, 0x3A4A8C, 0xFFE3F0, 0};
    private static final long[] TIME = {12750L, 18000L, 23100L, 18000L};

    public static boolean on() { return Modules.AMBIENCE.enabled; }

    /** ARGB sky colour for the current style */
    public static int skyColor() {
        int m = Modules.AMBIENCE.mode;
        int rgb = m == 3 ? Colors.hsb(Modules.AMBIENCE.value, 0.85f, 1f) : SKY[m];
        return 0xFF000000 | rgb;
    }

    public static int cloudColor() {
        int m = Modules.AMBIENCE.mode;
        int rgb = m == 3 ? Colors.hsb(Modules.AMBIENCE.value, 0.35f, 1f) : CLOUD[m];
        return 0xFF000000 | rgb;
    }

    private static long timeOfDay() {
        int m = Modules.AMBIENCE.mode;
        return m == 3 ? (long) Modules.AMBIENCE.extras.get(0).value : TIME[m];
    }

    public static void tick(MinecraftClient mc) {
        if (mc.world == null) { active = false; return; }
        if (Modules.AMBIENCE.enabled) {
            // freeze the visual time at our value, force clear weather
            mc.world.setTime(mc.world.getTime(), timeOfDay(), false);
            mc.world.setRainGradient(0f);
            mc.world.setThunderGradient(0f);
            active = true;
        } else if (active) {
            // let the world clock run again; the next server time packet corrects the value
            mc.world.setTime(mc.world.getTime(), mc.world.getTimeOfDay(), true);
            active = false;
        }
    }
}
