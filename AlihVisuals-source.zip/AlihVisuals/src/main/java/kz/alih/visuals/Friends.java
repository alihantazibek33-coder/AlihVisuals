package kz.alih.visuals;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

/** Friend list (UUID -> last known name). Friends cannot be attacked. */
public final class Friends {
    private Friends() {}

    private static final Map<UUID, String> MAP = new LinkedHashMap<>();
    private static boolean loaded;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("alihvisuals").resolve("friends.properties");
    }

    private static synchronized void ensure() {
        if (loaded) return;
        loaded = true;
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            Properties p = new Properties();
            p.load(r);
            for (String k : p.stringPropertyNames()) {
                try { MAP.put(UUID.fromString(k), p.getProperty(k)); } catch (IllegalArgumentException ignored) {}
            }
        } catch (IOException ignored) {}
    }

    private static synchronized void save() {
        Properties p = new Properties();
        for (Map.Entry<UUID, String> e : MAP.entrySet()) p.setProperty(e.getKey().toString(), e.getValue());
        try {
            Files.createDirectories(file().getParent());
            try (Writer w = Files.newBufferedWriter(file())) { p.store(w, "AlihVisuals friends"); }
        } catch (IOException ignored) {}
    }

    public static synchronized boolean is(UUID id) {
        ensure();
        return id != null && MAP.containsKey(id);
    }

    public static synchronized boolean add(UUID id, String name) {
        ensure();
        boolean isNew = !MAP.containsKey(id);
        MAP.put(id, name);
        save();
        return isNew;
    }

    public static synchronized boolean remove(String name) {
        ensure();
        UUID found = null;
        for (Map.Entry<UUID, String> e : MAP.entrySet())
            if (e.getValue().equalsIgnoreCase(name)) { found = e.getKey(); break; }
        if (found == null) return false;
        MAP.remove(found);
        save();
        return true;
    }

    public static synchronized List<String> names() {
        ensure();
        return new ArrayList<>(MAP.values());
    }
}
