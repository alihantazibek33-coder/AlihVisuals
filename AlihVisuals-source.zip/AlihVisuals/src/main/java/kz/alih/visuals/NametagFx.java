package kz.alih.visuals;

import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

/** Animated special colours for the Nametag module. mode 0 = default (no change). */
public final class NametagFx {
    private NametagFx() {}

    /** Gradient / animation colour (RGB) of character i of n at time t (seconds). */
    public static int color(int mode, int i, int n, double t) {
        switch (mode) {
            case 1: { // Gold - flowing gold with sparkles
                int c = pal(i * 0.07 - t * 0.6, 0xB8860B, 0xFFD700, 0xFFF3A0, 0xFFD700);
                if (frac(t * 1.4 - i * 0.23) < 0.09) c = 0xFFFFFF;
                return c;
            }
            case 2: return Colors.hsb((float) frac(t * 0.35 + i * 0.07), 0.8f, 1f); // Rainbow
            case 3: return pal(i * 0.06 - t * 0.35, 0x6A11CB, 0xFF3CAC, 0x2575FC, 0x9B5CFF); // Nebula
            case 4: return pal(i * 0.08 - t * 0.4, 0xFFC1D6, 0xFF8FB1, 0xFFFFFF, 0xFFA6C9); // Sakura
            case 5: { // Midnight - deep blue with twinkling stars
                int c = pal(i * 0.07 - t * 0.25, 0x0B1B5A, 0x2C3FA8, 0x7A89FF, 0x1A2A7A);
                if (frac(Math.sin(Math.floor(t * 3) * 12.9898 + i * 78.233) * 43758.5453) < 0.12) c = 0xFFFFFF;
                return c;
            }
            case 6: return pal(i * 0.08 - t * 0.5, 0x9AE3FF, 0xFFFFFF, 0x4FC3F7, 0xD6F6FF); // Frost
            case 7: return pal(i * 0.10 - t * 0.8, 0x1BFF00, 0xC6FF00, 0x0A8F00, 0x7CFF2B); // Toxic
            default: return 0xFFFFFF;
        }
    }

    /** Re-colours a nametag text letter by letter (animated, call it every frame). */
    public static Text apply(Text original) {
        int mode = Modules.NAMETAG.mode;
        if (!Modules.NAMETAG.enabled || mode <= 0) return original;
        int[] cps = original.getString().codePoints().toArray();
        if (cps.length == 0) return original;
        double t = System.currentTimeMillis() / 1000.0;
        MutableText out = Text.empty();
        for (int i = 0; i < cps.length; i++) {
            out.append(Text.literal(new String(Character.toChars(cps[i])))
                    .setStyle(Style.EMPTY.withColor(color(mode, i, cps.length, t))));
        }
        return out;
    }

    private static double frac(double v) { return v - Math.floor(v); }

    private static int pal(double pos, int... c) {
        pos = frac(pos);
        double f = pos * c.length;
        int i = (int) f;
        double u = f - i;
        u = u * u * (3 - 2 * u);
        int a = c[i % c.length], b = c[(i + 1) % c.length];
        int r = (int) (((a >> 16) & 255) * (1 - u) + ((b >> 16) & 255) * u);
        int g = (int) (((a >> 8) & 255) * (1 - u) + ((b >> 8) & 255) * u);
        int bl = (int) ((a & 255) * (1 - u) + (b & 255) * u);
        return (r << 16) | (g << 8) | bl;
    }
}
