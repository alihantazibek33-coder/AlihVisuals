# AlihVisuals (Fabric 1.21.4)
Меню: **0** пернесі. Build: `gradle build` (Java 21) -> build/libs/alihvisuals-1.0.0.jar
Немесе GitHub-қа жүктеп, Actions -> build -> Artifacts.

## Пернелер (Controls -> AlihVisuals)
- **Left Alt** (ұстап тұр) - Freelock. Баптауда View: Third Person / First Person
- **F7** - FreeCam қосу/өшіру (меню арқылы да болады). WASD + Space/Shift, Ctrl - жылдам
- **G** (ұстап тұр) - Zoom, дөңгелек - күшін өзгертеді
- **H** - творчествода қараған блокты қолға алу (Block Pick модулі қосулы болса)

## Чат командалары
- `.dupe [саны]` - қолдағы затты көшіреді (тек творчество, зачарование сақталады)
- `.friends add <ник>` / `.friends remove <ник>` / `.friends list` - достар ұрылмайды (add үшін ойында болуы керек)

## Музыка
Файлдарды `config/alihvisuals/music` папкасына сал. Аты - файл атынан кеңейтілімсіз.
mp3 және wav тікелей ойнайды. Басқа формат (mp4, m4a, ogg, flac) үшін ffmpeg орнатылған болу керек.

## Қылыштар -> Предмет
Қылыштар менюінің оң жақ жоғарғы бұрышында "Предмет" - атын немесе id-ін жазып, кез келген предметтің текстурасын қылышқа қоясың.


## Knife-inspired weapon presets
The Replacer menu includes ten additional original knife-inspired presets. They reuse models already bundled in this project and therefore do not include copied CS2 models or animations. Held-item positioning and attack motion use Minecraft's normal item rendering and swing animation; fully custom first-person animation requires a dedicated renderer/animation implementation.


## Knife-style first-person animation update
- Press **V** while in-game to trigger a short inspect-style movement for supported knife-named replacement models.
- Supported names include Knife, Karambit, Bayonet, Talon, Dagger, and Fang.
- Knife-style replacements also receive subtle idle movement and use the existing custom swing animation module when enabled.
- The knife entries remain in the existing **0 → Қылыштар** replacement screen; no separate main-menu button was added.
- This is a source update; build/launch testing was not possible in this environment because Gradle is not installed.
