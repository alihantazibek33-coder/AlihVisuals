package kz.alih.visuals.cosmetics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix4d;
import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.joml.Vector3f;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Minimal Blockbench (.bbmodel) renderer: cubes + meshes, nested groups with rotation, embedded textures.
 * Blockbench coordinates (pixels, Y up, character faces -Z, feet at y=0, neck at y=24)
 * are mapped to Minecraft player-model space by {@link #PRE}.
 */
public final class BBModel {
    /** Blockbench pixels -> player model space (neck = origin, blocks, Y down). */
    public static Matrix4f pre() {
        return new Matrix4f().translate(0f, 1.5f, 0f).scale(-1f / 16f, -1f / 16f, 1f / 16f);
    }

    private static final Map<String, BBModel> CACHE = new HashMap<>();
    private static final Set<String> FAILED = new HashSet<>();

    private static final Set<String> HAT_EXCLUDE = Set.of("body", "leftarm", "rightarm", "leftleg", "rightleg", "cape", "collision");
    private static final Set<String> WING_EXCLUDE = Set.of("head", "hat", "leftarm", "rightarm", "leftleg", "rightleg", "cape", "collision", "membranes");
    /** reference body parts that some models ship inside the file - they must not be drawn on top of the player */
    private static final Set<String> BODY_ELEMENTS = Set.of("head", "hat", "body", "jacket", "leftarm", "rightarm", "left arm", "right arm",
            "left sleeve", "right sleeve", "leftleg", "rightleg", "left leg", "right leg", "left pants", "right pants");
    private static final Set<String> PET_EXCLUDE = Set.of("collision");

    private static final class Quad {
        final float[] p = new float[12];
        final float[] uv = new float[8];
        float nx, ny, nz;
        int tex;
    }

    private static final class Node {
        String name = "";
        float ox, oy, oz, rx, ry, rz;
        final List<Node> kids = new ArrayList<>();
        final List<Quad> quads = new ArrayList<>();
    }

    private final Node root = new Node();
    private final Set<String> names = new HashSet<>();
    private Identifier[] tex = new Identifier[0];
    private boolean hasGeometry;
    /** minX, minY, minZ, maxX, maxY, maxZ in Blockbench pixels (default pose) */
    public final float[] bounds = new float[6];

    public boolean has(String lowerCaseGroupName) { return names.contains(lowerCaseGroupName); }

    /** authored rotation (degrees) of a group, or null if there is no such group */
    public float[] rot(String lowerCaseGroupName) {
        Node n = find(root, lowerCaseGroupName);
        return n == null ? null : new float[]{n.rx, n.ry, n.rz};
    }

    // ------------------------------------------------------------------ loading
    public static synchronized BBModel get(CosmeticsState.Entry e) {
        if (e == null) return null;
        String key = e.file() + "|" + (e.variant() == null ? "" : e.variant());
        BBModel m = CACHE.get(key);
        if (m != null) return m;
        if (FAILED.contains(key)) return null;
        try {
            String text = readText(e.file());
            m = parse(text, Integer.toHexString(key.hashCode()), e.type(), e.variant());
            if (!m.hasGeometry) { FAILED.add(key); return null; }
            CACHE.put(key, m);
            return m;
        } catch (Throwable t) {
            FAILED.add(key);
            return null;
        }
    }

    public static synchronized void clearCache() { CACHE.clear(); FAILED.clear(); }

    private static String readText(Path file) throws Exception {
        String low = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (low.endsWith(".zip")) {
            try (ZipFile zip = new ZipFile(file.toFile())) {
                ZipEntry found = null;
                for (var en = zip.entries(); en.hasMoreElements(); ) {
                    ZipEntry z = en.nextElement();
                    if (z.getName().toLowerCase(Locale.ROOT).endsWith(".bbmodel") && !z.getName().startsWith("__MACOSX")) { found = z; break; }
                }
                if (found == null) throw new IllegalStateException("archive contains no .bbmodel");
                try (InputStream in = zip.getInputStream(found)) { return new String(in.readAllBytes(), StandardCharsets.UTF_8); }
            }
        }
        return Files.readString(file, StandardCharsets.UTF_8);
    }

    /** hat1, hat2 ... groups under "Head" -> selectable variants (Hat Kid style models) */
    public static List<String> hatVariants(Path file) {
        List<String> out = new ArrayList<>();
        try {
            JsonObject j = JsonParser.parseString(readText(file)).getAsJsonObject();
            Map<String, JsonObject> groups = new HashMap<>();
            if (j.has("groups")) for (JsonElement g : j.getAsJsonArray("groups")) if (g.isJsonObject()) groups.put(str(g.getAsJsonObject(), "uuid"), g.getAsJsonObject());
            if (j.has("outliner")) for (JsonElement n : j.getAsJsonArray("outliner")) findHats(n, "", groups, out);
        } catch (Throwable ignored) {}
        out.sort(String::compareTo);
        return out;
    }

    private static void findHats(JsonElement n, String parent, Map<String, JsonObject> groups, List<String> out) {
        if (!n.isJsonObject()) return;
        JsonObject o = n.getAsJsonObject();
        JsonObject g = o.has("name") ? o : groups.getOrDefault(str(o, "uuid"), o);
        String name = str(g, "name").toLowerCase(Locale.ROOT);
        if (parent.equals("head") && name.matches("hat\\d+")) out.add(name);
        if (o.has("children")) for (JsonElement c : o.getAsJsonArray("children")) findHats(c, name, groups, out);
    }

    // ------------------------------------------------------------------ parsing
    private static final class Ctx {
        CosmeticType type;
        String variant;
        Set<String> excluded;
        float[][] uvSize;
        Map<String, JsonObject> elems = new HashMap<>();
        Map<String, JsonObject> groups = new HashMap<>();
    }

    private static BBModel parse(String text, String key, CosmeticType type, String variant) {
        JsonObject j = JsonParser.parseString(text).getAsJsonObject();
        BBModel m = new BBModel();
        float resW = 16, resH = 16;
        if (j.has("resolution") && j.get("resolution").isJsonObject()) {
            JsonObject r = j.getAsJsonObject("resolution");
            resW = num(r, "width", 16);
            resH = num(r, "height", 16);
        }

        JsonArray ta = j.has("textures") ? j.getAsJsonArray("textures") : new JsonArray();
        Ctx c = new Ctx();
        c.type = type;
        c.variant = variant;
        c.excluded = switch (type) {
            case HAT -> HAT_EXCLUDE;
            case WING -> WING_EXCLUDE;
            default -> PET_EXCLUDE;
        };
        c.uvSize = new float[ta.size()][2];
        m.tex = new Identifier[ta.size()];
        MinecraftClient mc = MinecraftClient.getInstance();
        for (int i = 0; i < ta.size(); i++) {
            JsonObject t = ta.get(i).getAsJsonObject();
            c.uvSize[i][0] = num(t, "uv_width", resW);
            c.uvSize[i][1] = num(t, "uv_height", resH);
            String src = str(t, "source");
            if (src.startsWith("data:")) {
                try {
                    byte[] bytes = Base64.getDecoder().decode(src.substring(src.indexOf(',') + 1));
                    NativeImage img = NativeImage.read(new ByteArrayInputStream(bytes));
                    Identifier id = Identifier.of("alihvisuals", "cosmetic/" + key + "/" + i);
                    mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture(img));
                    m.tex[i] = id;
                } catch (Exception ignored) {}
            }
        }

        if (j.has("elements")) for (JsonElement e : j.getAsJsonArray("elements")) if (e.isJsonObject()) c.elems.put(str(e.getAsJsonObject(), "uuid"), e.getAsJsonObject());
        if (j.has("groups")) for (JsonElement g : j.getAsJsonArray("groups")) if (g.isJsonObject()) c.groups.put(str(g.getAsJsonObject(), "uuid"), g.getAsJsonObject());
        if (j.has("outliner")) for (JsonElement n : j.getAsJsonArray("outliner")) m.walk(n, m.root, "", c);

        if (type == CosmeticType.WING) m.keepOneWingPose();
        m.hasGeometry = m.countQuads(m.root) > 0;
        m.computeBounds();
        return m;
    }

    private void walk(JsonElement n, Node parent, String parentName, Ctx c) {
        if (n.isJsonPrimitive()) {
            JsonObject e = c.elems.get(n.getAsString());
            if (e != null) element(e, parent, c);
            return;
        }
        if (!n.isJsonObject()) return;
        JsonObject o = n.getAsJsonObject();
        JsonObject g = o.has("name") ? o : c.groups.getOrDefault(str(o, "uuid"), o);
        if (isFalse(g, "visibility") || isFalse(g, "export")) return;
        String low = str(g, "name").toLowerCase(Locale.ROOT);
        if (c.excluded.contains(low)) return;
        if (c.variant != null && parentName.equals("head") && low.matches("hat\\d+") && !low.equals(c.variant)) return;

        Node node = new Node();
        node.name = low;
        float[] origin = arr3(g, "origin"), rot = arr3(g, "rotation");
        node.ox = origin[0]; node.oy = origin[1]; node.oz = origin[2];
        node.rx = rot[0]; node.ry = rot[1]; node.rz = rot[2];
        parent.kids.add(node);
        names.add(low);
        if (o.has("children")) for (JsonElement ch : o.getAsJsonArray("children")) walk(ch, node, low, c);
    }

    /** models like "Wimgs" contain several poses of one wing (wings1..wingsN) - keep one, it gets mirrored */
    private void keepOneWingPose() {
        Node wr = find(root, "wings_root");
        if (wr == null) return;
        List<Node> poses = new ArrayList<>();
        for (Node k : wr.kids) if (k.name.matches("wings\\d+")) poses.add(k);
        if (poses.size() < 2) return;
        Node keep = poses.get(0);
        for (Node p : poses) if (p.name.equals("wings2")) keep = p;
        for (Node p : poses) if (p != keep) wr.kids.remove(p);
    }

    private static Node find(Node n, String name) {
        if (n.name.equals(name)) return n;
        for (Node k : n.kids) { Node r = find(k, name); if (r != null) return r; }
        return null;
    }

    private int countQuads(Node n) {
        int c = n.quads.size();
        for (Node k : n.kids) c += countQuads(k);
        return c;
    }

    // ------------------------------------------------------------------ elements -> quads
    private void element(JsonObject e, Node node, Ctx c) {
        if (isFalse(e, "visibility") || isFalse(e, "export")) return;
        if (c.type != CosmeticType.PET && BODY_ELEMENTS.contains(str(e, "name").toLowerCase(Locale.ROOT))) return;
        String type = e.has("type") ? str(e, "type") : "cube";
        float[] o = arr3(e, "origin"), r = arr3(e, "rotation");
        Matrix4d E = new Matrix4d().translate(o[0], o[1], o[2])
                .rotateZ(Math.toRadians(r[2])).rotateY(Math.toRadians(r[1])).rotateX(Math.toRadians(r[0]))
                .translate(-o[0], -o[1], -o[2]);
        List<Quad> made = new ArrayList<>();

        if (type.equals("cube") && e.has("from") && e.has("to") && e.has("faces")) {
            float[] f = arr3(e, "from"), t = arr3(e, "to");
            JsonObject faces = e.getAsJsonObject("faces");
            double[][][] corners = cubeFaces(f, t);
            String[] keys = {"north", "south", "east", "west", "up", "down"};
            for (int i = 0; i < 6; i++) {
                if (!faces.has(keys[i]) || !faces.get(keys[i]).isJsonObject()) continue;
                JsonObject face = faces.getAsJsonObject(keys[i]);
                int ti = texIndex(face, c);
                if (ti < 0 || !face.has("uv") || !face.get("uv").isJsonArray()) continue;
                JsonArray uv = face.getAsJsonArray("uv");
                if (uv.size() < 4) continue;
                float u1 = uv.get(0).getAsFloat(), v1 = uv.get(1).getAsFloat(), u2 = uv.get(2).getAsFloat(), v2 = uv.get(3).getAsFloat();
                float[][] uvs = {{u1, v1}, {u2, v1}, {u2, v2}, {u1, v2}};
                made.add(quad(E, corners[i], uvs, ti, c));
            }
        } else if (type.equals("mesh") && e.has("vertices") && e.has("faces")) {
            JsonObject verts = e.getAsJsonObject("vertices");
            for (var entry : e.getAsJsonObject("faces").entrySet()) {
                if (!entry.getValue().isJsonObject()) continue;
                JsonObject face = entry.getValue().getAsJsonObject();
                int ti = texIndex(face, c);
                if (ti < 0 || !face.has("vertices") || !face.has("uv")) continue;
                JsonArray ids = face.getAsJsonArray("vertices");
                JsonObject uvMap = face.getAsJsonObject("uv");
                int n = ids.size();
                if (n < 3) continue;
                double[][] pts = new double[4][];
                float[][] uvs = new float[4][];
                for (int k = 0; k < 4; k++) {
                    String id = ids.get(Math.min(k, n - 1)).getAsString();
                    if (!verts.has(id) || !uvMap.has(id)) { pts = null; break; }
                    JsonArray p = verts.getAsJsonArray(id), u = uvMap.getAsJsonArray(id);
                    pts[k] = new double[]{o[0] + p.get(0).getAsDouble(), o[1] + p.get(1).getAsDouble(), o[2] + p.get(2).getAsDouble()};
                    uvs[k] = new float[]{u.get(0).getAsFloat(), u.get(1).getAsFloat()};
                }
                if (pts != null) made.add(quad(E, pts, uvs, ti, c));
            }
        }
        if (made.isEmpty()) return;

        // outward-facing normals: compare with the element centre
        Vector3d centre = new Vector3d();
        for (Quad q : made) for (int i = 0; i < 4; i++) centre.add(q.p[i * 3], q.p[i * 3 + 1], q.p[i * 3 + 2]);
        centre.div(made.size() * 4.0);
        for (Quad q : made) {
            Vector3d p0 = new Vector3d(q.p[0], q.p[1], q.p[2]), p1 = new Vector3d(q.p[3], q.p[4], q.p[5]);
            Vector3d p2 = new Vector3d(q.p[6], q.p[7], q.p[8]), p3 = new Vector3d(q.p[9], q.p[10], q.p[11]);
            Vector3d n = new Vector3d(p1).sub(p0).cross(new Vector3d(p3).sub(p0));
            if (n.lengthSquared() < 1e-12) n = new Vector3d(p1).sub(p0).cross(new Vector3d(p2).sub(p0));
            if (n.lengthSquared() < 1e-12) n.set(0, 1, 0); else n.normalize();
            Vector3d mid = new Vector3d(p0).add(p1).add(p2).add(p3).div(4.0).sub(centre);
            if (n.dot(mid) < 0) n.negate();
            q.nx = (float) n.x; q.ny = (float) n.y; q.nz = (float) n.z;
        }
        node.quads.addAll(made);
    }

    private static int texIndex(JsonObject face, Ctx c) {
        if (!face.has("texture") || face.get("texture").isJsonNull()) return -1;
        int ti;
        try { ti = face.get("texture").getAsInt(); } catch (Exception e) { return -1; }
        return ti >= 0 && ti < c.uvSize.length ? ti : -1;
    }

    private Quad quad(Matrix4d E, double[][] corners, float[][] uvs, int ti, Ctx c) {
        Quad q = new Quad();
        q.tex = ti;
        Vector3d v = new Vector3d();
        for (int i = 0; i < 4; i++) {
            E.transformPosition(corners[i][0], corners[i][1], corners[i][2], v);
            q.p[i * 3] = (float) v.x; q.p[i * 3 + 1] = (float) v.y; q.p[i * 3 + 2] = (float) v.z;
            q.uv[i * 2] = uvs[i][0] / c.uvSize[ti][0];
            q.uv[i * 2 + 1] = uvs[i][1] / c.uvSize[ti][1];
        }
        return q;
    }

    /** corner order per face: top-left, top-right, bottom-right, bottom-left as seen from outside */
    private static double[][][] cubeFaces(float[] f, float[] t) {
        double x0 = f[0], y0 = f[1], z0 = f[2], x1 = t[0], y1 = t[1], z1 = t[2];
        return new double[][][]{
                {{x1, y1, z0}, {x0, y1, z0}, {x0, y0, z0}, {x1, y0, z0}},   // north
                {{x0, y1, z1}, {x1, y1, z1}, {x1, y0, z1}, {x0, y0, z1}},   // south
                {{x1, y1, z1}, {x1, y1, z0}, {x1, y0, z0}, {x1, y0, z1}},   // east
                {{x0, y1, z0}, {x0, y1, z1}, {x0, y0, z1}, {x0, y0, z0}},   // west
                {{x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}},   // up
                {{x0, y0, z1}, {x1, y0, z1}, {x1, y0, z0}, {x0, y0, z0}}    // down
        };
    }

    // ------------------------------------------------------------------ bounds
    private void computeBounds() {
        float[] b = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
        boundsWalk(root, new Matrix4f(), b);
        if (b[0] == Float.MAX_VALUE) java.util.Arrays.fill(b, 0f);
        System.arraycopy(b, 0, bounds, 0, 6);
    }

    private void boundsWalk(Node n, Matrix4f parent, float[] b) {
        Matrix4f m = nodeMatrix(n, parent, null);
        Vector3f v = new Vector3f();
        for (Quad q : n.quads) {
            for (int i = 0; i < 4; i++) {
                m.transformPosition(q.p[i * 3], q.p[i * 3 + 1], q.p[i * 3 + 2], v);
                b[0] = Math.min(b[0], v.x); b[1] = Math.min(b[1], v.y); b[2] = Math.min(b[2], v.z);
                b[3] = Math.max(b[3], v.x); b[4] = Math.max(b[4], v.y); b[5] = Math.max(b[5], v.z);
            }
        }
        for (Node k : n.kids) boundsWalk(k, m, b);
    }

    private Matrix4f nodeMatrix(Node n, Matrix4f parent, Function<String, float[]> pose) {
        Matrix4f m = new Matrix4f(parent);
        if (n == root) return m;
        float rx = n.rx, ry = n.ry, rz = n.rz;
        float[] d = pose == null ? null : pose.apply(n.name);
        if (d != null) { rx += d[0]; ry += d[1]; rz += d[2]; }
        return m.translate(n.ox, n.oy, n.oz)
                .rotateZ((float) Math.toRadians(rz)).rotateY((float) Math.toRadians(ry)).rotateX((float) Math.toRadians(rx))
                .translate(-n.ox, -n.oy, -n.oz);
    }

    // ------------------------------------------------------------------ rendering
    /**
     * @param rootChain transform from Blockbench pixels to the current matrix-stack space (start from {@link #pre()})
     * @param pose      optional per-group rotation offsets in degrees (key = lower-case group name)
     */
    public void render(MatrixStack ms, VertexConsumerProvider vcp, int light, int overlay,
                       Matrix4f rootChain, Function<String, float[]> pose) {
        if (!hasGeometry) return;
        VertexConsumer[] buffers = new VertexConsumer[tex.length];
        draw(root, rootChain, ms.peek(), vcp, buffers, light, overlay, pose);
    }

    private void draw(Node n, Matrix4f parent, MatrixStack.Entry entry, VertexConsumerProvider vcp,
                      VertexConsumer[] buffers, int light, int overlay, Function<String, float[]> pose) {
        Matrix4f m = nodeMatrix(n, parent, pose);
        Vector3f v = new Vector3f();
        Vector3f nv = new Vector3f();
        for (Quad q : n.quads) {
            if (tex[q.tex] == null) continue;
            VertexConsumer vc = buffers[q.tex];
            if (vc == null) vc = buffers[q.tex] = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(tex[q.tex]));
            m.transformDirection(q.nx, q.ny, q.nz, nv).normalize();
            for (int i = 0; i < 4; i++) {
                m.transformPosition(q.p[i * 3], q.p[i * 3 + 1], q.p[i * 3 + 2], v);
                vc.vertex(entry.getPositionMatrix(), v.x, v.y, v.z)
                        .color(255, 255, 255, 255)
                        .texture(q.uv[i * 2], q.uv[i * 2 + 1])
                        .overlay(overlay)
                        .light(light)
                        .normal(entry, nv.x, nv.y, nv.z);
            }
        }
        for (Node k : n.kids) draw(k, m, entry, vcp, buffers, light, overlay, pose);
    }

    // ------------------------------------------------------------------ json helpers
    private static String str(JsonObject o, String k) {
        return o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsString() : "";
    }

    private static float num(JsonObject o, String k, float def) {
        try { return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsFloat() : def; } catch (Exception e) { return def; }
    }

    private static boolean isFalse(JsonObject o, String k) {
        return o.has(k) && o.get(k).isJsonPrimitive() && o.get(k).getAsJsonPrimitive().isBoolean() && !o.get(k).getAsBoolean();
    }

    private static float[] arr3(JsonObject o, String k) {
        float[] r = new float[3];
        if (o.has(k) && o.get(k).isJsonArray()) {
            JsonArray a = o.getAsJsonArray(k);
            for (int i = 0; i < 3 && i < a.size(); i++) {
                try { r[i] = a.get(i).getAsFloat(); } catch (Exception ignored) {}
            }
        }
        return r;
    }
}
