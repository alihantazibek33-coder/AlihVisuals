package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class ClearChatModule extends ClientModule {
    public ClearChatModule() { super("Clear Chat", "Adds a quick local chat-clearing action.", ModuleCategory.QUALITY); }
}
