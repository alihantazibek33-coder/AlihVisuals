package kz.alih.visuals.mixin;

import kz.alih.visuals.Glow;
import kz.alih.visuals.GlowConsumer;
import kz.alih.visuals.Modules;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.TexturedRenderLayers;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Shader Hands (item): after the held item is drawn, draw it again a few times - bigger, tinted, full-bright. */
@Mixin(ItemRenderState.class)
public abstract class ItemRenderStateMixin {
    private static final float[][] PASSES = {{1.04f, 0.34f}, {1.08f, 0.22f}, {1.13f, 0.12f}};

    @Inject(method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;II)V",
            at = @At("RETURN"), require = 0)
    private void alih$glow(MatrixStack ms, VertexConsumerProvider vcp, int light, int overlay, CallbackInfo ci) {
        if (Glow.busy || !Glow.inHand || !Modules.SHADERHANDS.enabled) return;
        Glow.busy = true;
        try {
            int rgb = Modules.SHADERHANDS.rgb();
            ItemRenderState self = (ItemRenderState) (Object) this;
            for (float[] ps : PASSES) {
                final float alpha = ps[1];
                ms.push();
                ms.scale(ps[0], ps[0], ps[0]);
                self.render(ms,
                        layer -> new GlowConsumer(vcp.getBuffer(TexturedRenderLayers.getItemEntityTranslucentCull()), rgb, alpha),
                        LightmapTextureManager.MAX_LIGHT_COORDINATE, overlay);
                ms.pop();
            }
        } finally {
            Glow.busy = false;
        }
    }
}
