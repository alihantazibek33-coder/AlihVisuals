package kz.alih.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

/** Marker at the place you died. Only shown on the same server / world / dimension, gone after a game restart. */
public final class DeathMarker {
    private DeathMarker() {}

    public static boolean has;
    public static double x, y, z;
    private static String server = "", dim = "";
    private static boolean deadHandled;

    // matrices + camera of the last rendered world frame (used to project the marker to the screen)
    private static final Matrix4f VIEW = new Matrix4f(), PROJ = new Matrix4f();
    private static double camX, camY, camZ;
    private static boolean haveMatrices;

    private static String serverKey(MinecraftClient mc) {
        ServerInfo si = mc.getCurrentServerEntry();
        if (si != null) return si.address;
        IntegratedServer is = mc.getServer();
        if (is != null) return "sp:" + is.getSaveProperties().getLevelName();
        return "?";
    }

    private static String dimKey(MinecraftClient mc) {
        return mc.world == null ? "" : mc.world.getRegistryKey().getValue().toString();
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { deadHandled = false; return; }
        if (p.isDead() || p.getHealth() <= 0f) {
            if (!deadHandled) {
                deadHandled = true;
                if (Modules.DEATHCOORD.enabled) {
                    x = p.getX(); y = p.getY(); z = p.getZ();
                    server = serverKey(mc);
                    dim = dimKey(mc);
                    has = true;
                }
            }
        } else {
            deadHandled = false;
        }
    }

    public static boolean visible(MinecraftClient mc) {
        return has && mc.world != null && serverKey(mc).equals(server) && dimKey(mc).equals(dim);
    }

    public static void capture(Matrix4f view, Matrix4f proj, Vec3d cam) {
        VIEW.set(view);
        PROJ.set(proj);
        camX = cam.x; camY = cam.y; camZ = cam.z;
        haveMatrices = true;
    }

    public static void invalidate() { haveMatrices = false; }

    // ------------------------------------------------------------------ HUD label
    public static void hud(DrawContext c, MinecraftClient mc) {
        if (!Modules.DEATHCOORD.enabled || mc.player == null || !visible(mc) || !haveMatrices) return;
        if (mc.options.hudHidden) return;

        Vector4f v = new Vector4f((float) (x - camX), (float) (y + 2.4 - camY), (float) (z - camZ), 1f);
        VIEW.transform(v);
        PROJ.transform(v);

        int W = c.getScaledWindowWidth(), H = c.getScaledWindowHeight();
        float cx = W / 2f, cy = H / 2f;
        boolean behind = v.w <= 0.001f;
        float sx, sy;
        if (!behind) {
            sx = (v.x / v.w * 0.5f + 0.5f) * W;
            sy = (0.5f - v.y / v.w * 0.5f) * H;
        } else {
            float len = (float) Math.hypot(v.x, v.y);
            if (len < 1e-4f) { sx = cx; sy = cy + 1000f; }
            else { sx = cx + v.x / len * 1000f; sy = cy - v.y / len * 1000f; }
        }

        float mx = W / 2f - 56f, my = H / 2f - 34f;
        float dx = sx - cx, dy = sy - cy;
        boolean off = behind || Math.abs(dx) > mx || Math.abs(dy) > my;
        if (off) {
            float k = Math.min(mx / Math.max(1e-3f, Math.abs(dx)), my / Math.max(1e-3f, Math.abs(dy)));
            sx = cx + dx * k;
            sy = cy + dy * k;
        }

        int rgb = Modules.DEATHCOORD.rgb();
        double dist = mc.player.getPos().distanceTo(new Vec3d(x, y, z));
        String l1 = "Death Point";
        String l2 = Math.round(dist) + " m";
        TextRenderer tr = mc.textRenderer;
        int w = Math.max(tr.getWidth(l1), tr.getWidth(l2)) + 24, h = 25;
        int px = Math.round(sx) - w / 2;
        int py = off ? Math.round(sy) - h / 2 : Math.round(sy) - h - 9;

        float pulse = 0.75f + 0.25f * (float) Math.sin(System.currentTimeMillis() / 260.0);
        Gfx.rrect(c, px - 1, py - 1, w + 2, h + 2, 8, Colors.argb((int) (210 * pulse), rgb));
        Gfx.rrect(c, px, py, w, h, 7, 0xE6101018);
        Gfx.circle(c, px + 11, py + h / 2f, 5.5f, Colors.argb(70, rgb));
        Gfx.circle(c, px + 11, py + h / 2f, 3.2f, 0xFF000000 | rgb);
        c.drawTextWithShadow(tr, l1, px + 20, py + 4, 0xFFFFFFFF);
        c.drawTextWithShadow(tr, l2, px + 20, py + 14, 0xFF000000 | rgb);
        if (!off) Gfx.triangle(c, sx - 5, py + h + 1, sx + 5, py + h + 1, sx, py + h + 8, Colors.argb(235, rgb));
    }
}
