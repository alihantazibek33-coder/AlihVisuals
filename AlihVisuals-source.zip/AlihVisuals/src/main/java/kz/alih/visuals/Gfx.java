package kz.alih.visuals;

import net.minecraft.client.gui.DrawContext;

public final class Gfx {
    private Gfx() {}

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int dx = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - d * d)));
            c.fill(x + dx, y + i, x + w - dx, y + i + 1, color);
            c.fill(x + dx, y + h - i - 1, x + w - dx, y + h - i, color);
        }
        c.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void circle(DrawContext c, float cx, float cy, float r, int color) {
        int ir = (int) Math.ceil(r);
        for (int dy = -ir; dy <= ir; dy++) {
            double v = r * r - (dy + 0.5) * (dy + 0.5);
            if (v <= 0) continue;
            int hw = (int) Math.round(Math.sqrt(v));
            c.fill((int) cx - hw, (int) cy + dy, (int) cx + hw, (int) cy + dy + 1, color);
        }
    }

    /** solid filled triangle (scan-line) */
    public static void triangle(DrawContext c, float x1, float y1, float x2, float y2, float x3, float y3, int color) {
        int minY = (int) Math.floor(Math.min(y1, Math.min(y2, y3)));
        int maxY = (int) Math.ceil(Math.max(y1, Math.max(y2, y3)));
        float[][] e = {{x1, y1, x2, y2}, {x2, y2, x3, y3}, {x3, y3, x1, y1}};
        for (int y = minY; y < maxY; y++) {
            float yy = y + 0.5f, xa = Float.MAX_VALUE, xb = -Float.MAX_VALUE;
            for (float[] s : e) {
                if ((yy < s[1]) == (yy < s[3])) continue;
                float t = (yy - s[1]) / (s[3] - s[1]);
                float xx = s[0] + t * (s[2] - s[0]);
                xa = Math.min(xa, xx); xb = Math.max(xb, xx);
            }
            if (xa <= xb) c.fill(Math.round(xa), y, Math.max(Math.round(xa) + 1, Math.round(xb)), y + 1, color);
        }
    }
}
