package kz.alih.visuals.knife;

import kz.alih.visuals.cosmetics.BBModel;
import kz.alih.visuals.replacer.ReplacerConfig;
import kz.alih.visuals.replacer.ReplacerSwap;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.joml.Matrix4f;

import java.util.function.Function;

/**
 * First-person rendering of a CS2 knife with its original animations:
 * draw when it is taken out, idle loop, melee_1/melee_2 on every swing, inspect on the Inspect key.
 * Position / size can be adjusted in game with the ViewModel module (it is applied before this runs).
 */
public final class KnifeAnim {
    /** where the knife sits in the first-person view, in blocks (x = to the right, y = up, -z = forward) */
    private static final float OFF_X = 0.28f, OFF_Y = -0.30f, OFF_Z = -0.70f;
    /** 1.0 = the model's own size (1 model unit = 1/16 block) */
    private static final float SCALE = 1.0f;

    private static String anim = "draw";
    private static boolean loop;
    private static long startMs;
    private static long lastRenderMs;
    private static String lastKnife = "";
    private static float prevSwing;
    private static boolean low;
    private static boolean inspectRequested;
    private static int attackCount, inspectCount;

    private KnifeAnim() {}

    public static void requestInspect() { inspectRequested = true; }

    /** @return true when the knife was drawn and vanilla must not render the item */
    public static boolean render(AbstractClientPlayerEntity player, Hand hand, float swing, float equip,
                                 ItemStack stack, MatrixStack ms, VertexConsumerProvider vcp, int light) {
        if (hand != Hand.MAIN_HAND || stack == null || stack.isEmpty() || ReplacerSwap.bypass) return false;
        ReplacerConfig c = ReplacerConfig.get();
        if (!c.enabled || !c.item.isEmpty()) return false;
        Knives.Info k = Knives.byName(c.weapon);
        if (k == null) return false;
        if (!c.replaces(Registries.ITEM.getId(stack.getItem()).toString())) return false;
        BBModel m = Knives.model(k);
        if (m == null) return false;

        long now = System.currentTimeMillis();
        boolean fresh = !k.id.equals(lastKnife) || now - lastRenderMs > 300L;
        if (fresh) {
            lastKnife = k.id;
            low = false;
            inspectRequested = false;
            prevSwing = swing;
            play(m, "draw", false, now);
        } else {
            // vanilla lowers the item to equip >= 1 while switching, then raises it again -> play draw again
            if (equip > 0.9f) low = true;
            else if (low) { low = false; play(m, "draw", false, now); }
            if (swing > 0f && prevSwing <= 0f) {
                play(m, (attackCount++ & 1) == 0 ? "melee_1" : "melee_2", false, now);
                inspectRequested = false;
            }
            prevSwing = swing;
            if (inspectRequested) {
                inspectRequested = false;
                String[] names = {"inspect", "inspect_1", "inspect_2"};
                for (int i = 0; i < names.length; i++) {
                    String n = names[(inspectCount + i) % names.length];
                    if (m.hasAnim(n)) { inspectCount = (inspectCount + i + 1) % names.length; play(m, n, false, now); break; }
                }
            }
        }
        lastRenderMs = now;

        float t = (now - startMs) / 1000f;
        float len = m.length(anim);
        if (!loop && t >= len) {
            play(m, idleName(m), true, now);
            t = 0f;
            len = m.length(anim);
        }
        float pt = loop || len <= 0f ? t : Math.min(t, len - 0.001f);
        Function<String, float[]> pose = m.pose(anim, pt);

        float sx = player.getMainArm() == Arm.LEFT ? -1f : 1f;
        float[] ctr = k.center;
        Matrix4f chain = new Matrix4f()
                .scale(sx, 1f, 1f)
                .translate(OFF_X, OFF_Y, OFF_Z)
                .scale(SCALE / 16f)
                .translate(-ctr[0], -ctr[1], -ctr[2])
                .scale(-1f, 1f, 1f);            // converted models use mirrored X (Blockbench space)
        m.render(ms, vcp, light, OverlayTexture.DEFAULT_UV, chain, pose);
        return true;
    }

    private static String idleName(BBModel m) {
        return m.hasAnim("static_idle") ? "static_idle" : "idle";
    }

    private static void play(BBModel m, String name, boolean looping, long now) {
        if (!m.hasAnim(name)) { name = idleName(m); looping = true; }
        anim = name;
        loop = looping;
        startMs = now;
    }
}
