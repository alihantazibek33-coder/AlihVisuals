package kz.alih.visuals;

/** Extra data attached to ItemEntityRenderState by a mixin. */
public interface PhysicsHolder {
    void alih$set(float blend, float angle, float yaw);
    float alih$blend();
    float alih$angle();
    float alih$yaw();
}
