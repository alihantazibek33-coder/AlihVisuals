package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class PingModule extends ClientModule {
    public PingModule() { super("Ping", "Shows connection latency when available.", ModuleCategory.HUD); }
}
