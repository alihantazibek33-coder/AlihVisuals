package kz.alih.visuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class WorldRender {
    private WorldRender() {}

    private static final class Circle {
        final double x, y, z; final long start;
        Circle(double x, double y, double z) { this.x = x; this.y = y; this.z = z; this.start = System.currentTimeMillis(); }
    }

    private static final List<Circle> CIRCLES = new ArrayList<>();
    private static final long CIRCLE_MS = 1100;
    private static boolean wasGround = true;

    public static void register() { WorldRenderEvents.AFTER_ENTITIES.register(WorldRender::render); }

    /** called every client tick */
    public static void tick(MinecraftClient mc) {
        PlayerEntity p = mc.player;
        if (p == null) { wasGround = true; return; }
        if (Modules.JUMPCIRCLES.enabled && wasGround && !p.isOnGround() && p.getVelocity().y > 0.1) {
            CIRCLES.add(new Circle(p.prevX, p.prevY, p.prevZ));
        }
        wasGround = p.isOnGround();
    }

    // ---- vertex helpers (quads are emitted double-sided) ----
    private static void v(VertexConsumer vc, Matrix4f m, float x, float y, float z, int argb) {
        vc.vertex(m, x, y, z).color(argb);
    }

    private static void quad(VertexConsumer vc, Matrix4f m,
                             float x1, float y1, float z1, int c1, float x2, float y2, float z2, int c2,
                             float x3, float y3, float z3, int c3, float x4, float y4, float z4, int c4) {
        v(vc, m, x1, y1, z1, c1); v(vc, m, x2, y2, z2, c2); v(vc, m, x3, y3, z3, c3); v(vc, m, x4, y4, z4, c4);
        v(vc, m, x4, y4, z4, c4); v(vc, m, x3, y3, z3, c3); v(vc, m, x2, y2, z2, c2); v(vc, m, x1, y1, z1, c1);
    }

    private static void box(VertexConsumer vc, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2, int c) {
        quad(vc, m, x1, y1, z1, c, x2, y1, z1, c, x2, y1, z2, c, x1, y1, z2, c); // bottom
        quad(vc, m, x1, y2, z1, c, x2, y2, z1, c, x2, y2, z2, c, x1, y2, z2, c); // top
        quad(vc, m, x1, y1, z1, c, x2, y1, z1, c, x2, y2, z1, c, x1, y2, z1, c); // north
        quad(vc, m, x1, y1, z2, c, x2, y1, z2, c, x2, y2, z2, c, x1, y2, z2, c); // south
        quad(vc, m, x1, y1, z1, c, x1, y1, z2, c, x1, y2, z2, c, x1, y2, z1, c); // west
        quad(vc, m, x2, y1, z1, c, x2, y1, z2, c, x2, y2, z2, c, x2, y2, z1, c); // east
    }

    private static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (ms == null || vcp == null) return;
        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(false);

        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLightning());
        ms.push();
        Matrix4f m = ms.peek().getPositionMatrix();

        if (Modules.CHINAHAT.enabled && !mc.options.getPerspective().isFirstPerson()) chinaHat(vc, m, mc.player, cam, td);
        if (Modules.BLOCKOVERLAY.enabled) blockOverlay(vc, m, mc, cam);
        if (Modules.JUMPCIRCLES.enabled) jumpCircles(vc, m, cam);
        else CIRCLES.clear();

        ms.pop();
    }

    private static void chinaHat(VertexConsumer vc, Matrix4f m, PlayerEntity p, Vec3d cam, float td) {
        float x = (float) (MathHelper.lerp(td, p.prevX, p.getX()) - cam.x);
        float y = (float) (MathHelper.lerp(td, p.prevY, p.getY()) - cam.y + p.getHeight() - 0.03);
        float z = (float) (MathHelper.lerp(td, p.prevZ, p.getZ()) - cam.z);
        final int n = 48;
        final float r = 0.62f, hgt = 0.34f;
        int apex = Colors.argb(235, 0x9FE9FF), base = Colors.argb(170, 0x2FA8FF);
        int ringIn = Colors.argb(255, 0x7FDFFF), ringOut = Colors.argb(0, 0x7FDFFF);
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            quad(vc, m, x + c0 * r, y, z + s0 * r, base, x + c1 * r, y, z + s1 * r, base,
                    x, y + hgt, z, apex, x, y + hgt, z, apex);
            // bright rim at the edge of the brim
            float ro = r + 0.05f;
            quad(vc, m, x + c0 * r, y, z + s0 * r, ringIn, x + c1 * r, y, z + s1 * r, ringIn,
                    x + c1 * ro, y, z + s1 * ro, ringOut, x + c0 * ro, y, z + s0 * ro, ringOut);
        }
    }

    private static void blockOverlay(VertexConsumer vc, Matrix4f m, MinecraftClient mc, Vec3d cam) {
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = hit.getBlockPos();
        VoxelShape shape = mc.world.getBlockState(pos).getOutlineShape(mc.world, pos);
        if (shape.isEmpty()) return;
        int col = Colors.argb(85, Modules.BLOCKOVERLAY.rgb());
        final float e = 0.002f;
        float ox = (float) (pos.getX() - cam.x), oy = (float) (pos.getY() - cam.y), oz = (float) (pos.getZ() - cam.z);
        shape.forEachBox((x1, y1, z1, x2, y2, z2) ->
                box(vc, m, ox + (float) x1 - e, oy + (float) y1 - e, oz + (float) z1 - e,
                        ox + (float) x2 + e, oy + (float) y2 + e, oz + (float) z2 + e, col));
    }

    private static void ring(VertexConsumer vc, Matrix4f m, float x, float y, float z, float rIn, float rOut, int cIn, int cOut) {
        final int n = 64;
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            quad(vc, m, x + c0 * rIn, y, z + s0 * rIn, cIn, x + c1 * rIn, y, z + s1 * rIn, cIn,
                    x + c1 * rOut, y, z + s1 * rOut, cOut, x + c0 * rOut, y, z + s0 * rOut, cOut);
        }
    }

    private static void jumpCircles(VertexConsumer vc, Matrix4f m, Vec3d cam) {
        long now = System.currentTimeMillis();
        int rgb = Modules.JUMPCIRCLES.rgb();
        int rgb2 = Colors.hsb(Modules.JUMPCIRCLES.value + 0.08f, 0.6f, 1f);
        for (Iterator<Circle> it = CIRCLES.iterator(); it.hasNext(); ) {
            Circle c = it.next();
            float t = (now - c.start) / (float) CIRCLE_MS;
            if (t >= 1f) { it.remove(); continue; }
            float ease = 1f - (float) Math.pow(1f - t, 3);
            float fade = 1f - t;
            float x = (float) (c.x - cam.x), y = (float) (c.y - cam.y) + 0.03f, z = (float) (c.z - cam.z);
            float r = 0.3f + ease * 1.9f;
            // main ring + soft glow disc
            ring(vc, m, x, y, z, r - 0.22f, r, Colors.argb(0, rgb), Colors.argb((int) (240 * fade), rgb));
            ring(vc, m, x, y, z, 0f, r - 0.22f, Colors.argb((int) (40 * fade), rgb), Colors.argb(0, rgb));
            // thin outer edge
            ring(vc, m, x, y + 0.001f, z, r, r + 0.05f, Colors.argb((int) (255 * fade), 0xFFFFFF), Colors.argb(0, 0xFFFFFF));
            // second smaller, delayed ring
            float t2 = Math.max(0f, t - 0.15f) / 0.85f;
            if (t2 > 0f) {
                float r2 = 0.2f + (1f - (float) Math.pow(1f - t2, 3)) * 1.1f;
                ring(vc, m, x, y + 0.002f, z, r2 - 0.12f, r2, Colors.argb(0, rgb2), Colors.argb((int) (200 * (1f - t2)), rgb2));
            }
        }
    }
}
