package kz.alih.visuals.knife;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import kz.alih.visuals.cosmetics.BBModel;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** The bundled CS2 knives (converted from the "CS2 Knifes Pack" geo models): name list + lazily loaded animated models. */
public final class Knives {
    public static final class Info {
        public final String id, name;
        /** centre of the idle pose in the pack's own model space (Bedrock units) */
        public final float[] center;

        Info(String id, String name, float[] center) {
            this.id = id;
            this.name = name;
            this.center = center;
        }
    }

    private static final Map<String, Info> BY_NAME = new LinkedHashMap<>();
    private static final Map<String, BBModel> MODELS = new HashMap<>();
    private static final Set<String> FAILED = new HashSet<>();
    private static boolean loaded;

    private Knives() {}

    public static synchronized Info byName(String name) {
        load();
        return name == null || name.isEmpty() ? null : BY_NAME.get(name);
    }

    /** null if the model could not be loaded (the flat item icon is shown instead) */
    public static synchronized BBModel model(Info k) {
        if (k == null || FAILED.contains(k.id)) return null;
        BBModel m = MODELS.get(k.id);
        if (m != null) return m;
        try (InputStream in = Knives.class.getResourceAsStream("/assets/alihvisuals/knives/" + k.id + ".bbmodel")) {
            if (in == null) throw new IllegalStateException("missing model " + k.id);
            m = BBModel.loadText("knife:" + k.id, new String(in.readAllBytes(), StandardCharsets.UTF_8));
            if (m == null) throw new IllegalStateException("bad model " + k.id);
            MODELS.put(k.id, m);
            return m;
        } catch (Throwable t) {
            FAILED.add(k.id);
            return null;
        }
    }

    private static void load() {
        if (loaded) return;
        loaded = true;
        try (InputStream in = Knives.class.getResourceAsStream("/assets/alihvisuals/knives/index.json")) {
            if (in == null) return;
            JsonArray arr = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonArray();
            for (JsonElement e : arr) {
                JsonObject o = e.getAsJsonObject();
                JsonArray c = o.getAsJsonArray("center");
                float[] ctr = {c.get(0).getAsFloat(), c.get(1).getAsFloat(), c.get(2).getAsFloat()};
                String name = o.get("name").getAsString();
                BY_NAME.put(name, new Info(o.get("id").getAsString(), name, ctr));
            }
        } catch (Throwable ignored) {}
    }
}
