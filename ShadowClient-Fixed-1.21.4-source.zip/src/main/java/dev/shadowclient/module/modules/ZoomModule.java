package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class ZoomModule extends ClientModule {
    public ZoomModule() { super("Zoom", "Hold a configurable key to zoom the view.", ModuleCategory.VISUALS); }
}
