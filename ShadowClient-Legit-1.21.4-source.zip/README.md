# ShadowClient — Legit Visual / QoL starter (Minecraft Java 1.21.4 Fabric)

This source project contains a custom dark-purple ClickGUI opened with Right Shift, a module registry, and 20 visual/HUD/quality-of-life module entries.

Important: the current build is a starter framework. The menu and toggle states work, but module entries are not all connected to gameplay/render events yet. This edition intentionally focuses on visual customization and quality-of-life tools rather than automated combat or hidden-player tracking.

## Build
Requirements: JDK 21 and Gradle 8.10.x.
Run `gradle build` in this folder. The output JAR will be in `build/libs/`.

Install the JAR into `.minecraft/mods` alongside Fabric Loader and Fabric API for Minecraft 1.21.4.
