package kz.alih.visuals.music;

import kz.alih.visuals.AlihMenu;
import kz.alih.visuals.Colors;
import kz.alih.visuals.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

/** "Музыка": list of the tracks from config/alihvisuals/music with a small player. */
public class MusicScreen extends Screen {
    private static final int CYAN = 0xFF5CE1FF;
    private static final int ROW_H = 24, ROW_GAP = 3;

    private final long openedAt = System.currentTimeMillis();
    private float al = 1f;
    private int px, py, pw, ph, lx, ly, lw, lh;
    private int barY;                      // top of the bottom player area
    private float scroll, maxScroll;
    private boolean pressActive, moved, dragVol;
    private double pressY;
    private int pressIndex = -1;

    public MusicScreen() { super(Text.literal("Music")); }

    @Override protected void init() { MusicPlayer.refresh(); layout(); }
    @Override public boolean shouldPause() { return false; }
    @Override public void close() { client.setScreen(new AlihMenu()); }

    private void layout() {
        pw = Math.min(width - 8, 460);
        ph = Math.min(height - 8, 320);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        lx = px + 10;
        ly = py + 46;
        lw = pw - 26;
        barY = py + ph - 74;
        lh = barY - 6 - ly;
        int n = MusicPlayer.tracks().size();
        maxScroll = Math.max(0, n * (ROW_H + ROW_GAP) - ROW_GAP - lh);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
    }

    private int A(int c) { return Colors.mulAlpha(c, al); }
    private void rr(DrawContext c, int x, int y, int w, int h, int r, int col) { Gfx.rrect(c, x, y, w, h, r, A(col)); }
    private void text(DrawContext c, String s, int x, int y, int col) {
        col = A(col);
        if ((col >>> 24) < 8) return;
        c.drawTextWithShadow(textRenderer, s, x, y, col);
    }
    private void ctext(DrawContext c, String s, int cx, int y, int col) {
        col = A(col);
        if ((col >>> 24) < 8) return;
        c.drawCenteredTextWithShadow(textRenderer, s, cx, y, col);
    }
    private boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    private static float clamp01(float v) { return v < 0f ? 0f : Math.min(1f, v); }

    private static String time(long ms) {
        if (ms < 0) return "--:--";
        long s = ms / 1000;
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    // button geometry (shared by render + click)
    private int playX() { return px + pw / 2 - 15; }
    private int btnY() { return py + ph - 30; }
    private int prevX() { return playX() - 30; }
    private int nextX() { return playX() + 36; }
    private int loopX() { return px + 10; }
    private int volX() { return px + pw - 10 - 110; }

    // ------------------------------------------------------------------ render
    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        float v = clamp01((System.currentTimeMillis() - openedAt) / 250f);
        c.fill(0, 0, width, height, Colors.mulAlpha(0xB0090B10, v));
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();
        float f = clamp01((System.currentTimeMillis() - openedAt) / 260f);
        al = 1f - (1f - f) * (1f - f);
        long now = System.currentTimeMillis();

        rr(c, px - 1, py - 1, pw + 2, ph + 2, 11, 0xFF2C313C);
        rr(c, px, py, pw, ph, 10, 0xF01A1D24);
        ctext(c, "Музыка", px + pw / 2, py + 10, CYAN);

        boolean bh = in(mx, my, px + 8, py + 6, 62, 16);
        rr(c, px + 8, py + 6, 62, 16, 7, bh ? 0xFF343946 : 0xFF2A2E38);
        ctext(c, "‹ Артқа", px + 8 + 31, py + 10, 0xFFB8BFCC);

        boolean rh = in(mx, my, px + pw - 78, py + 6, 70, 16);
        rr(c, px + pw - 78, py + 6, 70, 16, 7, rh ? 0xFF343946 : 0xFF2A2E38);
        ctext(c, "Жаңарту", px + pw - 78 + 35, py + 10, 0xFFB8BFCC);

        text(c, "config/alihvisuals/music", px + 12, py + 30, 0xFF5E6575);

        // ---- track list
        List<MusicPlayer.Track> tracks = MusicPlayer.tracks();
        int cur = MusicPlayer.current();
        boolean playing = MusicPlayer.isPlaying() && !MusicPlayer.isPaused();
        c.enableScissor(lx - 2, ly, lx + lw + 2, ly + lh);
        for (int i = 0; i < tracks.size(); i++) {
            int y = ly - (int) scroll + i * (ROW_H + ROW_GAP);
            if (y + ROW_H < ly || y > ly + lh) continue;
            MusicPlayer.Track t = tracks.get(i);
            boolean sel = i == cur && MusicPlayer.isPlaying();
            boolean hov = in(mx, my, lx, y, lw, ROW_H) && my >= ly && my < ly + lh;
            rr(c, lx, y, lw, ROW_H, 7, sel ? 0xFF4FC3F7 : 0xFF2C313C);
            rr(c, lx + 1, y + 1, lw - 2, ROW_H - 2, 6, hov ? 0xFF2D323E : 0xFF23262E);

            // equaliser bars for the current track, otherwise the number
            if (sel) {
                for (int b = 0; b < 3; b++) {
                    float hgt = playing ? 3f + 9f * (0.5f + 0.5f * (float) Math.sin(now / 160.0 + b * 1.9)) : 4f;
                    rr(c, lx + 9 + b * 4, y + ROW_H - 7 - (int) hgt, 3, (int) hgt, 1, 0xFF5CE1FF);
                }
            } else {
                text(c, String.valueOf(i + 1), lx + 9, y + 8, 0xFF5E6575);
            }
            String dur = time(t.durationMs);
            int dw = textRenderer.getWidth(dur);
            text(c, textRenderer.trimToWidth(t.name, lw - 36 - dw - 14), lx + 26, y + 8,
                    t.failed ? 0xFFFF8A8A : (sel ? CYAN : 0xFFE6E9EF));
            text(c, dur, lx + lw - dw - 9, y + 8, 0xFF8A90A0);
        }
        c.disableScissor();

        if (tracks.isEmpty()) {
            ctext(c, "Музыка табылмады", px + pw / 2, ly + 30, 0xFFB8BFCC);
            ctext(c, "Файлдарды (mp3, wav ...) осы папкаға сал:", px + pw / 2, ly + 46, 0xFF8A90A0);
            ctext(c, "config/alihvisuals/music", px + pw / 2, ly + 60, CYAN);
            ctext(c, "содан кейін \"Жаңарту\" бас", px + pw / 2, ly + 74, 0xFF8A90A0);
        }
        if (maxScroll > 0) {
            int barH = Math.max(18, (int) (lh * lh / (lh + maxScroll)));
            int bY = ly + (int) ((lh - barH) * (scroll / maxScroll));
            rr(c, px + pw - 8, bY, 3, barH, 1, 0xFF3FA9C9);
        }

        // ---- player bar
        rr(c, px + 8, barY, pw - 16, 1, 0, 0xFF2C313C);
        MusicPlayer.Track ct = MusicPlayer.currentTrack();
        String title = ct == null ? "Ештеңе ойнап тұрған жоқ" : ct.name;
        String status = MusicPlayer.status();
        text(c, textRenderer.trimToWidth(title, pw - 40), px + 12, barY + 7, ct == null ? 0xFF8A90A0 : 0xFFE6E9EF);
        if (!status.isEmpty()) text(c, textRenderer.trimToWidth(status, pw - 40), px + 12, barY + 19, 0xFFFFB4C0);

        // progress
        long pos = MusicPlayer.isPlaying() ? MusicPlayer.positionMs() : 0;
        long dur = ct == null ? -1 : ct.durationMs;
        int bx = px + 12, bw = pw - 24, by = barY + 32;
        rr(c, bx, by, bw, 4, 2, 0xFF2C313C);
        if (dur > 0) {
            int fw = (int) (bw * Math.min(1.0, pos / (double) dur));
            if (fw > 1) rr(c, bx, by, fw, 4, 2, 0xFF4FC3F7);
        }
        text(c, time(pos), bx, by + 7, 0xFF8A90A0);
        String ds = time(dur);
        text(c, ds, bx + bw - textRenderer.getWidth(ds), by + 7, 0xFF8A90A0);

        // controls
        int yb = btnY();
        boolean ph1 = in(mx, my, prevX(), yb, 26, 20), ph2 = in(mx, my, playX(), yb, 30, 20), ph3 = in(mx, my, nextX(), yb, 26, 20);
        rr(c, prevX(), yb, 26, 20, 7, ph1 ? 0xFF343946 : 0xFF2A2E38);
        rr(c, playX(), yb, 30, 20, 7, ph2 ? 0xFF5CD0F5 : 0xFF4FC3F7);
        rr(c, nextX(), yb, 26, 20, 7, ph3 ? 0xFF343946 : 0xFF2A2E38);
        int ic = A(0xFFE6E9EF), icDark = A(0xFF0E1218);
        // prev |<
        c.fill(prevX() + 8, yb + 5, prevX() + 10, yb + 15, ic);
        Gfx.triangle(c, prevX() + 19, yb + 5, prevX() + 19, yb + 15, prevX() + 11, yb + 10, ic);
        // next >|
        c.fill(nextX() + 16, yb + 5, nextX() + 18, yb + 15, ic);
        Gfx.triangle(c, nextX() + 7, yb + 5, nextX() + 7, yb + 15, nextX() + 15, yb + 10, ic);
        // play / pause
        if (playing) {
            c.fill(playX() + 10, yb + 5, playX() + 13, yb + 15, icDark);
            c.fill(playX() + 17, yb + 5, playX() + 20, yb + 15, icDark);
        } else {
            Gfx.triangle(c, playX() + 11, yb + 4, playX() + 11, yb + 16, playX() + 21, yb + 10, icDark);
        }

        // loop
        boolean loop = MusicPlayer.isLoop();
        boolean lh1 = in(mx, my, loopX(), yb, 52, 20);
        rr(c, loopX(), yb, 52, 20, 7, loop ? 0xFF4FC3F7 : (lh1 ? 0xFF343946 : 0xFF2A2E38));
        ctext(c, "Loop", loopX() + 26, yb + 6, loop ? 0xFF0E1218 : 0xFFB8BFCC);

        // volume
        int vx = volX() + 24, vw = 86;
        text(c, "Vol", volX(), yb + 6, 0xFF8A90A0);
        rr(c, vx, yb + 8, vw, 4, 2, 0xFF2C313C);
        int vf = (int) (vw * MusicPlayer.volume());
        if (vf > 1) rr(c, vx, yb + 8, vf, 4, 2, 0xFF4FC3F7);
        Gfx.circle(c, vx + vf, yb + 10, dragVol ? 6f : 5f, A(0xFFFFFFFF));
        al = 1f;
    }

    // ------------------------------------------------------------------ input
    private int rowAt(double mx, double my) {
        if (my < ly || my >= ly + lh || mx < lx || mx >= lx + lw) return -1;
        int i = (int) ((my - ly + scroll) / (ROW_H + ROW_GAP));
        int y = ly - (int) scroll + i * (ROW_H + ROW_GAP);
        if (i < 0 || i >= MusicPlayer.tracks().size() || my >= y + ROW_H) return -1;
        return i;
    }

    private void setVolume(double mx) {
        int vx = volX() + 24, vw = 86;
        MusicPlayer.setVolume((float) ((mx - vx) / vw));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        if (in(mx, my, px + 8, py + 6, 62, 16)) { close(); return true; }
        if (in(mx, my, px + pw - 78, py + 6, 70, 16)) { MusicPlayer.refresh(); return true; }
        int yb = btnY();
        if (in(mx, my, prevX(), yb, 26, 20)) { MusicPlayer.prev(); return true; }
        if (in(mx, my, playX(), yb, 30, 20)) { MusicPlayer.togglePause(); return true; }
        if (in(mx, my, nextX(), yb, 26, 20)) { MusicPlayer.next(); return true; }
        if (in(mx, my, loopX(), yb, 52, 20)) { MusicPlayer.toggleLoop(); return true; }
        if (in(mx, my, volX() + 24 - 6, yb, 98, 20)) { dragVol = true; setVolume(mx); return true; }
        if (my >= ly && my < ly + lh) {
            pressActive = true; moved = false; pressY = my; pressIndex = rowAt(mx, my);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragVol) { setVolume(mx); return true; }
        if (pressActive) {
            if (Math.abs(my - pressY) > 5) moved = true;
            if (moved) scroll = Math.max(0, Math.min(maxScroll, scroll - (float) dy));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragVol = false;
        if (pressActive && !moved && pressIndex >= 0 && pressIndex == rowAt(mx, my)) {
            if (pressIndex == MusicPlayer.current() && MusicPlayer.isPlaying()) MusicPlayer.togglePause();
            else MusicPlayer.play(pressIndex);
        }
        pressActive = false; pressIndex = -1;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scroll = Math.max(0, Math.min(maxScroll, scroll - (float) vAmount * 28f));
        return true;
    }
}
