package kz.alih.visuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class WorldRender {
    private WorldRender() {}

    private static final class Circle {
        final double x, y, z; final long start;
        Circle(double x, double y, double z) { this.x = x; this.y = y; this.z = z; this.start = System.currentTimeMillis(); }
    }

    private static final class TP {
        final double x, y, z; final long t;
        TP(double x, double y, double z, long t) { this.x = x; this.y = y; this.z = z; this.t = t; }
    }

    /** snapshot of the trail used by the Trails styles (index n-1 = current position) */
    private static final class TrailData {
        double[] x, y, z; float[] life; long[] age; int n; boolean first; long now; float base;
        Vector3f right, up;
    }

    private static final List<TP> TRAIL = new ArrayList<>();
    private static final long TRAIL_MS = 1100;
    private static final List<Circle> CIRCLES = new ArrayList<>();
    private static final long CIRCLE_MS = 1100;
    private static boolean wasGround = true;

    public static void register() { WorldRenderEvents.AFTER_ENTITIES.register(WorldRender::render); }

    /** called every client tick */
    public static void tick(MinecraftClient mc) {
        PlayerEntity p = mc.player;
        if (p == null) { wasGround = true; TRAIL.clear(); return; }
        if (Modules.TRAILS.enabled) {
            final long now = System.currentTimeMillis();
            TP last = TRAIL.isEmpty() ? null : TRAIL.get(TRAIL.size() - 1);
            double dx = last == null ? 1 : p.getX() - last.x, dy = last == null ? 0 : p.getY() - last.y,
                    dz = last == null ? 0 : p.getZ() - last.z;
            if (dx * dx + dy * dy + dz * dz > 0.0025) TRAIL.add(new TP(p.getX(), p.getY(), p.getZ(), now));
            TRAIL.removeIf(t -> now - t.t > TRAIL_MS);
        } else {
            TRAIL.clear();
        }
        if (Modules.JUMPCIRCLES.enabled && wasGround && !p.isOnGround() && p.getVelocity().y > 0.1) {
            CIRCLES.add(new Circle(p.prevX, p.prevY, p.prevZ));
        }
        wasGround = p.isOnGround();
    }

    // ---------------------------------------------------------------- vertex helpers (quads are emitted double-sided)
    private static void v(VertexConsumer vc, Matrix4f m, float x, float y, float z, int argb) {
        vc.vertex(m, x, y, z).color(argb);
    }

    private static void quad(VertexConsumer vc, Matrix4f m,
                             float x1, float y1, float z1, int c1, float x2, float y2, float z2, int c2,
                             float x3, float y3, float z3, int c3, float x4, float y4, float z4, int c4) {
        v(vc, m, x1, y1, z1, c1); v(vc, m, x2, y2, z2, c2); v(vc, m, x3, y3, z3, c3); v(vc, m, x4, y4, z4, c4);
        v(vc, m, x4, y4, z4, c4); v(vc, m, x3, y3, z3, c3); v(vc, m, x2, y2, z2, c2); v(vc, m, x1, y1, z1, c1);
    }

    private static void tri(VertexConsumer vc, Matrix4f m,
                            float x1, float y1, float z1, int c1, float x2, float y2, float z2, int c2,
                            float x3, float y3, float z3, int c3) {
        quad(vc, m, x1, y1, z1, c1, x2, y2, z2, c2, x3, y3, z3, c3, x3, y3, z3, c3);
    }

    private static void box(VertexConsumer vc, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2, int c) {
        quad(vc, m, x1, y1, z1, c, x2, y1, z1, c, x2, y1, z2, c, x1, y1, z2, c); // bottom
        quad(vc, m, x1, y2, z1, c, x2, y2, z1, c, x2, y2, z2, c, x1, y2, z2, c); // top
        quad(vc, m, x1, y1, z1, c, x2, y1, z1, c, x2, y2, z1, c, x1, y2, z1, c); // north
        quad(vc, m, x1, y1, z2, c, x2, y1, z2, c, x2, y2, z2, c, x1, y2, z2, c); // south
        quad(vc, m, x1, y1, z1, c, x1, y1, z2, c, x1, y2, z2, c, x1, y2, z1, c); // west
        quad(vc, m, x2, y1, z1, c, x2, y1, z2, c, x2, y2, z2, c, x2, y2, z1, c); // east
    }

    private static void glow(VertexConsumer vc, Matrix4f m, float x, float y, float z, Vector3f r, Vector3f u,
                             float rad, int n, int cIn, int cOut) {
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            float x0 = x + (r.x * c0 + u.x * s0) * rad, y0 = y + (r.y * c0 + u.y * s0) * rad, z0 = z + (r.z * c0 + u.z * s0) * rad;
            float x1 = x + (r.x * c1 + u.x * s1) * rad, y1 = y + (r.y * c1 + u.y * s1) * rad, z1 = z + (r.z * c1 + u.z * s1) * rad;
            tri(vc, m, x, y, z, cIn, x0, y0, z0, cOut, x1, y1, z1, cOut);
        }
    }

    private static void ring(VertexConsumer vc, Matrix4f m, float x, float y, float z, float rIn, float rOut, int cIn, int cOut) {
        arc(vc, m, x, y, z, rIn, rOut, 0f, (float) (Math.PI * 2), 64, cIn, cOut, cIn, cOut);
    }

    /** flat arc; t=0 (tail) -> t=1 (head); colours given as {tailIn, tailOut, headIn, headOut} */
    private static void arc(VertexConsumer vc, Matrix4f m, float x, float y, float z, float rIn, float rOut,
                            float a0, float len, int segs, int tIn, int tOut, int hIn, int hOut) {
        for (int i = 0; i < segs; i++) {
            float f0 = i / (float) segs, f1 = (i + 1) / (float) segs;
            float aa = a0 + len * f0, ab = a0 + len * f1;
            float c0 = (float) Math.cos(aa), s0 = (float) Math.sin(aa), c1 = (float) Math.cos(ab), s1 = (float) Math.sin(ab);
            int i0 = Colors.lerp(tIn, hIn, f0), o0 = Colors.lerp(tOut, hOut, f0);
            int i1 = Colors.lerp(tIn, hIn, f1), o1 = Colors.lerp(tOut, hOut, f1);
            quad(vc, m, x + c0 * rIn, y, z + s0 * rIn, i0, x + c1 * rIn, y, z + s1 * rIn, i1,
                    x + c1 * rOut, y, z + s1 * rOut, o1, x + c0 * rOut, y, z + s0 * rOut, o0);
        }
    }

    // ---------------------------------------------------------------- main render hook
    private static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (ms == null || vcp == null) return;
        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(false);
        boolean first = mc.options.getPerspective().isFirstPerson();

        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLightning());
        ms.push();
        Matrix4f m = ms.peek().getPositionMatrix();

        if (Modules.CHINAHAT.enabled && !first) chinaHat(vc, m, mc.player, cam, td);
        if (Modules.BLOCKOVERLAY.enabled) blockOverlay(vc, m, mc, cam);
        if (Modules.HITBOX.enabled) hitBoxes(vc, m, mc, cam, td);
        if (Modules.TARGETRENDER.enabled) targetRender(vc, m, cam, ctx.camera(), td);
        if (Modules.TRAILS.enabled) trails(vc, m, cam, ctx.camera(), mc.player, td, first);
        if (Modules.JUMPCIRCLES.enabled) jumpCircles(vc, m, cam);
        else CIRCLES.clear();

        ms.pop();
    }

    // ---------------------------------------------------------------- ChinaHat
    private static void chinaHat(VertexConsumer vc, Matrix4f m, PlayerEntity p, Vec3d cam, float td) {
        float x = (float) (MathHelper.lerp(td, p.prevX, p.getX()) - cam.x);
        float y = (float) (MathHelper.lerp(td, p.prevY, p.getY()) - cam.y + p.getHeight() - 0.03);
        float z = (float) (MathHelper.lerp(td, p.prevZ, p.getZ()) - cam.z);
        final int n = 48;
        final float r = 0.62f, hgt = 0.34f;
        float h = Modules.CHINAHAT.value;
        int apex = Colors.argb(235, Colors.hsb(h, 0.38f, 1f));
        int base = Colors.argb(170, Colors.hsb(h, 0.85f, 1f));
        int rimRgb = Colors.hsb(h, 0.5f, 1f);
        int ringIn = Colors.argb(255, rimRgb), ringOut = Colors.argb(0, rimRgb);
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            tri(vc, m, x + c0 * r, y, z + s0 * r, base, x + c1 * r, y, z + s1 * r, base, x, y + hgt, z, apex);
            float ro = r + 0.05f;
            quad(vc, m, x + c0 * r, y, z + s0 * r, ringIn, x + c1 * r, y, z + s1 * r, ringIn,
                    x + c1 * ro, y, z + s1 * ro, ringOut, x + c0 * ro, y, z + s0 * ro, ringOut);
        }
    }

    // ---------------------------------------------------------------- Block overlay
    private static void blockOverlay(VertexConsumer vc, Matrix4f m, MinecraftClient mc, Vec3d cam) {
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = hit.getBlockPos();
        VoxelShape shape = mc.world.getBlockState(pos).getOutlineShape(mc.world, pos);
        if (shape.isEmpty()) return;
        int col = Colors.argb(85, Modules.BLOCKOVERLAY.rgb());
        final float e = 0.002f;
        float ox = (float) (pos.getX() - cam.x), oy = (float) (pos.getY() - cam.y), oz = (float) (pos.getZ() - cam.z);
        shape.forEachBox((x1, y1, z1, x2, y2, z2) ->
                box(vc, m, ox + (float) x1 - e, oy + (float) y1 - e, oz + (float) z1 - e,
                        ox + (float) x2 + e, oy + (float) y2 + e, oz + (float) z2 + e, col));
    }

    // ---------------------------------------------------------------- HitBox
    private static void edges(VertexConsumer vc, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2,
                              float t, int c) {
        for (int a = 0; a < 2; a++) {
            float y = a == 0 ? y1 : y2;
            for (int b = 0; b < 2; b++) {
                float z = b == 0 ? z1 : z2;
                box(vc, m, x1 - t, y - t, z - t, x2 + t, y + t, z + t, c);          // along X
            }
        }
        for (int a = 0; a < 2; a++) {
            float x = a == 0 ? x1 : x2;
            for (int b = 0; b < 2; b++) {
                float z = b == 0 ? z1 : z2;
                box(vc, m, x - t, y1 - t, z - t, x + t, y2 + t, z + t, c);          // along Y
            }
        }
        for (int a = 0; a < 2; a++) {
            float x = a == 0 ? x1 : x2;
            for (int b = 0; b < 2; b++) {
                float y = b == 0 ? y1 : y2;
                box(vc, m, x - t, y - t, z1 - t, x + t, y + t, z2 + t, c);          // along Z
            }
        }
    }

    private static void corners(VertexConsumer vc, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2,
                                float t, int c) {
        float lx = Math.min(0.28f, (x2 - x1) * 0.4f), ly = Math.min(0.40f, (y2 - y1) * 0.25f), lz = Math.min(0.28f, (z2 - z1) * 0.4f);
        for (int i = 0; i < 8; i++) {
            float x = (i & 1) == 0 ? x1 : x2, y = (i & 2) == 0 ? y1 : y2, z = (i & 4) == 0 ? z1 : z2;
            float sx = (i & 1) == 0 ? 1 : -1, sy = (i & 2) == 0 ? 1 : -1, sz = (i & 4) == 0 ? 1 : -1;
            box(vc, m, Math.min(x, x + sx * lx) - t, y - t, z - t, Math.max(x, x + sx * lx) + t, y + t, z + t, c);
            box(vc, m, x - t, Math.min(y, y + sy * ly) - t, z - t, x + t, Math.max(y, y + sy * ly) + t, z + t, c);
            box(vc, m, x - t, y - t, Math.min(z, z + sz * lz) - t, x + t, y + t, Math.max(z, z + sz * lz) + t, c);
        }
    }

    private static void hitBoxes(VertexConsumer vc, Matrix4f m, MinecraftClient mc, Vec3d cam, float td) {
        Modules.Module hb = Modules.HITBOX;
        int rgb = Colors.hsb(hb.value, 0.75f, 1f);
        int white = Colors.hsb(hb.value, 0.15f, 1f);
        float fill = hb.extras.get(0).value;
        for (PlayerEntity pl : mc.world.getPlayers()) {
            if (pl == mc.player || pl.isSpectator()) continue;
            if (pl.squaredDistanceTo(mc.player) > 4096) continue;
            Box b = pl.getBoundingBox();
            double ox = MathHelper.lerp(td, pl.prevX, pl.getX()) - pl.getX();
            double oy = MathHelper.lerp(td, pl.prevY, pl.getY()) - pl.getY();
            double oz = MathHelper.lerp(td, pl.prevZ, pl.getZ()) - pl.getZ();
            float x1 = (float) (b.minX + ox - cam.x), y1 = (float) (b.minY + oy - cam.y), z1 = (float) (b.minZ + oz - cam.z);
            float x2 = (float) (b.maxX + ox - cam.x), y2 = (float) (b.maxY + oy - cam.y), z2 = (float) (b.maxZ + oz - cam.z);
            float eye = (float) (pl.getEyeY() + oy - cam.y);

            // soft translucent body
            int fillA = (int) (fill * 90);
            if (hb.mode == 1) fillA = Math.max(fillA, 30);
            if (fillA > 0) box(vc, m, x1, y1, z1, x2, y2, z2, Colors.argb(fillA, rgb));

            if (hb.mode == 2) corners(vc, m, x1, y1, z1, x2, y2, z2, 0.014f, Colors.argb(255, white));
            else edges(vc, m, x1, y1, z1, x2, y2, z2, 0.010f, Colors.argb(hb.mode == 1 ? 200 : 255, rgb));

            // eye line
            box(vc, m, x1, eye - 0.006f, z1, x2, eye + 0.006f, z2, Colors.argb(220, white));
        }
    }

    // ---------------------------------------------------------------- Jump circles
    private static void jumpCircles(VertexConsumer vc, Matrix4f m, Vec3d cam) {
        long now = System.currentTimeMillis();
        int rgb = Modules.JUMPCIRCLES.rgb();
        int rgb2 = Colors.hsb(Modules.JUMPCIRCLES.value + 0.08f, 0.6f, 1f);
        for (Iterator<Circle> it = CIRCLES.iterator(); it.hasNext(); ) {
            Circle c = it.next();
            float t = (now - c.start) / (float) CIRCLE_MS;
            if (t >= 1f) { it.remove(); continue; }
            float ease = 1f - (float) Math.pow(1f - t, 3);
            float fade = 1f - t;
            float x = (float) (c.x - cam.x), y = (float) (c.y - cam.y) + 0.03f, z = (float) (c.z - cam.z);
            float r = 0.3f + ease * 1.9f;
            ring(vc, m, x, y, z, r - 0.22f, r, Colors.argb(0, rgb), Colors.argb((int) (240 * fade), rgb));
            ring(vc, m, x, y, z, 0f, r - 0.22f, Colors.argb((int) (40 * fade), rgb), Colors.argb(0, rgb));
            ring(vc, m, x, y + 0.001f, z, r, r + 0.05f, Colors.argb((int) (255 * fade), 0xFFFFFF), Colors.argb(0, 0xFFFFFF));
            float t2 = Math.max(0f, t - 0.15f) / 0.85f;
            if (t2 > 0f) {
                float r2 = 0.2f + (1f - (float) Math.pow(1f - t2, 3)) * 1.1f;
                ring(vc, m, x, y + 0.002f, z, r2 - 0.12f, r2, Colors.argb(0, rgb2), Colors.argb((int) (200 * (1f - t2)), rgb2));
            }
        }
    }

    // ---------------------------------------------------------------- Trails (4 styles)
    private static void trails(VertexConsumer vc, Matrix4f m, Vec3d cam, Camera camera, PlayerEntity p, float td, boolean first) {
        final long now = System.currentTimeMillis();
        TRAIL.removeIf(t -> now - t.t > TRAIL_MS);
        int n = TRAIL.size() + 1;
        if (n < 2) return;
        TrailData d = new TrailData();
        d.n = n; d.first = first; d.now = now; d.base = Modules.TRAILS.value;
        d.x = new double[n]; d.y = new double[n]; d.z = new double[n];
        d.life = new float[n]; d.age = new long[n];
        d.right = new Vector3f(1, 0, 0).rotate(camera.getRotation());
        d.up = new Vector3f(0, 1, 0).rotate(camera.getRotation());
        for (int i = 0; i < n - 1; i++) {
            TP t = TRAIL.get(i);
            d.x[i] = t.x - cam.x; d.y[i] = t.y - cam.y; d.z[i] = t.z - cam.z;
            d.age[i] = now - t.t;
            d.life[i] = 1f - d.age[i] / (float) TRAIL_MS;
        }
        d.x[n - 1] = MathHelper.lerp(td, p.prevX, p.getX()) - cam.x;
        d.y[n - 1] = MathHelper.lerp(td, p.prevY, p.getY()) - cam.y;
        d.z[n - 1] = MathHelper.lerp(td, p.prevZ, p.getZ()) - cam.z;
        d.life[n - 1] = 1f;

        switch (Modules.TRAILS.mode) {
            case 1 -> trailWave(vc, m, d);
            case 2 -> trailSparks(vc, m, d);
            case 3 -> trailHelix(vc, m, d);
            default -> trailRibbon(vc, m, d);
        }
    }

    private static void trailRibbon(VertexConsumer vc, Matrix4f m, TrailData d) {
        final float[] heights = {0.40f, 0.90f, 1.40f};
        final float w = 0.09f;
        for (int j = 0; j < heights.length; j++) {
            for (int k = 1; k < d.n; k++) {
                if (d.first && d.age[k - 1] < 250) continue;
                float fa = Math.max(0f, d.life[k - 1]), fb = Math.max(0f, d.life[k]);
                int ca = Colors.argb((int) (200 * fa * fa), Colors.hsb(d.base + 0.06f * j + 0.10f * (1f - fa), 0.75f, 1f));
                int cb = Colors.argb((int) (200 * fb * fb), Colors.hsb(d.base + 0.06f * j + 0.10f * (1f - fb), 0.75f, 1f));
                float wa = (float) Math.sin(d.now / 220.0 + k * 0.55 + j) * 0.05f * (1f - fa);
                float wb = (float) Math.sin(d.now / 220.0 + (k + 1) * 0.55 + j) * 0.05f * (1f - fb);
                float ax = (float) d.x[k - 1], ay = (float) d.y[k - 1] + heights[j] + wa, az = (float) d.z[k - 1];
                float bx = (float) d.x[k], by = (float) d.y[k] + heights[j] + wb, bz = (float) d.z[k];
                quad(vc, m, ax, ay - w, az, ca, bx, by - w, bz, cb, bx, by + w, bz, cb, ax, ay + w, az, ca);
            }
        }
    }

    private static void trailWave(VertexConsumer vc, Matrix4f m, TrailData d) {
        for (int k = 1; k < d.n; k++) {
            if (d.first && d.age[k - 1] < 250) continue;
            float fa = Math.max(0f, d.life[k - 1]), fb = Math.max(0f, d.life[k]);
            float pa = (float) (d.now / 170.0 + (k - 1) * 0.55), pb = (float) (d.now / 170.0 + k * 0.55);
            float ya = 0.95f + (float) Math.sin(pa) * 0.34f * (1f - fa * 0.4f);
            float yb = 0.95f + (float) Math.sin(pb) * 0.34f * (1f - fb * 0.4f);
            float ax = (float) d.x[k - 1], ay = (float) d.y[k - 1] + ya, az = (float) d.z[k - 1];
            float bx = (float) d.x[k], by = (float) d.y[k] + yb, bz = (float) d.z[k];
            int rgbA = Colors.hsb(d.base + 0.12f * (1f - fa), 0.7f, 1f), rgbB = Colors.hsb(d.base + 0.12f * (1f - fb), 0.7f, 1f);
            // broad soft band + thin white core
            quad(vc, m, ax, ay - 0.13f, az, Colors.argb(0, rgbA), bx, by - 0.13f, bz, Colors.argb(0, rgbB),
                    bx, by, bz, Colors.argb((int) (210 * fb * fb), rgbB), ax, ay, az, Colors.argb((int) (210 * fa * fa), rgbA));
            quad(vc, m, ax, ay, az, Colors.argb((int) (210 * fa * fa), rgbA), bx, by, bz, Colors.argb((int) (210 * fb * fb), rgbB),
                    bx, by + 0.13f, bz, Colors.argb(0, rgbB), ax, ay + 0.13f, az, Colors.argb(0, rgbA));
            quad(vc, m, ax, ay - 0.018f, az, Colors.argb((int) (255 * fa * fa), 0xFFFFFF), bx, by - 0.018f, bz, Colors.argb((int) (255 * fb * fb), 0xFFFFFF),
                    bx, by + 0.018f, bz, Colors.argb((int) (255 * fb * fb), 0xFFFFFF), ax, ay + 0.018f, az, Colors.argb((int) (255 * fa * fa), 0xFFFFFF));
        }
    }

    private static float rnd(long seed, int i) {
        long h = seed * 0x9E3779B97F4A7C15L + i * 0xBF58476D1CE4E5B9L;
        h ^= h >>> 31; h *= 0x94D049BB133111EBL; h ^= h >>> 29;
        return ((h >>> 40) & 0xFFFFFF) / (float) 0x1000000;
    }

    private static void trailSparks(VertexConsumer vc, Matrix4f m, TrailData d) {
        for (int k = 0; k < d.n - 1; k++) {
            if (d.first && d.age[k] < 250) continue;
            float life = Math.max(0f, d.life[k]);
            long seed = d.now - d.age[k];
            float ox = (rnd(seed, 1) - 0.5f) * 0.9f, oz = (rnd(seed, 2) - 0.5f) * 0.9f;
            float oy = 0.15f + rnd(seed, 3) * 1.5f + d.age[k] * 0.00035f;
            float size = (0.05f + 0.06f * rnd(seed, 4)) * (0.35f + 0.65f * life);
            int rgb = Colors.hsb(d.base + 0.12f * rnd(seed, 5), 0.6f, 1f);
            float x = (float) d.x[k] + ox, y = (float) d.y[k] + oy, z = (float) d.z[k] + oz;
            int a = (int) (255 * (float) Math.pow(life, 1.2));
            glow(vc, m, x, y, z, d.right, d.up, size * 2.6f, 8, Colors.argb(a / 2, rgb), Colors.argb(0, rgb));
            glow(vc, m, x, y, z, d.right, d.up, size, 8, Colors.argb(a, 0xFFFFFF), Colors.argb(a / 2, rgb));
        }
    }

    private static void trailHelix(VertexConsumer vc, Matrix4f m, TrailData d) {
        for (int s = 0; s < 2; s++) {
            float ph = s * (float) Math.PI;
            for (int k = 1; k < d.n; k++) {
                if (d.first && d.age[k - 1] < 250) continue;
                float[][] pts = new float[2][3];
                for (int e = 0; e < 2; e++) {
                    int i = k - 1 + e;
                    int a = Math.max(0, i - 1), b = Math.min(d.n - 1, i + 1);
                    float dx = (float) (d.x[b] - d.x[a]), dz = (float) (d.z[b] - d.z[a]);
                    float len = (float) Math.sqrt(dx * dx + dz * dz);
                    float px = len < 1e-5f ? 1f : -dz / len, pz = len < 1e-5f ? 0f : dx / len;
                    float phi = (float) ((d.now - d.age[i]) / 150.0) + ph;
                    pts[e][0] = (float) d.x[i] + px * (float) Math.cos(phi) * 0.5f;
                    pts[e][1] = (float) d.y[i] + 0.95f + (float) Math.sin(phi) * 0.6f;
                    pts[e][2] = (float) d.z[i] + pz * (float) Math.cos(phi) * 0.5f;
                }
                float fa = Math.max(0f, d.life[k - 1]), fb = Math.max(0f, d.life[k]);
                int rgbA = Colors.hsb(d.base + 0.14f * s + 0.08f * (1f - fa), 0.7f, 1f);
                int rgbB = Colors.hsb(d.base + 0.14f * s + 0.08f * (1f - fb), 0.7f, 1f);
                int ca = Colors.argb((int) (230 * fa * fa), rgbA), cb = Colors.argb((int) (230 * fb * fb), rgbB);
                float w = 0.06f;
                quad(vc, m, pts[0][0], pts[0][1] - w, pts[0][2], ca, pts[1][0], pts[1][1] - w, pts[1][2], cb,
                        pts[1][0], pts[1][1] + w, pts[1][2], cb, pts[0][0], pts[0][1] + w, pts[0][2], ca);
            }
        }
    }

    // ---------------------------------------------------------------- TargetRender (4 styles)
    /** soft glowing ribbon facing the camera; edgeFactor 0 = fully feathered, 1 = hard edges */
    private static void ribbon(VertexConsumer vc, Matrix4f m, float[] x, float[] y, float[] z, int n,
                               float width, float alpha, float edgeFactor, int rgbHead, int rgbTail) {
        float[] sx = new float[n + 1], sy = new float[n + 1], sz = new float[n + 1];
        for (int k = 0; k <= n; k++) {
            int a = Math.max(0, k - 1), b = Math.min(n, k + 1);
            float tx = x[b] - x[a], ty = y[b] - y[a], tz = z[b] - z[a];
            float cx = ty * z[k] - tz * y[k], cy = tz * x[k] - tx * z[k], cz = tx * y[k] - ty * x[k];
            float len = (float) Math.sqrt(cx * cx + cy * cy + cz * cz);
            if (len < 1e-6f) { cx = 0; cy = 1; cz = 0; len = 1; }
            sx[k] = cx / len; sy[k] = cy / len; sz[k] = cz / len;
        }
        for (int k = 0; k < n; k++) {
            float f0 = 1f - k / (float) n, f1 = 1f - (k + 1) / (float) n;
            float w0 = width * (0.2f + 0.8f * f0), w1 = width * (0.2f + 0.8f * f1);
            int rgb0 = Colors.lerp(0xFF000000 | rgbTail, 0xFF000000 | rgbHead, f0) & 0xFFFFFF;
            int rgb1 = Colors.lerp(0xFF000000 | rgbTail, 0xFF000000 | rgbHead, f1) & 0xFFFFFF;
            float a0 = alpha * (float) Math.pow(f0, 1.2), a1 = alpha * (float) Math.pow(f1, 1.2);
            int c0 = Colors.argb((int) a0, rgb0), c1 = Colors.argb((int) a1, rgb1);
            int e0 = Colors.argb((int) (a0 * edgeFactor), rgb0), e1 = Colors.argb((int) (a1 * edgeFactor), rgb1);
            float lx0 = x[k] - sx[k] * w0, ly0 = y[k] - sy[k] * w0, lz0 = z[k] - sz[k] * w0;
            float lx1 = x[k + 1] - sx[k + 1] * w1, ly1 = y[k + 1] - sy[k + 1] * w1, lz1 = z[k + 1] - sz[k + 1] * w1;
            float rx0 = x[k] + sx[k] * w0, ry0 = y[k] + sy[k] * w0, rz0 = z[k] + sz[k] * w0;
            float rx1 = x[k + 1] + sx[k + 1] * w1, ry1 = y[k + 1] + sy[k + 1] * w1, rz1 = z[k + 1] + sz[k + 1] * w1;
            quad(vc, m, lx0, ly0, lz0, e0, lx1, ly1, lz1, e1, x[k + 1], y[k + 1], z[k + 1], c1, x[k], y[k], z[k], c0);
            quad(vc, m, x[k], y[k], z[k], c0, x[k + 1], y[k + 1], z[k + 1], c1, rx1, ry1, rz1, e1, rx0, ry0, rz0, e0);
        }
    }

    private static void targetRender(VertexConsumer vc, Matrix4f m, Vec3d cam, Camera camera, float td) {
        LivingEntity e = Hud.active();
        if (e == null) return;
        Vector3f right = new Vector3f(1, 0, 0).rotate(camera.getRotation());
        Vector3f up = new Vector3f(0, 1, 0).rotate(camera.getRotation());
        float ex = (float) (MathHelper.lerp(td, e.prevX, e.getX()) - cam.x);
        float ey = (float) (MathHelper.lerp(td, e.prevY, e.getY()) - cam.y);
        float ez = (float) (MathHelper.lerp(td, e.prevZ, e.getZ()) - cam.z);
        float hgt = e.getHeight(), wid = e.getWidth();
        double now = System.currentTimeMillis();
        float h = Modules.TARGETRENDER.value;
        int tint = Colors.hsb(h, 0.55f, 1f);
        int white = Colors.hsb(h, 0.10f, 1f);

        switch (Modules.TARGETRENDER.mode) {
            case 1 -> trCircle(vc, m, ex, ey, ez, wid, now, h, tint, white);
            case 2 -> trJello(vc, m, ex, ey, ez, hgt, wid, now, tint, white);
            case 3 -> trCrystal(vc, m, ex, ey, ez, hgt, now, tint, white, right, up);
            default -> trGhost(vc, m, ex, ey + hgt * 0.5f, ez, wid, now, tint, white, right, up);
        }
    }

    // crisp comet orbs (like the reference video)
    private static void trGhost(VertexConsumer vc, Matrix4f m, float cxp, float cyp, float czp, float wid, double now,
                                int tint, int white, Vector3f right, Vector3f up) {
        float rad = 0.72f + wid * 0.3f;
        float base = (float) (now / 1000.0 * Math.PI * 2);
        float psi = (float) (now / 3800.0 * Math.PI * 2);
        float tilt = (float) Math.toRadians(52);
        float sinT = (float) Math.sin(tilt), cosT = (float) Math.cos(tilt);
        float cp = (float) Math.cos(psi), sp = (float) Math.sin(psi);
        final int n = 22;
        for (int o = 0; o < 2; o++) {
            float phase = base + o * (float) Math.PI;
            float[] tx = new float[n + 1], ty = new float[n + 1], tz = new float[n + 1];
            for (int k = 0; k <= n; k++) {
                float a = phase - k * 0.07f;
                float lx = rad * (float) Math.cos(a), l0 = rad * (float) Math.sin(a);
                float ly = l0 * sinT, lz = l0 * cosT;
                tx[k] = cxp + lx * cp + lz * sp;
                ty[k] = cyp + ly;
                tz[k] = czp - lx * sp + lz * cp;
            }
            ribbon(vc, m, tx, ty, tz, n, 0.13f, 235f, 0.30f, tint, tint);     // defined band
            ribbon(vc, m, tx, ty, tz, n, 0.045f, 255f, 0.85f, white, white);  // bright core line
            float ox = tx[0], oy = ty[0], oz = tz[0];
            glow(vc, m, ox, oy, oz, right, up, 0.20f, 16, Colors.argb(110, tint), Colors.argb(0, tint));
            glow(vc, m, ox, oy, oz, right, up, 0.11f, 16, Colors.argb(235, white), Colors.argb(0, tint));
            glow(vc, m, ox, oy, oz, right, up, 0.05f, 16, 0xFFFFFFFF, Colors.argb(255, white));
        }
    }

    // rotating ring with two comet arcs on the ground
    private static void trCircle(VertexConsumer vc, Matrix4f m, float x, float y, float z, float wid, double now, float h,
                                 int tint, int white) {
        float r = wid * 0.5f + 0.55f + (float) Math.sin(now / 350.0) * 0.04f;
        float yy = y + 0.03f;
        float spin = (float) (now / 700.0 * Math.PI * 2);
        ring(vc, m, x, yy, z, r - 0.02f, r + 0.02f, Colors.argb(70, tint), Colors.argb(70, tint));
        for (int i = 0; i < 2; i++) {
            float head = spin + i * (float) Math.PI;
            float len = 2.1f;
            arc(vc, m, x, yy + 0.002f, z, r - 0.07f, r + 0.07f, head - len, len, 40,
                    Colors.argb(0, tint), Colors.argb(0, tint), Colors.argb(235, white), Colors.argb(200, tint));
        }
        ring(vc, m, x, yy, z, r + 0.07f, r + 0.30f, Colors.argb(55, tint), Colors.argb(0, tint));
    }

    // ring sweeping up and down the body, leaving a glowing curtain behind it
    private static void trJello(VertexConsumer vc, Matrix4f m, float x, float y, float z, float hgt, float wid, double now,
                                int tint, int white) {
        float r = wid * 0.5f + 0.32f;
        float ph = (float) (now / 1000.0 * 2.4);
        float f = 0.5f + 0.5f * (float) Math.sin(ph);            // 0..1
        float dir = (float) Math.cos(ph) >= 0 ? 1f : -1f;         // +1 moving up
        float ry = y + 0.05f + f * (hgt - 0.1f);
        float trail = 0.65f;
        final int n = 40;
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0) * r, s0 = (float) Math.sin(a0) * r, c1 = (float) Math.cos(a1) * r, s1 = (float) Math.sin(a1) * r;
            float yt = ry - dir * trail;
            quad(vc, m, x + c0, ry, z + s0, Colors.argb(150, tint), x + c1, ry, z + s1, Colors.argb(150, tint),
                    x + c1, yt, z + s1, Colors.argb(0, tint), x + c0, yt, z + s0, Colors.argb(0, tint));
        }
        ring(vc, m, x, ry, z, r - 0.045f, r + 0.045f, Colors.argb(255, white), Colors.argb(255, white));
        ring(vc, m, x, ry, z, r + 0.045f, r + 0.15f, Colors.argb(120, tint), Colors.argb(0, tint));
    }

    // spinning crystal above the head
    private static void trCrystal(VertexConsumer vc, Matrix4f m, float x, float y, float z, float hgt, double now,
                                  int tint, int white, Vector3f right, Vector3f up) {
        float cy = y + hgt + 0.55f + (float) Math.sin(now / 420.0) * 0.06f;
        float spin = (float) (now / 1000.0 * 2.4);
        float rw = 0.17f, hh = 0.30f;
        float[] px = new float[4], pz = new float[4];
        for (int i = 0; i < 4; i++) {
            px[i] = x + (float) Math.cos(spin + i * Math.PI / 2) * rw;
            pz[i] = z + (float) Math.sin(spin + i * Math.PI / 2) * rw;
        }
        int top = Colors.argb(235, white), mid = Colors.argb(190, tint), bot = Colors.argb(150, tint);
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            int shade = (i % 2 == 0) ? mid : Colors.argb(140, tint);
            tri(vc, m, x, cy + hh, z, top, px[i], cy, pz[i], shade, px[j], cy, pz[j], shade);
            tri(vc, m, x, cy - hh, z, bot, px[i], cy, pz[i], shade, px[j], cy, pz[j], shade);
        }
        glow(vc, m, x, cy, z, right, up, 0.45f, 18, Colors.argb(70, tint), Colors.argb(0, tint));
        glow(vc, m, x, cy, z, right, up, 0.12f, 12, Colors.argb(200, white), Colors.argb(0, tint));
    }
}
