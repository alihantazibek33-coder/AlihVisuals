package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class FreelookModule extends ClientModule {
    public FreelookModule() { super("Freelook", "Look around without changing movement direction.", ModuleCategory.VISUALS); }
}
