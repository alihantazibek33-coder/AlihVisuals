package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class FpsModule extends ClientModule {
    public FpsModule() { super("FPS Counter", "Displays current frames per second.", ModuleCategory.HUD); }
}
