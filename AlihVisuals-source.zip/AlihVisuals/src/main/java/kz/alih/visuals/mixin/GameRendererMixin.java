package kz.alih.visuals.mixin;

import kz.alih.visuals.Modules;
import net.minecraft.client.render.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    // Only the 3D world projection is changed - HUD / menus / crosshair stay untouched.
    @Inject(method = "getBasicProjectionMatrix", at = @At("RETURN"), cancellable = true)
    private void alih$aspect(float fov, CallbackInfoReturnable<Matrix4f> cir) {
        if (!Modules.ASPECT.enabled) return;
        Matrix4f m = new Matrix4f(cir.getReturnValue());
        m.scale(1.0f / Modules.ASPECT.value, 1.0f, 1.0f);
        cir.setReturnValue(m);
    }
}
