package kz.alih.visuals.mixin;

import kz.alih.visuals.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    // Nametag: show your own name tag in 2nd / 3rd person view
    @Inject(method = "hasLabel(Lnet/minecraft/entity/LivingEntity;D)Z", at = @At("RETURN"), cancellable = true, require = 0)
    private void alih$ownTag(LivingEntity entity, double dist, CallbackInfoReturnable<Boolean> cir) {
        if (!Modules.NAMETAG.enabled || Boolean.TRUE.equals(cir.getReturnValue())) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (entity == mc.player && !mc.options.getPerspective().isFirstPerson() && !entity.isInvisible()) {
            cir.setReturnValue(true);
        }
    }
}
