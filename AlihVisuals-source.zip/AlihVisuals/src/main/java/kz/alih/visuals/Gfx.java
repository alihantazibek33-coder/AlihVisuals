package kz.alih.visuals;

import net.minecraft.client.gui.DrawContext;

public final class Gfx {
    private Gfx() {}

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int dx = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - d * d)));
            c.fill(x + dx, y + i, x + w - dx, y + i + 1, color);
            c.fill(x + dx, y + h - i - 1, x + w - dx, y + h - i, color);
        }
        c.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void circle(DrawContext c, float cx, float cy, float r, int color) {
        int ir = (int) Math.ceil(r);
        for (int dy = -ir; dy <= ir; dy++) {
            double v = r * r - (dy + 0.5) * (dy + 0.5);
            if (v <= 0) continue;
            int hw = (int) Math.round(Math.sqrt(v));
            c.fill((int) cx - hw, (int) cy + dy, (int) cx + hw, (int) cy + dy + 1, color);
        }
    }
}
