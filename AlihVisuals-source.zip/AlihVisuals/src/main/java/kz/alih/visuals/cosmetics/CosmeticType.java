package kz.alih.visuals.cosmetics;

public enum CosmeticType {
    CAPE("Плащ"), HAT("Қалпақ"), WING("Қанат"), PET("Жануар");

    public final String label;

    CosmeticType(String label) { this.label = label; }
}
