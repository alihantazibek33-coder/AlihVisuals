package kz.alih.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class AlihMenu extends Screen {
    private static final int PAD = 14, GAP = 10, RGAP = 6, HEAD = 58, FOOT = 24, CARD_H = 52;
    private static final int CYAN = 0xFF5CE1FF, CYAN_DIM = 0xFF3FA9C9;

    private static float savedScroll = 0f;

    private int px, py, pw, ph, cardW, gx, viewTop, viewBottom;
    private float scroll, maxScroll;
    private int[] rx, ry, rw, rh;        // card rects (ry is relative to content top, unscrolled)
    private long last = System.nanoTime();
    private final long openedAt = System.currentTimeMillis();

    private int dragMod = -1, dragK = -2;  // slider being dragged (k=-1 primary, >=0 extra)
    private boolean pressActive, moved;
    private int pressCard = -1;
    private double pressY;

    public AlihMenu() { super(Text.literal("AlihVisuals")); scroll = savedScroll; }

    @Override
    protected void init() { layout(); }

    private static int wideHeight(Modules.Module m) { return 34 + ((m.extras.size() + 1) / 2) * 26 + 6; }

    private void layout() {
        pw = Math.min(width - 10, Math.max(340, (int) (width * 0.55)));
        ph = Math.min(height - 10, Math.max(300, (int) (height * 0.72)));
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cardW = (pw - PAD * 2 - GAP) / 2;
        gx = px + PAD;
        viewTop = py + HEAD - 4;
        viewBottom = py + ph - FOOT;

        int n = Modules.ALL.size();
        rx = new int[n]; ry = new int[n]; rw = new int[n]; rh = new int[n];
        int y = 0, col = 0;
        for (int i = 0; i < n; i++) {
            Modules.Module m = Modules.ALL.get(i);
            if (m.wide) {
                if (col == 1) { y += CARD_H + RGAP; col = 0; }
                rx[i] = 0; ry[i] = y; rw[i] = pw - PAD * 2; rh[i] = wideHeight(m);
                y += rh[i] + RGAP;
            } else {
                rx[i] = col * (cardW + GAP); ry[i] = y; rw[i] = cardW; rh[i] = CARD_H;
                if (col == 1) { y += CARD_H + RGAP; col = 0; } else col = 1;
            }
        }
        if (col == 1) y += CARD_H + RGAP;
        int content = y - RGAP;
        maxScroll = Math.max(0, content - (viewBottom - (py + HEAD)) + 4);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
    }

    private int cx(int i) { return gx + rx[i]; }
    private int cy(int i) { return py + HEAD - (int) scroll + ry[i]; }
    private boolean inView(double my) { return my >= viewTop && my < viewBottom; }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, 0xB0090B10);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();
        long now = System.nanoTime();
        float dt = (now - last) / 1e9f;
        last = now;
        float k = 1f - (float) Math.exp(-dt * 14f);

        Gfx.rrect(c, px - 1, py - 1, pw + 2, ph + 2, 11, 0xFF2C313C);
        Gfx.rrect(c, px, py, pw, ph, 10, 0xF01A1D24);
        c.fillGradient(px + 6, py + 2, px + pw - 6, py + 34, 0x2A5CE1FF, 0x00000000);

        MatrixStack ms = c.getMatrices();
        ms.push();
        ms.translate(px + pw / 2f, py + 11, 0);
        ms.scale(2f, 2f, 1f);
        c.drawCenteredTextWithShadow(textRenderer, "AlihVisuals", 0, 0, CYAN);
        ms.pop();
        c.drawCenteredTextWithShadow(textRenderer, "visual client", px + pw / 2, py + 32, 0xFF7C8494);

        int lw = pw - 60, n = 60;
        for (int i = 0; i < n; i++) {
            float a = (float) Math.sin(Math.PI * (i + 0.5) / n);
            int x1 = px + 30 + lw * i / n, x2 = px + 30 + lw * (i + 1) / n;
            c.fill(x1, py + 46, x2, py + 47, Colors.argb((int) (255 * a), 0x5CE1FF));
        }
        Gfx.circle(c, px + 14, py + 14, 2.5f, CYAN_DIM);
        Gfx.circle(c, px + pw - 14, py + 14, 2.5f, CYAN_DIM);

        List<Modules.Module> all = Modules.ALL;
        c.enableScissor(px + 2, viewTop, px + pw - 2, viewBottom);
        for (int i = 0; i < all.size(); i++) {
            Modules.Module m = all.get(i);
            m.anim += ((m.enabled ? 1f : 0f) - m.anim) * k;
            int y = cy(i);
            if (y + rh[i] < viewTop || y > viewBottom) continue;
            drawCard(c, m, i, cx(i), y, mx, my);
        }
        c.disableScissor();

        if (maxScroll > 0) {
            int trackH = viewBottom - viewTop;
            int barH = Math.max(20, (int) (trackH * trackH / (trackH + maxScroll)));
            int barY = viewTop + (int) ((trackH - barH) * (scroll / maxScroll));
            Gfx.rrect(c, px + pw - 8, barY, 3, barH, 1, 0xFF3FA9C9);
        }

        String hint = maxScroll > 0 ? "0 / ESC - жабу   |   жоғары-төмен сүйре" : "0 / ESC - жабу";
        c.drawCenteredTextWithShadow(textRenderer, hint, px + pw / 2, py + ph - 15, 0xFF5E6575);
    }

    private void drawSlider(DrawContext c, int x, int y, int w, float norm, boolean hue, int knobRgb, String label) {
        c.drawTextWithShadow(textRenderer, label, x, y - 11, 0xFF6F7788);
        if (hue) {
            for (int i = 0; i < w; i += 2)
                c.fill(x + i, y, Math.min(x + i + 2, x + w), y + 6, 0xFF000000 | Colors.hsb(i / (float) w, 0.85f, 1f));
        } else {
            Gfx.rrect(c, x, y, w, 6, 3, 0xFF3A3F4B);
            Gfx.rrect(c, x, y, Math.max(6, (int) (w * norm)), 6, 3, 0xFF4FC3F7);
        }
        float kx = x + w * norm;
        Gfx.circle(c, kx, y + 3, 5f, 0xFF12141A);
        Gfx.circle(c, kx, y + 3, 4f, knobRgb);
    }

    // slider geometry: {x, trackY, w}; k=-1 primary setting, k>=0 extras
    private int[] sliderGeom(int i, int k) {
        int x = cx(i), y = cy(i);
        if (k < 0) return new int[]{x + 10, y + rh[i] - 13, rw[i] - 20};
        int colW = (rw[i] - 30) / 2;
        int col = k % 2, row = k / 2;
        return new int[]{x + 10 + col * (colW + 10), y + 34 + row * 26 + 11, colW};
    }

    private void drawCard(DrawContext c, Modules.Module m, int i, int x, int y, int mx, int my) {
        int w = rw[i], h = rh[i];
        boolean hover = inView(my) && mx >= x && mx < x + w && my >= y && my < y + h;
        int bg = hover ? 0xFF2A2E38 : 0xFF23262E;
        Gfx.rrect(c, x, y, w, h, 7, Colors.lerp(0xFF2C313C, 0xFF3FA9C9, m.anim * 0.8f));
        Gfx.rrect(c, x + 1, y + 1, w - 2, h - 2, 6, bg);
        if (m.anim > 0.02f) Gfx.rrect(c, x + 1, y + 6, 2, Math.min(h - 12, 40), 1, Colors.argb((int) (255 * m.anim), 0x5CE1FF));

        c.drawTextWithShadow(textRenderer, m.name, x + 10, y + 7, 0xFFE6E9EF);
        c.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(m.desc, w - 64), x + 10, y + 19, 0xFF8A90A0);

        int tx = x + w - 10 - 34, ty = y + 8;
        Gfx.rrect(c, tx, ty, 34, 16, 8, Colors.lerp(0xFF3A3F4B, 0xFF4FC3F7, m.anim));
        Gfx.circle(c, tx + 8 + 18 * m.anim, ty + 8, 6f, 0xFFFFFFFF);

        if (m.hasSetting()) {
            boolean hue = m.settingName.equals("Color");
            int[] g = sliderGeom(i, -1);
            String label = hue ? m.settingName : String.format("%s %.2f", m.settingName, m.value);
            drawSlider(c, g[0], g[1], g[2], m.norm(), hue, hue ? 0xFF000000 | m.rgb() : 0xFFFFFFFF, label);
        } else if (m.extras.isEmpty()) {
            c.drawTextWithShadow(textRenderer, m.enabled ? "ON" : "OFF", x + 10, y + h - 13,
                    m.enabled ? CYAN : 0xFF5E6575);
        }
        for (int k = 0; k < m.extras.size(); k++) {
            Modules.Setting st = m.extras.get(k);
            int[] g = sliderGeom(i, k);
            drawSlider(c, g[0], g[1], g[2], st.norm(), false, 0xFFFFFFFF, String.format("%s  %.2f", st.name, st.value));
        }
    }

    private boolean inSlider(int i, int k, double mx, double my) {
        int[] g = sliderGeom(i, k);
        return inView(my) && mx >= g[0] - 5 && mx <= g[0] + g[2] + 5 && my >= g[1] - 7 && my <= g[1] + 13;
    }

    private void dragTo(int i, int k, double mx) {
        int[] g = sliderGeom(i, k);
        float t = (float) ((mx - g[0]) / g[2]);
        Modules.Module m = Modules.ALL.get(i);
        if (k < 0) m.setNorm(t); else m.extras.get(k).setNorm(t);
    }

    private int cardAt(double mx, double my) {
        if (!inView(my)) return -1;
        for (int i = 0; i < Modules.ALL.size(); i++) {
            int x = cx(i), y = cy(i);
            if (mx >= x && mx < x + rw[i] && my >= y && my < y + rh[i]) return i;
        }
        return -1;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            for (int i = 0; i < Modules.ALL.size(); i++) {
                Modules.Module m = Modules.ALL.get(i);
                if (m.hasSetting() && inSlider(i, -1, mx, my)) { dragMod = i; dragK = -1; dragTo(i, -1, mx); return true; }
                for (int k = 0; k < m.extras.size(); k++)
                    if (inSlider(i, k, mx, my)) { dragMod = i; dragK = k; dragTo(i, k, mx); return true; }
            }
            if (inView(my)) {
                pressActive = true; moved = false; pressY = my; pressCard = cardAt(mx, my);
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragMod >= 0) { dragTo(dragMod, dragK, mx); return true; }
        if (pressActive) {
            if (Math.abs(my - pressY) > 5) moved = true;
            if (moved) scroll = Math.max(0, Math.min(maxScroll, scroll - (float) dy));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (pressActive && !moved && pressCard >= 0 && pressCard == cardAt(mx, my)) {
            Modules.Module m = Modules.ALL.get(pressCard);
            m.enabled = !m.enabled;
        }
        pressActive = false; pressCard = -1; dragMod = -1; dragK = -2;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scroll = Math.max(0, Math.min(maxScroll, scroll - (float) vAmount * 24f));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if ((key == GLFW.GLFW_KEY_0 || key == GLFW.GLFW_KEY_KP_0) && System.currentTimeMillis() - openedAt > 200) {
            close();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void removed() { savedScroll = scroll; Modules.save(); }
}
