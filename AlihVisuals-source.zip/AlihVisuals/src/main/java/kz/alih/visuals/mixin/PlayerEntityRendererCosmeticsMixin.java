package kz.alih.visuals.mixin;

import kz.alih.visuals.cosmetics.CapeTextures;
import kz.alih.visuals.cosmetics.CosmeticType;
import kz.alih.visuals.cosmetics.CosmeticsState;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererCosmeticsMixin {
    @Inject(method = "updateRenderState(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V",
            at = @At("RETURN"), require = 0)
    private void alih$cosmetics(AbstractClientPlayerEntity player, PlayerEntityRenderState state, float tickDelta, CallbackInfo ci) {
        CosmeticsState.bind(state, player.getUuid());

        CosmeticsState.Entry cape = CosmeticsState.get().selectedFor(player.getUuid(), CosmeticType.CAPE);
        if (cape == null || !state.capeVisible) return;
        Identifier id = CapeTextures.current(cape);
        if (id == null) return;
        SkinTextures s = state.skinTextures;
        state.skinTextures = new SkinTextures(s.texture(), s.textureUrl(), id, s.elytraTexture(), s.model(), s.secure());
    }
}
