package kz.alih.visuals.knives;

import kz.alih.visuals.AlihMenu;
import kz.alih.visuals.Colors;
import kz.alih.visuals.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/** "Қылыштар": pick a CS-style knife that replaces your swords (only you see it) and one of its finishes. */
public class KnifeScreen extends Screen {
    private static final int CYAN = 0xFF5CE1FF;
    private static final String[] SLIDER_NAMES = {"Масштаб", "Жылжу X", "Жылжу Y", "Жылжу Z", "Еңкею", "Бұрылыс", "Пышақ осі"};
    private static final float[] SLIDER_MIN = {0.2f, -0.8f, -0.8f, -0.8f, -180f, -180f, -180f};
    private static final float[] SLIDER_MAX = {1.3f, 0.8f, 0.8f, 0.8f, 180f, 180f, 180f};

    private final long openedAt = System.currentTimeMillis();
    private long last = System.nanoTime();
    private float kk = 0.2f, al = 1f;
    private int px, py, pw, ph, listX, listW, rx, rw, step = 24;
    private boolean tuner;
    private int dragSlider = -1;
    private final Map<String, Float> hover = new HashMap<>();

    public KnifeScreen() { super(Text.literal("Knives")); }

    @Override protected void init() { layout(); }
    @Override public boolean shouldPause() { return false; }
    @Override public void close() { client.setScreen(new AlihMenu()); }
    @Override public void removed() { KnifeState.get().save(); }

    private void layout() {
        pw = Math.min(width - 8, 520);
        ph = Math.min(height - 8, 330);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        listX = px + 10;
        listW = 150;
        rx = px + 170;
        rw = pw - 180;
        step = Math.max(16, Math.min(24, (ph - 30 - 34) / (KnifeData.KNIVES.size() + 1)));
    }

    private int A(int c) { return Colors.mulAlpha(c, al); }
    private void rr(DrawContext c, int x, int y, int w, int h, int r, int col) { Gfx.rrect(c, x, y, w, h, r, A(col)); }
    private void circ(DrawContext c, float x, float y, float r, int col) { Gfx.circle(c, x, y, r, A(col)); }
    private void text(DrawContext c, String s, int x, int y, int col) {
        col = A(col);
        if ((col >>> 24) < 8) return;
        c.drawTextWithShadow(textRenderer, s, x, y, col);
    }
    private void ctext(DrawContext c, String s, int cx, int y, int col) {
        col = A(col);
        if ((col >>> 24) < 8) return;
        c.drawCenteredTextWithShadow(textRenderer, s, cx, y, col);
    }
    private static float clamp01(float v) { return v < 0f ? 0f : Math.min(1f, v); }
    private boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    private static Identifier thumb(String knife, String skin) {
        return Identifier.of("alihvisuals", "textures/knives/thumbs/" + knife + "_" + skin + ".png");
    }

    private float hov(String key, boolean on) {
        float v = hover.getOrDefault(key, 0f);
        v += ((on ? 1f : 0f) - v) * kk;
        hover.put(key, v);
        return v;
    }

    private void image(DrawContext c, Identifier id, int x, int y, int w, int h) {
        if ((A(0xFF000000) >>> 24) < 8) return;
        c.drawTexture(RenderLayer::getGuiTextured, id, x, y, 0f, 0f, w, h, 160, 80, 160, 80);
    }

    // ------------------------------------------------------------------ render
    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        float v = clamp01((System.currentTimeMillis() - openedAt) / 250f);
        c.fill(0, 0, width, height, Colors.mulAlpha(0xB0090B10, v));
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        kk = 1f - (float) Math.exp(-dt * 14f);
        float f = clamp01((System.currentTimeMillis() - openedAt) / 260f);
        al = 1f - (1f - f) * (1f - f);

        KnifeState st = KnifeState.get();
        rr(c, px - 1, py - 1, pw + 2, ph + 2, 11, 0xFF2C313C);
        rr(c, px, py, pw, ph, 10, 0xF01A1D24);
        ctext(c, "Қылыштар", px + pw / 2, py + 10, CYAN);

        boolean backHover = in(mx, my, px + 8, py + 6, 62, 16) && !tuner;
        rr(c, px + 8, py + 6, 62, 16, 7, backHover ? 0xFF343946 : 0xFF2A2E38);
        ctext(c, "‹ Артқа", px + 8 + 31, py + 10, 0xFFB8BFCC);

        // ---- knife list
        int y = py + 30;
        for (int i = -1; i < KnifeData.KNIVES.size(); i++) {
            String id = i < 0 ? "" : KnifeData.KNIVES.get(i).id();
            String name = i < 0 ? "Қарапайым қылыш" : KnifeData.KNIVES.get(i).name();
            boolean sel = st.selected.equals(id);
            boolean h = in(mx, my, listX, y, listW, step - 3) && !tuner;
            float hv = hov("k:" + id, h);
            rr(c, listX, y, listW, step - 3, 7, sel ? 0xFF4FC3F7 : Colors.lerp(0xFF2A2E38, 0xFF363B48, hv));
            if (i >= 0) {
                image(c, thumb(id, st.skin(id)), listX + 4, y + 1, 2 * (step - 5), step - 5);
                text(c, textRenderer.trimToWidth(name, listW - 6 - 2 * (step - 5) - 10), listX + 2 * (step - 5) + 10, y + (step - 3 - 8) / 2, sel ? 0xFF0E1218 : 0xFFE6E9EF);
            } else {
                text(c, name, listX + 10, y + (step - 3 - 8) / 2, sel ? 0xFF0E1218 : 0xFFE6E9EF);
            }
            y += step;
        }

        // ---- switch + tuner button
        int sy = py + ph - 26;
        rr(c, listX, sy, 30, 16, 8, st.enabled ? 0xFF4FC3F7 : 0xFF3A3F4B);
        circ(c, st.enabled ? listX + 22 : listX + 8, sy + 8, 6f, 0xFFFFFFFF);
        text(c, "Қосулы", listX + 36, sy + 4, 0xFFB8BFCC);
        boolean th = in(mx, my, listX + 90, sy, 60, 16) && !tuner;
        rr(c, listX + 90, sy, 60, 16, 7, th ? 0xFF343946 : 0xFF2A2E38);
        ctext(c, "Орналасу", listX + 120, sy + 4, 0xFFB8BFCC);

        // ---- right side
        KnifeData.Knife k = st.knife() != null ? st.knife() : KnifeData.byId(st.selected);
        if (k == null) {
            ctext(c, "Қылыштың орнына CS пышағын таңдаңыз", rx + rw / 2, py + 70, 0xFF7C8494);
            ctext(c, "Оны тек сіз көресіз, басқаларда қарапайым қылыш", rx + rw / 2, py + 86, 0xFF5E6575);
        } else {
            String skin = st.skin(k.id());
            rr(c, rx, py + 30, rw, 96, 8, 0xFF14161B);
            image(c, thumb(k.id(), skin), rx + 6, py + 38, 160, 80);
            text(c, k.name(), rx + 174, py + 44, 0xFFE6E9EF);
            String sname = "";
            for (KnifeData.Skin s : KnifeData.SKINS) if (s.id().equals(skin)) sname = s.name();
            text(c, sname, rx + 174, py + 58, CYAN);
            text(c, k.dual() ? "Екі қолмен" : "Бір қолмен", rx + 174, py + 72, 0xFF8A90A0);
            text(c, "Инспект: R", rx + 174, py + 86, 0xFF8A90A0);

            // skin grid
            int cols = 4, gap = 6, cw = (rw - gap * (cols - 1)) / cols, ch = 50;
            int gy = py + 134;
            for (int i = 0; i < KnifeData.SKINS.size(); i++) {
                KnifeData.Skin s = KnifeData.SKINS.get(i);
                int x = rx + (i % cols) * (cw + gap), yy = gy + (i / cols) * (ch + gap);
                boolean sel = s.id().equals(skin);
                float hv = hov("s:" + s.id(), in(mx, my, x, yy, cw, ch) && !tuner);
                rr(c, x, yy, cw, ch, 7, sel ? 0xFF4FC3F7 : 0xFF2C313C);
                rr(c, x + 1, yy + 1, cw - 2, ch - 2, 6, Colors.lerp(0xFF23262E, 0xFF2D323E, hv));
                image(c, thumb(k.id(), s.id()), x + (cw - 56) / 2, yy + 3, 56, 28);
                ctext(c, textRenderer.trimToWidth(s.name(), cw - 4), x + cw / 2, yy + 35, sel ? CYAN : 0xFFB8BFCC);
                circ(c, x + 6, yy + 6, 2.5f, 0xFF000000 | s.rgb());
            }
        }

        if (tuner && k != null) drawTuner(c, k, mx, my);
        al = 1f;
    }

    private int tx() { return px + (pw - 270) / 2; }
    private int ty() { return py + (ph - 218) / 2; }

    private void drawTuner(DrawContext c, KnifeData.Knife k, int mx, int my) {
        c.fill(px, py, px + pw, py + ph, A(0xB0000000));
        int x = tx(), y = ty();
        rr(c, x - 1, y - 1, 272, 220, 9, 0xFF3FA9C9);
        rr(c, x, y, 270, 218, 8, 0xFF1D2028);
        text(c, "Қолдағы орналасуы: " + k.name(), x + 12, y + 9, CYAN);
        float[] t = KnifeState.get().transform(k);
        for (int i = 0; i < 7; i++) {
            int sy = y + 38 + i * 21;
            float norm = (t[i] - SLIDER_MIN[i]) / (SLIDER_MAX[i] - SLIDER_MIN[i]);
            text(c, SLIDER_NAMES[i] + "  " + String.format("%.2f", t[i]), x + 12, sy - 12, 0xFFA0A7B6);
            rr(c, x + 12, sy, 246, 6, 3, 0xFF3A3F4B);
            rr(c, x + 12, sy, Math.max(6, (int) (246 * clamp01(norm))), 6, 3, 0xFF4FC3F7);
            circ(c, x + 12 + 246 * clamp01(norm), sy + 3, 5f, 0xFF12141A);
            circ(c, x + 12 + 246 * clamp01(norm), sy + 3, 4f, 0xFFFFFFFF);
        }
        boolean rh = in(mx, my, x + 12, y + 196, 120, 16);
        rr(c, x + 12, y + 196, 120, 16, 7, rh ? 0xFF4A2A38 : 0xFF3A2430);
        ctext(c, "Қалыпты қалпына", x + 72, y + 200, 0xFFFFB4C0);
        boolean oh = in(mx, my, x + 138, y + 196, 120, 16);
        rr(c, x + 138, y + 196, 120, 16, 7, oh ? 0xFF343946 : 0xFF2A2E38);
        ctext(c, "Дайын", x + 198, y + 200, 0xFFB8BFCC);
    }

    // ------------------------------------------------------------------ input
    private void setSlider(KnifeData.Knife k, int i, double mx) {
        float norm = clamp01((float) ((mx - (tx() + 12)) / 246.0));
        KnifeState.get().transform(k)[i] = SLIDER_MIN[i] + norm * (SLIDER_MAX[i] - SLIDER_MIN[i]);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        KnifeState st = KnifeState.get();
        KnifeData.Knife k = KnifeData.byId(st.selected);

        if (tuner) {
            if (k != null) {
                int x = tx(), y = ty();
                for (int i = 0; i < 7; i++) {
                    int sy = y + 38 + i * 21;
                    if (in(mx, my, x + 6, sy - 8, 258, 22)) { dragSlider = i; setSlider(k, i, mx); return true; }
                }
                if (in(mx, my, x + 12, y + 196, 120, 16)) { st.resetTransform(k); return true; }
                if (in(mx, my, x + 138, y + 196, 120, 16)) { tuner = false; st.save(); return true; }
            }
            if (!in(mx, my, tx(), ty(), 270, 218)) tuner = false;
            return true;
        }

        if (in(mx, my, px + 8, py + 6, 62, 16)) { close(); return true; }

        int y = py + 30;
        for (int i = -1; i < KnifeData.KNIVES.size(); i++) {
            if (in(mx, my, listX, y, listW, step - 3)) {
                st.selected = i < 0 ? "" : KnifeData.KNIVES.get(i).id();
                st.save();
                return true;
            }
            y += step;
        }
        int sy = py + ph - 26;
        if (in(mx, my, listX, sy, 30, 16)) { st.enabled = !st.enabled; st.save(); return true; }
        if (in(mx, my, listX + 90, sy, 60, 16)) { if (k != null) tuner = true; return true; }

        if (k != null) {
            int cols = 4, gap = 6, cw = (rw - gap * (cols - 1)) / cols, ch = 50, gy = py + 134;
            for (int i = 0; i < KnifeData.SKINS.size(); i++) {
                int x = rx + (i % cols) * (cw + gap), yy = gy + (i / cols) * (ch + gap);
                if (in(mx, my, x, yy, cw, ch)) {
                    st.setSkin(k.id(), KnifeData.SKINS.get(i).id());
                    st.save();
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        KnifeData.Knife k = KnifeData.byId(KnifeState.get().selected);
        if (tuner && dragSlider >= 0 && k != null) { setSlider(k, dragSlider, mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragSlider >= 0) KnifeState.get().save();
        dragSlider = -1;
        return super.mouseReleased(mx, my, button);
    }
}
