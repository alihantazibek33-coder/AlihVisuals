package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class WeatherInfoModule extends ClientModule {
    public WeatherInfoModule() { super("Weather Info", "Displays current local-world weather state.", ModuleCategory.HUD); }
}
