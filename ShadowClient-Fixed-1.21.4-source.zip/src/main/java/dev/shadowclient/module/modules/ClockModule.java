package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class ClockModule extends ClientModule {
    public ClockModule() { super("Clock", "Displays local system time.", ModuleCategory.HUD); }
}
