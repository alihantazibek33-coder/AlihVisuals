package kz.alih.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class AlihMenu extends Screen {
    private static final int PAD = 14, GAP = 10, RGAP = 6, HEAD = 58, FOOT = 24;
    private static final int CYAN = 0xFF5CE1FF, CYAN_DIM = 0xFF3FA9C9;

    private int px, py, pw, ph, cardW, cardH, gx, gy;
    private long last = System.nanoTime();
    private final long openedAt = System.currentTimeMillis();
    private Modules.Module dragging;

    public AlihMenu() { super(Text.literal("AlihVisuals")); }

    @Override
    protected void init() { layout(); }

    private void layout() {
        pw = Math.min(width - 10, Math.max(380, (int) (width * 0.62)));
        ph = Math.min(height - 10, Math.max(330, (int) (height * 0.78)));
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cardW = (pw - PAD * 2 - GAP) / 2;
        cardH = (ph - HEAD - FOOT - RGAP * 4) / 5;
        gx = px + PAD;
        gy = py + HEAD;
    }

    private int cx(int i) { return gx + (i % 2) * (cardW + GAP); }
    private int cy(int i) { return gy + (i / 2) * (cardH + RGAP); }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, 0xB0090B10);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();
        long now = System.nanoTime();
        float dt = (now - last) / 1e9f;
        last = now;
        float k = 1f - (float) Math.exp(-dt * 14f);

        // panel: dark muted grey, thin border, soft blue top glow
        Gfx.rrect(c, px - 1, py - 1, pw + 2, ph + 2, 11, 0xFF2C313C);
        Gfx.rrect(c, px, py, pw, ph, 10, 0xF01A1D24);
        c.fillGradient(px + 6, py + 2, px + pw - 6, py + 34, 0x2A5CE1FF, 0x00000000);

        // title
        MatrixStack ms = c.getMatrices();
        ms.push();
        ms.translate(px + pw / 2f, py + 11, 0);
        ms.scale(2f, 2f, 1f);
        c.drawCenteredTextWithShadow(textRenderer, "AlihVisuals", 0, 0, CYAN);
        ms.pop();
        c.drawCenteredTextWithShadow(textRenderer, "visual client", px + pw / 2, py + 32, 0xFF7C8494);

        // glowing divider
        int lw = pw - 60, n = 60;
        for (int i = 0; i < n; i++) {
            float a = (float) Math.sin(Math.PI * (i + 0.5) / n);
            int x1 = px + 30 + lw * i / n, x2 = px + 30 + lw * (i + 1) / n;
            c.fill(x1, py + 46, x2, py + 47, Colors.argb((int) (255 * a), 0x5CE1FF));
        }
        // corner dots
        Gfx.circle(c, px + 14, py + 14, 2.5f, CYAN_DIM);
        Gfx.circle(c, px + pw - 14, py + 14, 2.5f, CYAN_DIM);

        List<Modules.Module> all = Modules.ALL;
        for (int i = 0; i < all.size(); i++) {
            Modules.Module m = all.get(i);
            m.anim += ((m.enabled ? 1f : 0f) - m.anim) * k;
            drawCard(c, m, cx(i), cy(i), mx, my);
        }

        c.drawCenteredTextWithShadow(textRenderer, "0 / ESC - жабу", px + pw / 2, py + ph - 15, 0xFF5E6575);
    }

    private void drawCard(DrawContext c, Modules.Module m, int x, int y, int mx, int my) {
        boolean hover = mx >= x && mx < x + cardW && my >= y && my < y + cardH;
        int bg = hover ? 0xFF2A2E38 : 0xFF23262E;
        Gfx.rrect(c, x, y, cardW, cardH, 7, Colors.lerp(0xFF2C313C, 0xFF3FA9C9, m.anim * 0.8f));
        Gfx.rrect(c, x + 1, y + 1, cardW - 2, cardH - 2, 6, bg);
        // accent bar
        if (m.anim > 0.02f) Gfx.rrect(c, x + 1, y + 6, 2, cardH - 12, 1, Colors.argb((int) (255 * m.anim), 0x5CE1FF));

        c.drawTextWithShadow(textRenderer, m.name, x + 10, y + 7, 0xFFE6E9EF);
        c.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(m.desc, cardW - 64), x + 10, y + 19, 0xFF8A90A0);

        // circle toggle
        int tx = x + cardW - 10 - 34, ty = y + 8;
        Gfx.rrect(c, tx, ty, 34, 16, 8, Colors.lerp(0xFF3A3F4B, 0xFF4FC3F7, m.anim));
        Gfx.circle(c, tx + 8 + 18 * m.anim, ty + 8, 6f, 0xFFFFFFFF);

        if (m.hasSetting()) {
            int sx = x + 10, sy = y + cardH - 13, sw = cardW - 20;
            boolean hue = m.settingName.equals("Color");
            if (hue) {
                for (int i = 0; i < sw; i += 2)
                    c.fill(sx + i, sy, Math.min(sx + i + 2, sx + sw), sy + 6, 0xFF000000 | Colors.hsb(i / (float) sw, 0.85f, 1f));
            } else {
                Gfx.rrect(c, sx, sy, sw, 6, 3, 0xFF3A3F4B);
                Gfx.rrect(c, sx, sy, Math.max(6, (int) (sw * m.norm())), 6, 3, 0xFF4FC3F7);
            }
            float kx = sx + sw * m.norm();
            Gfx.circle(c, kx, sy + 3, 5f, 0xFF12141A);
            Gfx.circle(c, kx, sy + 3, 4f, hue ? 0xFF000000 | m.rgb() : 0xFFFFFFFF);
            String label = hue ? m.settingName : String.format("%s %.2f", m.settingName, m.value);
            c.drawTextWithShadow(textRenderer, label, x + 10, sy - 10, 0xFF6F7788);
        } else {
            c.drawTextWithShadow(textRenderer, m.enabled ? "ON" : "OFF", x + 10, y + cardH - 13,
                    m.enabled ? CYAN : 0xFF5E6575);
        }
    }

    private boolean inSlider(int i, double mx, double my) {
        int x = cx(i), y = cy(i);
        return mx >= x + 6 && mx <= x + cardW - 6 && my >= y + cardH - 18 && my <= y + cardH - 4;
    }

    private void dragTo(int i, double mx) {
        Modules.Module m = Modules.ALL.get(i);
        m.setNorm((float) ((mx - (cx(i) + 10)) / (cardW - 20)));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            for (int i = 0; i < Modules.ALL.size(); i++) {
                Modules.Module m = Modules.ALL.get(i);
                if (m.hasSetting() && inSlider(i, mx, my)) { dragging = m; dragTo(i, mx); return true; }
                int x = cx(i), y = cy(i);
                if (mx >= x && mx < x + cardW && my >= y && my < y + cardH) { m.enabled = !m.enabled; return true; }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) { dragTo(Modules.ALL.indexOf(dragging), mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if ((key == GLFW.GLFW_KEY_0 || key == GLFW.GLFW_KEY_KP_0) && System.currentTimeMillis() - openedAt > 200) {
            close();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void removed() { Modules.save(); }
}
