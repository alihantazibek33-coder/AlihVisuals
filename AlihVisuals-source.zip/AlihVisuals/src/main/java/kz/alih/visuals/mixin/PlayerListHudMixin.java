package kz.alih.visuals.mixin;

import kz.alih.visuals.AlihUsers;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerListHud.class)
public abstract class PlayerListHudMixin {
    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true)
    private void alih$logo(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
        if (AlihUsers.has(entry.getProfile().getId())) {
            cir.setReturnValue(AlihUsers.withLogo(cir.getReturnValue()));
        }
    }
}
