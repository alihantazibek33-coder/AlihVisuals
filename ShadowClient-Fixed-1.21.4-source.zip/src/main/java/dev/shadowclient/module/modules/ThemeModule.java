package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class ThemeModule extends ClientModule {
    public ThemeModule() { super("Theme", "Enables the Shadow purple accent theme.", ModuleCategory.QUALITY); }
}
