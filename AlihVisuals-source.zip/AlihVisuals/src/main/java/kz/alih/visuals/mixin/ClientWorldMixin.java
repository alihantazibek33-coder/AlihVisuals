package kz.alih.visuals.mixin;

import kz.alih.visuals.Ambience;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public abstract class ClientWorldMixin {

    @Inject(method = "getSkyColor(Lnet/minecraft/util/math/Vec3d;F)I", at = @At("RETURN"), cancellable = true, require = 0)
    private void alih$sky(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Integer> cir) {
        if (Ambience.on()) cir.setReturnValue(Ambience.skyColor());
    }

    @Inject(method = "getCloudsColor(F)I", at = @At("RETURN"), cancellable = true, require = 0)
    private void alih$clouds(float tickDelta, CallbackInfoReturnable<Integer> cir) {
        if (Ambience.on()) cir.setReturnValue(Ambience.cloudColor());
    }
}
