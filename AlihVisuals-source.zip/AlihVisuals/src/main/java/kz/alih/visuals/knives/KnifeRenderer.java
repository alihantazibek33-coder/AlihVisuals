package kz.alih.visuals.knives;

import kz.alih.visuals.cosmetics.BBModel;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/** Draws the chosen knife in the first-person hand, with a small idle sway and a per-knife inspect animation. */
public final class KnifeRenderer {
    private static final Map<String, String> MODEL_JSON = new HashMap<>();

    private KnifeRenderer() {}

    private static byte[] read(String path) {
        try (InputStream in = MinecraftClient.getInstance().getResourceManager().open(Identifier.of("alihvisuals", path))) {
            return in.readAllBytes();
        } catch (Throwable t) {
            return null;
        }
    }

    public static BBModel model(KnifeData.Knife k, String skin) {
        String json = MODEL_JSON.get(k.id());
        if (json == null) {
            byte[] b = read("knives/models/" + k.id() + ".bbmodel");
            if (b == null) return null;
            json = new String(b, StandardCharsets.UTF_8);
            MODEL_JSON.put(k.id(), json);
        }
        String key = "knife:" + k.id() + ":" + skin;
        byte[] png = skinBytes(k, skin);
        if (png.length == 0) return null;
        return BBModel.loadSkinned(key, json, png);
    }

    private static final Map<String, byte[]> SKIN_BYTES = new HashMap<>();

    private static byte[] skinBytes(KnifeData.Knife k, String skin) {
        String key = k.id() + "_" + skin;
        byte[] b = SKIN_BYTES.get(key);
        if (b == null) {
            b = read("knives/skins/" + key + ".png");
            if (b != null) SKIN_BYTES.put(key, b);
        }
        return b == null ? new byte[0] : b;
    }

    // ------------------------------------------------------------------ animation
    private static final class Anim {
        float x, y, z, rx, ry, rz;
        float py, pz;                       // pivot of the local rotation (model pixels, relative to the grip centre)
        Function<String, float[]> pose;
    }

    private static float clamp01(float v) { return v < 0f ? 0f : Math.min(1f, v); }
    private static float smooth(float v) { v = clamp01(v); return v * v * (3f - 2f * v); }

    private static float easeOutBack(float v) {
        v = clamp01(v);
        float c1 = 1.70158f, c3 = c1 + 1f, u = v - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    /**
     * Inspect animations follow how these knives are really handled:
     *  - butterfly (balisong): close both handles around the blade, rollover, flick open, fan
     *  - karambit: held reverse-grip, spins 360 degrees around the finger ring, flips forward/reverse
     *  - push daggers: fist thrusts, then a flip
     *  - the rest: reverse-grip flip, toss-and-catch, slash, axis spin
     */
    private static Anim animate(KnifeData.Knife k, float inspectT, float idleT) {
        Anim a = new Anim();
        a.rx = 2.0f * (float) Math.sin(idleT * 0.9f);
        a.ry = 1.5f * (float) Math.sin(idleT * 1.1f);
        a.y = 0.15f * (float) Math.sin(idleT * 1.3f);
        if (inspectT < 0f || inspectT > k.inspectSeconds()) return a;
        float p = inspectT / k.inspectSeconds();
        float lift = (float) Math.sin(Math.PI * p);
        switch (k.id()) {
            case "m9" -> {                      // reverse-grip flip, then show the other side
                a.rx += 360f * smooth((p - 0.1f) / 0.45f);
                a.ry += 180f * smooth((p - 0.55f) / 0.35f);
                a.y += 4f * lift;
            }
            case "stiletto" -> {                // spin along the blade axis, small flick at the end
                a.ry += 720f * smooth((p - 0.05f) / 0.7f);
                a.rz += 25f * (float) Math.sin(2 * Math.PI * p);
                a.y += 3f * lift;
            }
            case "talon" -> {                   // hawkbill: two quick slashes, then a roll
                float sl = (float) Math.sin(Math.PI * 4f * clamp01(p / 0.6f));
                a.rx += -60f * sl * (1f - p);
                a.rz += 40f * sl;
                a.ry += 360f * smooth((p - 0.6f) / 0.35f);
                a.y += 2f * lift;
            }
            case "karambit" -> {                // ring spin around the finger, then forward/reverse switch
                a.py = -5.1f; a.pz = -0.3f;     // the finger ring is the pivot
                a.rx += 720f * smooth((p - 0.08f) / 0.55f);
                a.ry += 180f * smooth((p - 0.65f) / 0.25f);
                a.y += 3f * lift;
            }
            case "skeleton" -> {                // toss and catch
                float up = (float) Math.sin(Math.PI * smooth(p / 0.8f));
                a.y += 14f * up;
                a.rx += 720f * smooth(p / 0.8f);
                a.ry += 30f * (float) Math.sin(2 * Math.PI * p);
            }
            case "butterfly" -> {               // balisong: close, rollover, flick open, fan
                final float hb = 180f * smooth((p - 0.08f) / 0.22f) - 180f * easeOutBack((p - 0.68f) / 0.12f);
                final float ha = -180f * smooth((p - 0.20f) / 0.18f) + 180f * easeOutBack((p - 0.62f) / 0.10f);
                float fan = p > 0.82f ? (float) Math.sin((p - 0.82f) * 55f) * 28f * (1f - (p - 0.82f) / 0.18f) : 0f;
                final float fa = ha + fan, fb = hb - fan;
                a.rx += 360f * smooth((p - 0.38f) / 0.24f);
                a.ry += 20f * (float) Math.sin(2 * Math.PI * p);
                a.y += 2f * lift;
                a.pose = name -> switch (name) {
                    case "handle_a" -> new float[]{fa, 0f, 0f};
                    case "handle_b" -> new float[]{fb, 0f, 0f};
                    default -> null;
                };
            }
            case "shadow" -> {                  // two fist thrusts, then a flip
                float th = (float) Math.abs(Math.sin(Math.PI * 2f * clamp01(p / 0.5f)));
                a.z += -6f * th * (p < 0.5f ? 1f : 0f);
                a.rx += 360f * smooth((p - 0.55f) / 0.35f);
                a.ry += 12f * (float) Math.sin(4 * Math.PI * p);
            }
            default -> {}
        }
        return a;
    }

    // ------------------------------------------------------------------ drawing
    /** @return true if a knife was drawn (so the vanilla item must not be drawn) */
    public static boolean draw(MatrixStack ms, VertexConsumerProvider vcp, int light, boolean mirror) {
        KnifeState st = KnifeState.get();
        KnifeData.Knife k = st.knife();
        if (k == null) return false;
        BBModel m = model(k, st.skin(k.id()));
        if (m == null) return false;

        float[] t = st.transform(k);
        long now = System.currentTimeMillis();
        float inspectT = (now - st.inspectStart) / 1000f;
        float idleT = (now % 3_600_000L) / 1000f;
        Anim a = animate(k, inspectT, idleT);

        Matrix4f chain = new Matrix4f();
        if (mirror) chain.scale(-1f, 1f, 1f);
        chain.translate(t[1], t[2], t[3])
                .rotateY((float) Math.toRadians(t[5]))
                .rotateX((float) Math.toRadians(t[4]))
                .rotateY((float) Math.toRadians(t[6]))
                .scale(t[0] / 16f)
                .translate(a.x, a.y, a.z)
                .translate(0f, a.py, a.pz)
                .rotateX((float) Math.toRadians(a.rx))
                .rotateY((float) Math.toRadians(a.ry))
                .rotateZ((float) Math.toRadians(a.rz))
                .translate(0f, -a.py, -a.pz)
                .translate(0f, k.grip(), 0f);
        m.render(ms, vcp, light, OverlayTexture.DEFAULT_UV, chain, a.pose);
        return true;
    }
}
