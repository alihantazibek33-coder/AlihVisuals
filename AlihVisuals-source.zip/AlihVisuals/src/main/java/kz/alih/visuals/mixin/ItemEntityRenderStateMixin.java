package kz.alih.visuals.mixin;

import kz.alih.visuals.PhysicsHolder;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(ItemEntityRenderState.class)
public class ItemEntityRenderStateMixin implements PhysicsHolder {
    @Unique private float alih$b, alih$a, alih$y;

    @Override public void alih$set(float blend, float angle, float yaw) { alih$b = blend; alih$a = angle; alih$y = yaw; }
    @Override public float alih$blend() { return alih$b; }
    @Override public float alih$angle() { return alih$a; }
    @Override public float alih$yaw() { return alih$y; }
}
