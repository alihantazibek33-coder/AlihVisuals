import numpy as np, base64, io, math, json
from PIL import Image

def T(x,y,z):
    m=np.eye(4); m[:3,3]=[x,y,z]; return m
def Rx(a):
    c,s=math.cos(a),math.sin(a); m=np.eye(4); m[1,1]=c; m[1,2]=-s; m[2,1]=s; m[2,2]=c; return m
def Ry(a):
    c,s=math.cos(a),math.sin(a); m=np.eye(4); m[0,0]=c; m[0,2]=s; m[2,0]=-s; m[2,2]=c; return m
def Rz(a):
    c,s=math.cos(a),math.sin(a); m=np.eye(4); m[0,0]=c; m[0,1]=-s; m[1,0]=s; m[1,1]=c; return m
rad=math.radians

class Model:
    def __init__(self, j):
        self.j=j
        self.elems={e['uuid']:e for e in j['elements']}
        t=j['textures'][0]
        self.tex=np.array(Image.open(io.BytesIO(base64.b64decode(t['source'].split(',')[1]))).convert('RGBA'))
        self.uw,self.uh=t['uv_width'],t['uv_height']
        self.anims={a['name'].lower():a for a in j.get('animations',[])}
        self.uname={}
        def reg(n):
            self.uname[n['uuid']]=n['name'].lower()
            for c in n.get('children',[]):
                if isinstance(c,dict): reg(c)
        for n in j['outliner']: reg(n)
    def pose(self,anim,t):
        a=self.anims.get(anim)
        if not a: return {}
        t=t%a['length'] if a['length']>0 else 0.0
        out={}
        for uid,an in a['animators'].items():
            name=self.uname.get(uid)
            if not name: continue
            rot=[k for k in an['keyframes'] if k['channel']=='rotation']
            pos=[k for k in an['keyframes'] if k['channel']=='position']
            def samp(kf):
                if not kf: return None
                kf=sorted(kf,key=lambda k:k['time'])
                ts=[k['time'] for k in kf]; vs=[[k['data_points'][0][c] for c in 'xyz'] for k in kf]
                if t<=ts[0]: return vs[0]
                if t>=ts[-1]: return vs[-1]
                for i in range(len(ts)-1):
                    if ts[i]<=t<=ts[i+1]:
                        f=(t-ts[i])/max(1e-6,ts[i+1]-ts[i])
                        return [vs[i][c]+(vs[i+1][c]-vs[i][c])*f for c in range(3)]
            r=samp(rot); p=samp(pos)
            o=[0]*6
            if r: o[0],o[1],o[2]=-r[0],-r[1],r[2]
            if p: o[3],o[4],o[5]=-p[0],p[1],p[2]
            out[name]=o
        return out
    def quads(self,pose=None,root=np.eye(4)):
        pose=pose or {}
        res=[]
        def node_m(n,parent):
            o=n.get('origin',[0,0,0]); r=n.get('rotation',[0,0,0]); d=pose.get(n['name'].lower(),[0]*6)
            rx,ry,rz=r[0]+d[0],r[1]+d[1],r[2]+d[2]
            return parent@T(d[3],d[4],d[5])@T(*o)@Rz(rad(rz))@Ry(rad(ry))@Rx(rad(rx))@T(-o[0],-o[1],-o[2])
        def walk(n,parent):
            m=node_m(n,parent)
            for c in n.get('children',[]):
                if isinstance(c,str):
                    e=self.elems.get(c)
                    if e: self.element(e,m,res)
                else: walk(c,m)
        for n in self.j['outliner']: walk(n,root)
        return res
    def element(self,e,M,res):
        o=e['origin']; r=e['rotation']; f=e['from']; t=e['to']
        E=T(*o)@Rz(rad(r[2]))@Ry(rad(r[1]))@Rx(rad(r[0]))@T(-o[0],-o[1],-o[2])
        x0,y0,z0=f; x1,y1,z1=t
        faces={'north':[(x1,y1,z0),(x0,y1,z0),(x0,y0,z0),(x1,y0,z0)],
               'south':[(x0,y1,z1),(x1,y1,z1),(x1,y0,z1),(x0,y0,z1)],
               'east':[(x1,y1,z1),(x1,y1,z0),(x1,y0,z0),(x1,y0,z1)],
               'west':[(x0,y1,z0),(x0,y1,z1),(x0,y0,z1),(x0,y0,z0)],
               'up':[(x0,y1,z0),(x1,y1,z0),(x1,y1,z1),(x0,y1,z1)],
               'down':[(x0,y0,z1),(x1,y0,z1),(x1,y0,z0),(x0,y0,z0)]}
        for k,c in faces.items():
            fa=e['faces'].get(k)
            if not fa: continue
            u1,v1,u2,v2=fa['uv']
            uvs=[(u1,v1),(u2,v1),(u2,v2),(u1,v2)]
            P=np.array([(M@E@np.array([*p,1.0]))[:3] for p in c])
            UV=np.array([(u/self.uw,v/self.uh) for u,v in uvs])
            res.append((P,UV))

def render(quads,tex,cam,size=420,light=True):
    """cam: function mapping Nx3 points -> (x,y,depth) screen coords already scaled"""
    H=W=size
    img=np.zeros((H,W,4),np.uint8); img[:]=(32,36,44,255)
    zb=np.full((H,W),1e9)
    th,tw=tex.shape[:2]
    for P,UV in quads:
        S=cam(P)
        n=np.cross(P[1]-P[0],P[3]-P[0]); ln=np.linalg.norm(n)
        shade=1.0
        for tri in ((0,1,2),(0,2,3)):
            a,b,c=S[tri[0]],S[tri[1]],S[tri[2]]
            minx=int(max(0,math.floor(min(a[0],b[0],c[0])))); maxx=int(min(W-1,math.ceil(max(a[0],b[0],c[0]))))
            miny=int(max(0,math.floor(min(a[1],b[1],c[1])))); maxy=int(min(H-1,math.ceil(max(a[1],b[1],c[1]))))
            if minx>maxx or miny>maxy: continue
            den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
            if abs(den)<1e-9: continue
            xs,ys=np.meshgrid(np.arange(minx,maxx+1)+0.5,np.arange(miny,maxy+1)+0.5)
            w1=((b[1]-c[1])*(xs-c[0])+(c[0]-b[0])*(ys-c[1]))/den
            w2=((c[1]-a[1])*(xs-c[0])+(a[0]-c[0])*(ys-c[1]))/den
            w3=1-w1-w2
            m=(w1>=-1e-4)&(w2>=-1e-4)&(w3>=-1e-4)
            if not m.any(): continue
            z=w1*a[2]+w2*b[2]+w3*c[2]
            u=w1*UV[tri[0]][0]+w2*UV[tri[1]][0]+w3*UV[tri[2]][0]
            v=w1*UV[tri[0]][1]+w2*UV[tri[1]][1]+w3*UV[tri[2]][1]
            ti=np.clip((u*tw).astype(int),0,tw-1); tj=np.clip((v*th).astype(int),0,th-1)
            col=tex[tj,ti]
            sub=zb[miny:maxy+1,minx:maxx+1]
            ok=m&(z<sub)&(col[...,3]>128)
            sub[ok]=z[ok]
            img[miny:maxy+1,minx:maxx+1][ok]=col[ok]
    return Image.fromarray(img)
