package kz.alih.visuals;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import kz.alih.visuals.cosmetics.CosmeticType;
import kz.alih.visuals.cosmetics.CosmeticsState;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.EnumMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Knows which players use AlihVisuals (logo in front of their name in the tab list) and what cosmetics they wear.
 * You always see the logo on yourself. Everyone else comes from a small sync server (Cloudflare Worker):
 *   POST {endpoint}/state   {"uuid": "...", "loadout": {"CAPE": "...", ...}}   when your loadout changes
 *   GET  {endpoint}/users   {"<uuid>": {"l": {...}}, ...}                        every 60 s
 * A plain text file with one uuid per line (e.g. on GitHub raw) also works for the GET part.
 */
public final class AlihUsers {
    /** put your Worker address here before you release the mod, e.g. "https://alih-sync.yourname.workers.dev" */
    private static final String DEFAULT_ENDPOINT = "https://alih-sync.twixdark01.workers.dev";

    private static final Set<UUID> USERS = ConcurrentHashMap.newKeySet();
    private static final Identifier FONT = Identifier.of("alihvisuals", "logo");
    private static final Text LOGO = Text.literal("\uE000").setStyle(Style.EMPTY.withFont(FONT));
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private static final long REFRESH_PUBLISH_MS = 12L * 3600_000L;

    private static String lastPublished = "";
    private static long lastPublishMs = 0L;

    private AlihUsers() {}

    public static void init() {
        String endpoint = readEndpoint();
        if (endpoint.isEmpty()) return;
        ScheduledExecutorService ex = Executors.newScheduledThreadPool(1, r -> {
            Thread t = new Thread(r, "AlihVisuals-sync");
            t.setDaemon(true);
            return t;
        });
        ex.scheduleWithFixedDelay(() -> publish(endpoint), 5, 10, TimeUnit.SECONDS);
        ex.scheduleWithFixedDelay(() -> fetch(endpoint), 3, 60, TimeUnit.SECONDS);
    }

    private static String readEndpoint() {
        String e = DEFAULT_ENDPOINT;
        try {
            Path f = FabricLoader.getInstance().getConfigDir().resolve("alihvisuals_network.properties");
            Properties p = new Properties();
            if (Files.exists(f)) {
                try (var in = Files.newInputStream(f)) { p.load(in); }
            } else {
                p.setProperty("endpoint", "");
                try (var out = Files.newOutputStream(f)) { p.store(out, "AlihVisuals sync. Leave endpoint empty to use the built-in server."); }
            }
            String custom = p.getProperty("endpoint", "").trim();
            if (!custom.isEmpty()) e = custom;
        } catch (Exception ignored) {}
        e = e.trim();
        while (e.endsWith("/")) e = e.substring(0, e.length() - 1);
        return e;
    }

    // ------------------------------------------------------------------ publish my loadout
    private static void publish(String endpoint) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            UUID self = self();
            if (mc.world == null || self == null) return;

            JsonObject loadout = new JsonObject();
            for (Map.Entry<CosmeticType, String> en : CosmeticsState.get().localLoadout().entrySet()) {
                loadout.addProperty(en.getKey().name(), en.getValue());
            }
            JsonObject body = new JsonObject();
            body.addProperty("uuid", self.toString());
            body.add("loadout", loadout);
            String text = body.toString();

            long now = System.currentTimeMillis();
            if (text.equals(lastPublished) && now - lastPublishMs < REFRESH_PUBLISH_MS) return;

            HttpResponse<Void> r = HTTP.send(HttpRequest.newBuilder(URI.create(endpoint + "/state"))
                            .timeout(Duration.ofSeconds(8))
                            .header("Content-Type", "application/json")
                            .POST(HttpRequest.BodyPublishers.ofString(text)).build(),
                    HttpResponse.BodyHandlers.discarding());
            if (r.statusCode() / 100 == 2) { lastPublished = text; lastPublishMs = now; }
        } catch (Exception ignored) {
            // network problems must never affect the game
        }
    }

    // ------------------------------------------------------------------ read everyone else
    private static void fetch(String endpoint) {
        try {
            if (MinecraftClient.getInstance().world == null) return;
            HttpResponse<String> r = HTTP.send(HttpRequest.newBuilder(URI.create(endpoint + "/users"))
                    .timeout(Duration.ofSeconds(8)).GET().build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() != 200) return;
            String body = r.body().trim();

            Set<UUID> fresh = ConcurrentHashMap.newKeySet();
            if (body.startsWith("{")) {
                JsonObject root = JsonParser.parseString(body).getAsJsonObject();
                for (Map.Entry<String, JsonElement> en : root.entrySet()) {
                    UUID id;
                    try { id = UUID.fromString(en.getKey()); } catch (IllegalArgumentException e) { continue; }
                    fresh.add(id);
                    CosmeticsState.get().setRemote(id, parseLoadout(en.getValue()));
                }
            } else {
                for (String line : body.split("\\R")) {
                    try { fresh.add(UUID.fromString(line.trim())); } catch (IllegalArgumentException ignored) {}
                }
            }
            USERS.retainAll(fresh);
            USERS.addAll(fresh);
        } catch (Exception ignored) {
            // ignore
        }
    }

    private static Map<CosmeticType, String> parseLoadout(JsonElement e) {
        Map<CosmeticType, String> out = new EnumMap<>(CosmeticType.class);
        if (!e.isJsonObject() || !e.getAsJsonObject().has("l") || !e.getAsJsonObject().get("l").isJsonObject()) return out;
        for (Map.Entry<String, JsonElement> en : e.getAsJsonObject().getAsJsonObject("l").entrySet()) {
            try {
                if (en.getValue().isJsonPrimitive()) out.put(CosmeticType.valueOf(en.getKey()), en.getValue().getAsString());
            } catch (IllegalArgumentException ignored) {}
        }
        return out;
    }

    private static UUID self() {
        return MinecraftClient.getInstance().getSession().getUuidOrNull();
    }

    public static boolean has(UUID id) {
        if (id == null) return false;
        return id.equals(self()) || USERS.contains(id);
    }

    /** logo + space + original name (the name keeps its own team colour / style) */
    public static Text withLogo(Text name) {
        MutableText t = Text.empty();
        t.append(LOGO);
        t.append(Text.literal(" "));
        t.append(name);
        return t;
    }
}
