package kz.alih.visuals;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public final class Modules {
    private Modules() {}

    public static final class Setting {
        public final String name;
        public final float min, max, def;
        public float value;

        Setting(String name, float min, float max, float def) {
            this.name = name; this.min = min; this.max = max; this.def = def; this.value = def;
        }

        public float norm() { return (value - min) / (max - min); }
        public void setNorm(float t) { value = min + Math.max(0f, Math.min(1f, t)) * (max - min); }
    }

    public static final class Module {
        public final String name, desc;
        public boolean enabled;
        public float anim; // 0..1 toggle animation

        // optional primary slider ("Color" = hue slider)
        public String settingName;
        public float min, max, def, value;

        // optional extra sliders, style selector and reset button (all shown in the right-click settings panel)
        public final List<Setting> extras = new ArrayList<>();
        public String[] modes;
        public int mode;
        public boolean resettable;
        public boolean whole;                 // show/round the primary value as an integer
        public String modeLabel = "Style";    // caption above the mode buttons

        Module(String name, String desc) { this.name = name; this.desc = desc; }

        Module primary(String n, float min, float max, float def) {
            this.settingName = n; this.min = min; this.max = max; this.def = def; this.value = def; return this;
        }
        Module modes(String... m) { this.modes = m; return this; }
        Module extra(String n, float min, float max, float def) { extras.add(new Setting(n, min, max, def)); return this; }
        Module resettable() { this.resettable = true; return this; }
        Module whole() { this.whole = true; return this; }
        Module modeLabel(String l) { this.modeLabel = l; return this; }

        public boolean hasSetting() { return settingName != null; }
        public boolean hasAnySettings() { return hasSetting() || !extras.isEmpty() || modes != null || resettable; }
        public float norm() { return (value - min) / (max - min); }
        public void setNorm(float t) {
            value = min + Math.max(0f, Math.min(1f, t)) * (max - min);
            if (whole) value = Math.round(value);
        }
        public int rgb() { return Colors.hsb(value, 0.85f, 1f); } // for hue settings
        public void resetExtras() { for (Setting s : extras) s.value = s.def; }
        String key() { return name.replace(' ', '_'); }
    }

    public static final Module FULLBRIGHT = new Module("Fulbright", "Түнгі көру, бәрі жарық");
    public static final Module ASPECT = new Module("Aspect Ratio", "Әлемді растяг ету (HUD қалады)").primary("Stretch", 0.4f, 1.6f, 0.75f);
    public static final Module CHINAHAT = new Module("ChinaHat", "Қытай шляпасы (тек өзіңде)").primary("Color", 0f, 1f, 0.57f);
    public static final Module FREELOOK = new Module("Freelock", "Alt ұстап тұр - денең бұрылмай, камера бұрылады")
            .modes("Third Person", "First Person").modeLabel("View");
    public static final Module BLOCKOVERLAY = new Module("Block Overlay", "Қараған блок түсі").primary("Color", 0f, 1f, 0.55f);
    public static final Module HITCOLOR = new Module("HitColor", "Ұрғанда скин түсі өзгереді").primary("Color", 0f, 1f, 0.78f);
    public static final Module NOFLUID = new Module("NoFluid", "Су/лава астында тұман жоқ");
    public static final Module JUMPCIRCLES = new Module("Jump Circles", "Секіргенде домалақ шығады").primary("Color", 0f, 1f, 0.55f);
    public static final Module TARGETHUD = new Module("TargetHud", "Қарап тұрған ойыншы инфосы");
    public static final Module WATERMARK = new Module("Watermark", "AlihVisuals | ms | FPS");
    public static final Module ITEMPHYSIC = new Module("Item Physic", "Лақтырған зат физикамен түседі");
    public static final Module SHADERHANDS = new Module("Shader Hands", "Қол мен зат жарқырайды").primary("Color", 0f, 1f, 0.52f);
    public static final Module SWING = new Module("Swing Animation", "Ұрғанда әдемі анимация").primary("Power", 0.5f, 2f, 1f);
    public static final Module TRAILS = new Module("Trails", "Денеңнен жарық із қалады").primary("Color", 0f, 1f, 0.55f)
            .modes("Ribbon", "Wave", "Sparks", "Helix");
    // ViewModel extras: 0=X 1=Y 2=Z 3=Scale 4=RotX 5=RotY 6=RotZ
    public static final Module VIEWMODEL = new Module("ViewModel", "Қолды өз қалауыңша орналастыр")
            .extra("X", -0.8f, 0.8f, 0f).extra("Y", -0.8f, 0.8f, 0f).extra("Z", -0.9f, 0.5f, 0f)
            .extra("Scale", 0.4f, 1.6f, 1f)
            .extra("Rotate X", -90f, 90f, 0f).extra("Rotate Y", -90f, 90f, 0f).extra("Rotate Z", -90f, 90f, 0f)
            .resettable();
    public static final Module AUTOEZ = new Module("AutoEzz", "Ойыншы өлтірсең чатқа ezz жазады");
    public static final Module TARGETRENDER = new Module("TargetRender", "Нысана айналасында эффект").primary("Color", 0f, 1f, 0.52f)
            .modes("Ghost", "Circle", "Jello", "Crystal");
    // HitBox extras: 0=Fill
    public static final Module HITBOX = new Module("HitBox", "Хитбокс; ұруға болатын нысана қызыл болады").primary("Color", 0f, 1f, 0.55f)
            .modes("Outline", "Filled", "Corners").extra("Fill", 0f, 1f, 0.25f);

    public static final Module HITPARTICLES = new Module("Hit Particles", "Ұрғанда әдемі бөлшектер шығады").primary("Color", 0f, 1f, 0.58f)
            .modes("Burst", "Stars", "Ring");
    public static final Module PREDICTION = new Module("Prediction", "Жебе / перл қайда түсетінін көрсетеді").primary("Color", 0f, 1f, 0.55f)
            .modes("Line", "Dots");
    public static final Module WORLDPARTICLES = new Module("World Particles", "Айналаңда ұшып жүрген бөлшектер").primary("Color", 0f, 1f, 0.55f)
            .modes("Snow", "Fireflies", "Magic");
    // Ambience extras: 0=Neon Time
    public static final Module AMBIENCE = new Module("Ambience", "Аспан, уақыт, ауа райы").primary("Color", 0f, 1f, 0.78f)
            .modes("Sunset", "Night", "Dawn", "Neon").extra("Neon Time", 0f, 24000f, 18000f);

    public static final Module FREECAM = new Module("FreeCam", "Камера еркін ұшады, денең орнында қалады").primary("Speed", 0.2f, 3f, 1f);
    public static final Module BLOCKPICK = new Module("Block Pick", "Творчествода H - қараған блок қолыңа");
    public static final Module COORDINATES = new Module("Coordinates", "Координата экранда (Bedrock стилі)");
    public static final Module AUTOSPRINT = new Module("AutoSprint", "Жүргенде бірден жүгіреді");
    public static final Module AUTOTOOL = new Module("AutoTool", "Блокқа лайық құрал қолыңа өзі келеді");
    public static final Module AUTOEAT = new Module("AutoEat", "Қарның ашқанда тамақты өзі жейді").primary("Hunger", 1f, 10f, 3f).whole();
    public static final Module DEATHCOORD = new Module("DeathCoord", "Өлген жеріңе метка қояды").primary("Color", 0f, 1f, 0.98f);
    public static final Module ZOOM = new Module("Zoom", "G ұстап тұр - жақындатады (дөңгелек - күші)").primary("Zoom", 1.5f, 10f, 4f);
    public static final Module NAMETAG = new Module("Nametag", "Өз ниігің 2-3 бет көрінісінде көрінеді")
            .modes("Default", "Gold", "Rainbow", "Nebula", "Sakura", "Midnight", "Frost", "Toxic").modeLabel("Nick color");

    public static final List<Module> ALL = List.of(FULLBRIGHT, ASPECT, CHINAHAT, FREELOOK, BLOCKOVERLAY,
            HITCOLOR, NOFLUID, JUMPCIRCLES, TARGETHUD, WATERMARK, ITEMPHYSIC, SHADERHANDS, SWING, TRAILS, VIEWMODEL,
            AUTOEZ, TARGETRENDER, HITBOX, HITPARTICLES, PREDICTION, WORLDPARTICLES, AMBIENCE,
            FREECAM, BLOCKPICK, COORDINATES, AUTOSPRINT, AUTOTOOL, AUTOEAT, DEATHCOORD, ZOOM, NAMETAG);

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("alihvisuals.properties"); }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            Properties p = new Properties();
            p.load(r);
            for (Module m : ALL) {
                m.enabled = Boolean.parseBoolean(p.getProperty(m.key() + ".enabled", "false"));
                m.anim = m.enabled ? 1f : 0f;
                if (m.hasSetting()) {
                    try { m.value = Float.parseFloat(p.getProperty(m.key() + ".value", String.valueOf(m.value))); }
                    catch (NumberFormatException ignored) {}
                }
                for (Setting st : m.extras) {
                    try { st.value = Float.parseFloat(p.getProperty(m.key() + "." + st.name.replace(' ', '_'), String.valueOf(st.value))); }
                    catch (NumberFormatException ignored) {}
                }
                if (m.modes != null) {
                    try { m.mode = Math.max(0, Math.min(m.modes.length - 1, Integer.parseInt(p.getProperty(m.key() + ".mode", "0")))); }
                    catch (NumberFormatException ignored) {}
                }
            }
        } catch (IOException ignored) {}
        FREECAM.enabled = false; FREECAM.anim = 0f;   // never start a world already in freecam
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : ALL) {
            p.setProperty(m.key() + ".enabled", String.valueOf(m.enabled));
            if (m.hasSetting()) p.setProperty(m.key() + ".value", String.valueOf(m.value));
            for (Setting st : m.extras) p.setProperty(m.key() + "." + st.name.replace(' ', '_'), String.valueOf(st.value));
            if (m.modes != null) p.setProperty(m.key() + ".mode", String.valueOf(m.mode));
        }
        try (Writer w = Files.newBufferedWriter(file())) { p.store(w, "AlihVisuals"); }
        catch (IOException ignored) {}
    }
}
