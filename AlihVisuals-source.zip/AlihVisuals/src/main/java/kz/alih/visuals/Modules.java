package kz.alih.visuals;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;

public final class Modules {
    private Modules() {}

    public static final class Module {
        public final String name, desc, settingName;
        public final float min, max;
        public boolean enabled;
        public float value;
        public float anim; // 0..1 toggle animation

        Module(String name, String desc) { this(name, desc, null, 0, 1, 0); }

        Module(String name, String desc, String settingName, float min, float max, float def) {
            this.name = name; this.desc = desc; this.settingName = settingName;
            this.min = min; this.max = max; this.value = def;
        }

        public boolean hasSetting() { return settingName != null; }
        public float norm() { return (value - min) / (max - min); }
        public void setNorm(float t) { value = min + Math.max(0f, Math.min(1f, t)) * (max - min); }
        public int rgb() { return Colors.hsb(value, 0.85f, 1f); } // for hue settings
        String key() { return name.replace(' ', '_'); }
    }

    public static final Module FULLBRIGHT = new Module("Fulbright", "Түнгі көру, бәрі жарық");
    public static final Module ASPECT = new Module("Aspect Ratio", "Әлемді растяг ету (HUD қалады)", "Stretch", 0.4f, 1.6f, 0.75f);
    public static final Module CHINAHAT = new Module("ChinaHat", "Көк қытай шляпасы (тек өзіңде)");
    public static final Module FREELOOK = new Module("Freelock", "Alt ұстап тұр - камера бұрылады");
    public static final Module BLOCKOVERLAY = new Module("Block Overlay", "Қараған блок түсі", "Color", 0f, 1f, 0.55f);
    public static final Module HITCOLOR = new Module("HitColor", "Ұрғанда скин түсі өзгереді", "Color", 0f, 1f, 0.78f);
    public static final Module NOFLUID = new Module("NoFluid", "Су/лава астында тұман жоқ");
    public static final Module JUMPCIRCLES = new Module("Jump Circles", "Секіргенде домалақ шығады", "Color", 0f, 1f, 0.55f);
    public static final Module TARGETHUD = new Module("TargetHud", "Қарап тұрған ойыншы инфосы");
    public static final Module WATERMARK = new Module("Watermark", "AlihVisuals | ms | FPS");

    public static final List<Module> ALL = List.of(FULLBRIGHT, ASPECT, CHINAHAT, FREELOOK, BLOCKOVERLAY,
            HITCOLOR, NOFLUID, JUMPCIRCLES, TARGETHUD, WATERMARK);

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("alihvisuals.properties"); }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            Properties p = new Properties();
            p.load(r);
            for (Module m : ALL) {
                m.enabled = Boolean.parseBoolean(p.getProperty(m.key() + ".enabled", "false"));
                m.anim = m.enabled ? 1f : 0f;
                if (m.hasSetting()) {
                    try { m.value = Float.parseFloat(p.getProperty(m.key() + ".value", String.valueOf(m.value))); }
                    catch (NumberFormatException ignored) {}
                }
            }
        } catch (IOException ignored) {}
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : ALL) {
            p.setProperty(m.key() + ".enabled", String.valueOf(m.enabled));
            if (m.hasSetting()) p.setProperty(m.key() + ".value", String.valueOf(m.value));
        }
        try (Writer w = Files.newBufferedWriter(file())) { p.store(w, "AlihVisuals"); }
        catch (IOException ignored) {}
    }
}
