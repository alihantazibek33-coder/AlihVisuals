# AlihVisuals (Fabric 1.21.4)
Меню: **0** пернесі. Build: `gradle build` (Java 21) -> build/libs/alihvisuals-1.0.0.jar
Немесе GitHub-қа жүктеп, Actions -> build -> Artifacts.

## Пернелер (Controls -> AlihVisuals)
- **Left Alt** (ұстап тұр) - Freelock. Баптауда View: Third Person / First Person
- **F7** - FreeCam қосу/өшіру (меню арқылы да болады). WASD + Space/Shift, Ctrl - жылдам
- **G** (ұстап тұр) - Zoom, дөңгелек - күшін өзгертеді
- **H** - творчествода қараған блокты қолға алу (Block Pick модулі қосулы болса)

## Чат командалары
- `.dupe [саны]` - қолдағы затты көшіреді (тек творчество, зачарование сақталады)
- `.friends add <ник>` / `.friends remove <ник>` / `.friends list` - достар ұрылмайды (add үшін ойында болуы керек)

## Музыка
Файлдарды `config/alihvisuals/music` папкасына сал. Аты - файл атынан кеңейтілімсіз.
mp3 және wav тікелей ойнайды. Басқа формат (mp4, m4a, ogg, flac) үшін ffmpeg орнатылған болу керек.

## Қылыштар -> Предмет
Қылыштар менюінің оң жақ жоғарғы бұрышында "Предмет" - атын немесе id-ін жазып, кез келген предметтің текстурасын қылышқа қоясың.

## CS2 пышақтары (анимациялы)
Қылыштар менюінде "CS2 ..." деп басталатын 10 пышақ бар (Karambit, Butterfly, M9, Bayonet, Talon, Stiletto, Shadow Daggers, Skeleton, Huntsman, Seal).
Біріншісін таңдасаң, қолыңдағы қылыш (таңдалған қылыш түрлері ғана) 3D анимациялы пышаққа ауысады:
- алғаш қолға алғанда `draw`, содан кейін `idle` циклі;
- әр соққыда `melee_1` / `melee_2`;
- **J** пернесі (Controls -> AlihVisuals -> "Inspect knife") -> `inspect` анимациясы.
Орнын/өлшемін ViewModel модулінің слайдерлерімен реттеуге болады. Инвентарьда, жерде және басқа ойыншыларда жалпақ иконка көрінеді.

Модельдер "CS2 Knifes Pack" (TACZ форматы) пакінен `tools/build_knives.py` арқылы аударылған (Bedrock geo -> .bbmodel). Қайта жасау:
`CS2_PACK=<пак>/assets/cs2_wt python3 tools/build_knives.py` (numpy + Pillow керек). Модельдердің авторлары мен лицензиясы пак авторына тиесілі.
