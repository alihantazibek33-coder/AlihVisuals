package dev.shadowclient.gui;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;
import dev.shadowclient.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.Arrays;
import java.util.List;

public final class ClickGuiScreen extends Screen {
    private ModuleCategory selected = ModuleCategory.HUD;
    private int px, py, pw, ph, listX, listY, listW;
    private static final int ACCENT = 0xFFB18CFF;

    public ClickGuiScreen() { super(Text.literal("ShadowClient")); }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        pw = Math.min(650, width - 28);
        ph = Math.min(390, height - 28);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        int sidebar = 142;

        // Window, top accent, and header
        ctx.fill(px, py, px + pw, py + ph, 0xF0101118);
        ctx.fill(px, py, px + pw, py + 3, ACCENT);
        ctx.fill(px, py + 48, px + pw, py + 49, 0xFF30313D);
        ctx.drawText(textRenderer, "SHADOW", px + 16, py + 13, 0xFFF4F0FF, false);
        ctx.drawText(textRenderer, "CLIENT  /  1.21.4", px + 76, py + 14, ACCENT, false);
        ctx.drawText(textRenderer, "RIGHT SHIFT", px + pw - 88, py + 15, 0xFF9293A5, false);

        // Search-style label (visual only)
        ctx.fill(px + 16, py + 58, px + sidebar - 8, py + 82, 0xFF1C1D27);
        ctx.drawText(textRenderer, "MODULES", px + 25, py + 66, 0xFF9B9CAC, false);

        int cy = py + 94;
        for (ModuleCategory category : ModuleCategory.values()) {
            boolean active = category == selected;
            int x1 = px + 12, x2 = px + sidebar - 8;
            ctx.fill(x1, cy, x2, cy + 29, active ? 0xFF30283F : 0xFF171820);
            if (active) ctx.fill(x1, cy, x1 + 3, cy + 29, ACCENT);
            ctx.drawText(textRenderer, category.title(), x1 + 12, cy + 10,
                    active ? 0xFFFFFFFF : 0xFFB5B6C5, false);
            cy += 34;
        }

        listX = px + sidebar + 8;
        listY = py + 60;
        listW = pw - sidebar - 24;
        ctx.drawText(textRenderer, selected.title().toUpperCase(), listX, py + 16, 0xFFE6E1F0, false);
        ctx.drawText(textRenderer, "Click module to toggle", listX, py + 33, 0xFF8E8FA0, false);

        List<ClientModule> modules = ModuleManager.inCategory(selected);
        int rowY = listY;
        int rowH = 43;
        int visible = Math.max(0, (py + ph - 30 - listY) / rowH);
        for (int i = 0; i < Math.min(modules.size(), visible); i++) {
            ClientModule module = modules.get(i);
            boolean hover = mouseX >= listX && mouseX <= listX + listW &&
                    mouseY >= rowY && mouseY <= rowY + 36;
            ctx.fill(listX, rowY, listX + listW, rowY + 36,
                    hover ? 0xFF292A36 : 0xFF1C1D26);
            ctx.drawText(textRenderer, module.name(), listX + 11, rowY + 6,
                    0xFFEDECF5, false);
            ctx.drawText(textRenderer, module.description(), listX + 11, rowY + 20,
                    0xFF898A9B, false);
            int pillX = listX + listW - 47;
            ctx.fill(pillX, rowY + 9, pillX + 36, rowY + 27,
                    module.enabled() ? 0xFF4A3A64 : 0xFF30313D);
            ctx.drawText(textRenderer, module.enabled() ? "ON" : "OFF",
                    pillX + 7, rowY + 14, module.enabled() ? ACCENT : 0xFF9A9BA8, false);
            rowY += rowH;
        }

        ctx.fill(px + 12, py + ph - 24, px + pw - 12, py + ph - 23, 0xFF292A35);
        ctx.drawText(textRenderer, "SHADOWCLIENT  •  Visual utility build",
                px + 16, py + ph - 16, 0xFF777888, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int cy = py + 94;
        for (ModuleCategory category : ModuleCategory.values()) {
            if (mouseX >= px + 12 && mouseX <= px + 134 &&
                    mouseY >= cy && mouseY <= cy + 29) {
                selected = category;
                return true;
            }
            cy += 34;
        }

        List<ClientModule> modules = ModuleManager.inCategory(selected);
        int rowY = listY;
        int rowH = 43;
        int visible = Math.max(0, (py + ph - 30 - listY) / rowH);
        for (int i = 0; i < Math.min(modules.size(), visible); i++) {
            if (mouseX >= listX && mouseX <= listX + listW &&
                    mouseY >= rowY && mouseY <= rowY + 36) {
                modules.get(i).toggle();
                return true;
            }
            rowY += rowH;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public boolean shouldPause() { return false; }
}
