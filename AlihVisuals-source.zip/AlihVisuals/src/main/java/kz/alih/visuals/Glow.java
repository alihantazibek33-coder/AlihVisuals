package kz.alih.visuals;

/** Small shared flags for the Shader Hands item glow. */
public final class Glow {
    private Glow() {}
    /** true while the first-person held item is being rendered */
    public static boolean inHand = false;
    /** guard against recursion while the glow passes are drawn */
    public static boolean busy = false;
}
