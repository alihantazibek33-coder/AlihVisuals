package kz.alih.visuals.replacer;

import kz.alih.visuals.Colors;
import kz.alih.visuals.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Pick any vanilla item (search by name or id); its texture / model is then shown on your sword. */
public class ItemPickerScreen extends Screen {
    private static final int CYAN = 0xFF5CE1FF;
    private static final int CW = 38, CH = 38, GAP = 4;

    private record Entry(Item item, String id, String name, String hay, ItemStack stack) {}

    private static List<Entry> ALL;
    private static String lastQuery = "";

    private final long openedAt = System.currentTimeMillis();
    private float al = 1f;
    private int px, py, pw, ph, gx, gy, gw, gh, cols;
    private float scroll, maxScroll;
    private boolean pressActive, moved;
    private double pressY;
    private int pressIndex = -1;
    private TextFieldWidget field;
    private List<Entry> shown = new ArrayList<>();

    public ItemPickerScreen() { super(Text.literal("Item picker")); }

    private static void buildAll() {
        if (ALL != null) return;
        List<Entry> list = new ArrayList<>();
        for (Item item : Registries.ITEM) {
            if (item == Items.AIR) continue;
            String id = Registries.ITEM.getId(item).toString();
            String name = item.getName().getString();
            list.add(new Entry(item, id, name, (name + " " + id).toLowerCase(Locale.ROOT), new ItemStack(item)));
        }
        ALL = list;
    }

    @Override
    protected void init() {
        buildAll();
        layout();
        field = new TextFieldWidget(textRenderer, px + 10, py + 28, pw - 20 - 74, 18, Text.literal("Search"));
        field.setMaxLength(80);
        field.setText(lastQuery);
        field.setChangedListener(s -> { lastQuery = s; refilter(); scroll = 0; });
        addSelectableChild(field);
        setInitialFocus(field);
        refilter();
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { client.setScreen(new ReplacerScreen()); }

    private void layout() {
        pw = Math.min(width - 8, 520);
        ph = Math.min(height - 8, 330);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        gx = px + 10;
        gy = py + 66;
        gw = pw - 26;
        gh = py + ph - 10 - gy;
        cols = Math.max(1, (gw + GAP) / (CW + GAP));
        int rows = (shown.size() + cols - 1) / cols;
        maxScroll = Math.max(0, rows * (CH + GAP) - GAP - gh);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
    }

    private void refilter() {
        String q = lastQuery.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) { shown = new ArrayList<>(ALL); return; }
        List<Entry> exact = new ArrayList<>(), starts = new ArrayList<>(), rest = new ArrayList<>();
        for (Entry e : ALL) {
            if (e.id.equals(q) || e.id.equals("minecraft:" + q)) exact.add(e);
            else if (e.id.startsWith("minecraft:" + q) || e.name.toLowerCase(Locale.ROOT).startsWith(q)) starts.add(e);
            else if (e.hay.contains(q)) rest.add(e);
        }
        exact.addAll(starts);
        exact.addAll(rest);
        shown = exact;
    }

    private int A(int c) { return Colors.mulAlpha(c, al); }
    private void rr(DrawContext c, int x, int y, int w, int h, int r, int col) { Gfx.rrect(c, x, y, w, h, r, A(col)); }
    private void text(DrawContext c, String s, int x, int y, int col) {
        col = A(col);
        if ((col >>> 24) < 8) return;
        c.drawTextWithShadow(textRenderer, s, x, y, col);
    }
    private void ctext(DrawContext c, String s, int cx, int y, int col) {
        col = A(col);
        if ((col >>> 24) < 8) return;
        c.drawCenteredTextWithShadow(textRenderer, s, cx, y, col);
    }
    private boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    private static float clamp01(float v) { return v < 0f ? 0f : Math.min(1f, v); }

    private void item(DrawContext c, ItemStack stack, int x, int y, float scale) {
        MatrixStack ms = c.getMatrices();
        ms.push();
        ms.translate(x, y, 0f);
        ms.scale(scale, scale, 1f);
        ReplacerSwap.bypass = true;
        try { c.drawItem(stack, 0, 0); } finally { ReplacerSwap.bypass = false; }
        ms.pop();
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        float v = clamp01((System.currentTimeMillis() - openedAt) / 250f);
        c.fill(0, 0, width, height, Colors.mulAlpha(0xB0090B10, v));
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();
        float f = clamp01((System.currentTimeMillis() - openedAt) / 260f);
        al = 1f - (1f - f) * (1f - f);
        ReplacerConfig cfg = ReplacerConfig.get();

        rr(c, px - 1, py - 1, pw + 2, ph + 2, 11, 0xFF2C313C);
        rr(c, px, py, pw, ph, 10, 0xF01A1D24);
        ctext(c, "Предмет таңда", px + pw / 2, py + 10, CYAN);

        boolean bh = in(mx, my, px + 8, py + 6, 62, 16);
        rr(c, px + 8, py + 6, 62, 16, 7, bh ? 0xFF343946 : 0xFF2A2E38);
        ctext(c, "‹ Артқа", px + 8 + 31, py + 10, 0xFFB8BFCC);

        // search field + clear button
        field.render(c, mx, my, delta);
        int cbx = px + pw - 10 - 70;
        boolean ch = in(mx, my, cbx, py + 28, 70, 18);
        rr(c, cbx, py + 28, 70, 18, 6, ch ? 0xFF343946 : 0xFF2A2E38);
        ctext(c, "Тазалау", cbx + 35, py + 33, 0xFFB8BFCC);

        // grid
        String hoverName = null;
        c.enableScissor(gx - 2, gy, gx + gw + 2, gy + gh);
        for (int i = 0; i < shown.size(); i++) {
            int x = gx + (i % cols) * (CW + GAP);
            int y = gy - (int) scroll + (i / cols) * (CH + GAP);
            if (y + CH < gy || y > gy + gh) continue;
            Entry e = shown.get(i);
            boolean sel = cfg.item.equals(e.id);
            boolean hov = in(mx, my, x, y, CW, CH) && my >= gy && my < gy + gh;
            if (hov) hoverName = e.name + "  (" + e.id + ")";
            rr(c, x, y, CW, CH, 6, sel ? 0xFF4FC3F7 : 0xFF2C313C);
            rr(c, x + 1, y + 1, CW - 2, CH - 2, 5, hov ? 0xFF2D323E : 0xFF23262E);
            item(c, e.stack, x + 3, y + 3, 2f);
        }
        c.disableScissor();
        if (shown.isEmpty()) ctext(c, "Ештеңе табылмады", px + pw / 2, gy + 20, 0xFF8A90A0);

        if (maxScroll > 0) {
            int barH = Math.max(18, (int) (gh * gh / (gh + maxScroll)));
            int barY = gy + (int) ((gh - barH) * (scroll / maxScroll));
            rr(c, px + pw - 8, barY, 3, barH, 1, 0xFF3FA9C9);
        }

        String info = hoverName != null ? hoverName
                : (cfg.item.isEmpty() ? "Атын немесе ID жаз, содан соң таңда" : "Қазір: " + cfg.item);
        ctext(c, textRenderer.trimToWidth(info, pw - 40), px + pw / 2, py + 52, hoverName != null ? 0xFFE6E9EF : CYAN);
        al = 1f;
    }

    private int cardAt(double mx, double my) {
        if (my < gy || my >= gy + gh) return -1;
        for (int i = 0; i < shown.size(); i++) {
            int x = gx + (i % cols) * (CW + GAP);
            int y = gy - (int) scroll + (i / cols) * (CH + GAP);
            if (in(mx, my, x, y, CW, CH)) return i;
        }
        return -1;
    }

    private void choose(Entry e) {
        ReplacerConfig cfg = ReplacerConfig.get();
        cfg.item = e.id;
        cfg.enabled = true;
        cfg.save();
        client.setScreen(new ReplacerScreen());
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && !shown.isEmpty()) {
            choose(shown.get(0));
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        if (in(mx, my, px + 8, py + 6, 62, 16)) { close(); return true; }
        if (in(mx, my, px + pw - 80, py + 28, 70, 18)) {
            ReplacerConfig cfg = ReplacerConfig.get();
            cfg.item = "";
            cfg.save();
            return true;
        }
        if (my >= gy && my < gy + gh) {
            pressActive = true; moved = false; pressY = my; pressIndex = cardAt(mx, my);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (pressActive) {
            if (Math.abs(my - pressY) > 5) moved = true;
            if (moved) scroll = Math.max(0, Math.min(maxScroll, scroll - (float) dy));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        boolean pick = pressActive && !moved && pressIndex >= 0 && pressIndex == cardAt(mx, my);
        int idx = pressIndex;
        pressActive = false; pressIndex = -1;
        if (pick && idx < shown.size()) { choose(shown.get(idx)); return true; }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scroll = Math.max(0, Math.min(maxScroll, scroll - (float) vAmount * 28f));
        return true;
    }
}
