package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class CoordinatesModule extends ClientModule {
    public CoordinatesModule() { super("Coordinates", "Shows your current XYZ position.", ModuleCategory.HUD); }
}
