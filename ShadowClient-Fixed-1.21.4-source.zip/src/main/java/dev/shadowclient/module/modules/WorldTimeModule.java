package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class WorldTimeModule extends ClientModule {
    public WorldTimeModule() { super("World Time", "Shows the in-game day time.", ModuleCategory.HUD); }
}
