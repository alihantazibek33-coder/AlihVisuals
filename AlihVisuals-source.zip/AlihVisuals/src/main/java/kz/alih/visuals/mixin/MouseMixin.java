package kz.alih.visuals.mixin;

import kz.alih.visuals.Freecam;
import kz.alih.visuals.Freelook;
import kz.alih.visuals.Zoom;
import net.minecraft.client.Mouse;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public abstract class MouseMixin {
    // Freelook / FreeCam: the mouse turns the camera instead of the player (checked right where the mouse is applied)
    @Redirect(method = "updateMouse",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V"),
            require = 0)
    private void alih$turn(ClientPlayerEntity player, double dx, double dy) {
        if (Freecam.active) {
            Freecam.yaw += (float) dx * 0.15f;
            Freecam.pitch = MathHelper.clamp(Freecam.pitch + (float) dy * 0.15f, -90f, 90f);
        } else if (Freelook.active) {
            Freelook.look(dx, dy);
        } else {
            player.changeLookDirection(dx, dy);
        }
    }

    // Zoom: the mouse wheel changes the zoom strength instead of the hotbar slot
    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true, require = 0)
    private void alih$zoomScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (vertical != 0 && Zoom.isZooming()) {
            Zoom.scroll(vertical);
            ci.cancel();
        }
    }
}
