package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class CrosshairModule extends ClientModule {
    public CrosshairModule() { super("Custom Crosshair", "Customizable crosshair size and color.", ModuleCategory.VISUALS); }
}
