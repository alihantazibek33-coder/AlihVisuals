package kz.alih.visuals.mixin;

import kz.alih.visuals.GlowConsumer;
import kz.alih.visuals.Modules;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.TexturedRenderLayers;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Unique;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {

    private static final float[][] PASSES = {{1.04f, 0.32f}, {1.08f, 0.20f}, {1.13f, 0.11f}};

    // Shader Hands (item): draw the item again a few times, bigger, tinted, full-bright and translucent
    @Redirect(method = "renderItem",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/render/item/ItemRenderState;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;II)V"),
            require = 0)
    private void alih$glowItem(ItemRenderState s, MatrixStack ms, VertexConsumerProvider vcp, int light, int overlay) {
        s.render(ms, vcp, light, overlay);
        if (!Modules.SHADERHANDS.enabled) return;
        int rgb = Modules.SHADERHANDS.rgb();
        for (float[] ps : PASSES) {
            ms.push();
            ms.scale(ps[0], ps[0], ps[0]);
            final float alpha = ps[1];
            s.render(ms, layer -> new GlowConsumer(vcp.getBuffer(TexturedRenderLayers.getItemEntityTranslucentCull()), rgb, alpha),
                    LightmapTextureManager.MAX_LIGHT_COORDINATE, overlay);
            ms.pop();
        }
    }

    // ViewModel: move / rotate / scale the whole first-person hand
    @Unique private boolean alih$pushed = false;

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), require = 0)
    private void alih$vmHead(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                             float swing, ItemStack item, float equip, MatrixStack ms,
                             VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        alih$pushed = false;
        Modules.Module vm = Modules.VIEWMODEL;
        if (!vm.enabled) return;
        boolean left = hand == Hand.MAIN_HAND ? player.getMainArm() == Arm.LEFT : player.getMainArm() == Arm.RIGHT;
        float s = left ? -1f : 1f;
        float x = vm.extras.get(0).value, y = vm.extras.get(1).value, z = vm.extras.get(2).value;
        float sc = vm.extras.get(3).value;
        float rx = vm.extras.get(4).value, ry = vm.extras.get(5).value, rz = vm.extras.get(6).value;
        ms.push();
        alih$pushed = true;
        ms.translate(s * x, y, z);
        ms.translate(s * 0.56f, -0.52f, -0.72f);        // rotate / scale around the hand itself
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rx));
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(s * ry));
        ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s * rz));
        ms.scale(sc, sc, sc);
        ms.translate(-s * 0.56f, 0.52f, 0.72f);
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"), require = 0)
    private void alih$vmTail(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                             float swing, ItemStack item, float equip, MatrixStack ms,
                             VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        if (alih$pushed) { ms.pop(); alih$pushed = false; }
    }

    // Swing Animation
    @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true, require = 0)
    private void alih$swing(MatrixStack ms, Arm arm, float p, CallbackInfo ci) {
        if (!Modules.SWING.enabled) return;
        float pw = Modules.SWING.value;
        int i = arm == Arm.RIGHT ? 1 : -1;
        float f = MathHelper.sin(p * p * (float) Math.PI);
        float g = MathHelper.sin(MathHelper.sqrt(p) * (float) Math.PI);
        float h = MathHelper.sin(p * (float) Math.PI);
        ms.translate(i * 0.10f * g * pw, -0.12f * h * pw, -0.25f * g * pw);
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * (45f + f * -40f * pw)));
        ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * g * -30f * pw));
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -105f * pw));
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * -45f));
        ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * h * 18f * pw));
        ci.cancel();
    }
}
