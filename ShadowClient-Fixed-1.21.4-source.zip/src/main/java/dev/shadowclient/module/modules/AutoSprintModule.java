package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class AutoSprintModule extends ClientModule {
    public AutoSprintModule() { super("Auto Sprint", "Convenience sprint toggle for normal movement.", ModuleCategory.PLAYER); }
}
