package kz.alih.visuals;

import kz.alih.visuals.mixin.SimpleOptionAccessor;
import net.minecraft.client.MinecraftClient;

/** OptiFine / Zoomify style zoom: hold the key, scroll to change the strength. */
public final class Zoom {
    private Zoom() {}

    public static boolean keyDown;            // updated every tick from the keybinding
    private static float cur = 1f;
    private static Integer baseFov;
    private static Double baseSens;
    private static long lastNs;

    public static boolean isZooming() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return Modules.ZOOM.enabled && keyDown && mc.currentScreen == null && mc.player != null;
    }

    public static void scroll(double vertical) {
        Modules.ZOOM.value = Math.max(Modules.ZOOM.min, Math.min(Modules.ZOOM.max,
                Modules.ZOOM.value * (vertical > 0 ? 1.15f : 1f / 1.15f)));
    }

    /** Every rendered frame. */
    @SuppressWarnings("unchecked")
    public static void frame(MinecraftClient mc) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        if (mc.player == null) { restore(mc); cur = 1f; return; }

        float target = isZooming() ? Modules.ZOOM.value : 1f;
        cur += (target - cur) * (1f - (float) Math.exp(-dt * 14f));
        if (Math.abs(cur - target) < 0.004f) cur = target;

        if (cur <= 1.004f && target == 1f) { restore(mc); cur = 1f; return; }

        if (baseFov == null) baseFov = mc.options.getFov().getValue();
        if (baseSens == null) baseSens = mc.options.getMouseSensitivity().getValue();
        ((SimpleOptionAccessor<Integer>) (Object) mc.options.getFov())
                .alih$setRaw(Math.max(1, Math.round(baseFov / cur)));
        ((SimpleOptionAccessor<Double>) (Object) mc.options.getMouseSensitivity())
                .alih$setRaw(Math.max(0.0, baseSens / cur));
    }

    @SuppressWarnings("unchecked")
    public static void restore(MinecraftClient mc) {
        if (baseFov != null) {
            ((SimpleOptionAccessor<Integer>) (Object) mc.options.getFov()).alih$setRaw(baseFov);
            baseFov = null;
        }
        if (baseSens != null) {
            ((SimpleOptionAccessor<Double>) (Object) mc.options.getMouseSensitivity()).alih$setRaw(baseSens);
            baseSens = null;
        }
    }
}
