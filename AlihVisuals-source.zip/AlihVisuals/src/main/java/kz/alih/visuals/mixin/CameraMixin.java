package kz.alih.visuals.mixin;

import kz.alih.visuals.Freecam;
import kz.alih.visuals.Freelook;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import net.minecraft.world.RaycastContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow protected abstract void setPos(double x, double y, double z);

    /**
     * Freelook: after vanilla has finished placing the camera we put it where WE want it - the view direction comes
     * from the freelook angles, and in 3rd person the camera is moved back from the eyes along that direction
     * (with a simple wall check). Done at the very end of update(), so nothing can overwrite it.
     */
    @Inject(method = "update", at = @At("TAIL"), require = 0)
    private void alih$freelook(BlockView area, Entity focusedEntity, boolean thirdPerson,
                               boolean inverseView, float tickDelta, CallbackInfo ci) {
        if (!Freelook.active || Freecam.active) return;

        float yaw = Freelook.yaw, pitch = Freelook.pitch;
        if (thirdPerson && inverseView) { yaw += 180f; pitch = -pitch; }   // front view (F5 twice)
        setRotation(yaw, pitch);
        if (!thirdPerson) return;

        Vec3d eye = focusedEntity.getCameraPosVec(tickDelta);
        Vec3d fwd = Vec3d.fromPolar(pitch, yaw);
        double dist = 4.0;
        Vec3d target = eye.subtract(fwd.multiply(dist));
        BlockHitResult hit = area.raycast(new RaycastContext(eye, target,
                RaycastContext.ShapeType.VISUAL, RaycastContext.FluidHandling.NONE, focusedEntity));
        if (hit.getType() != HitResult.Type.MISS) {
            double d = Math.max(0.0, hit.getPos().distanceTo(eye) - 0.2);
            target = eye.subtract(fwd.multiply(d));
        }
        setPos(target.x, target.y, target.z);
    }

    // FreeCam: the camera leaves the body completely
    @Inject(method = "update", at = @At("TAIL"), require = 0)
    private void alih$freecam(BlockView area, Entity focusedEntity, boolean thirdPerson,
                              boolean inverseView, float tickDelta, CallbackInfo ci) {
        if (!Freecam.active) return;
        setRotation(Freecam.yaw, Freecam.pitch);
        setPos(MathHelper.lerp(tickDelta, Freecam.px, Freecam.x),
                MathHelper.lerp(tickDelta, Freecam.py, Freecam.y),
                MathHelper.lerp(tickDelta, Freecam.pz, Freecam.z));
    }
}
