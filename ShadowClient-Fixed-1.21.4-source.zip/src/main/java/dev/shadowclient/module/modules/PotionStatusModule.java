package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class PotionStatusModule extends ClientModule {
    public PotionStatusModule() { super("Effect Status", "Shows active potion effects and duration.", ModuleCategory.HUD); }
}
