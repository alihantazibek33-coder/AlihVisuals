package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class DirectionModule extends ClientModule {
    public DirectionModule() { super("Direction", "Displays cardinal facing direction.", ModuleCategory.HUD); }
}
