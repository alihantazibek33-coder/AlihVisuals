package kz.alih.visuals.replacer;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.CustomModelDataComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.List;

/** Gives a sword a custom_model_data string just for rendering, so the item definition picks the replacement model. */
public final class ReplacerSwap {
    /** set while the menu draws its own previews, so they are not replaced again */
    public static boolean bypass = false;

    private ReplacerSwap() {}

    public static ItemStack swap(ItemStack stack) {
        if (bypass || stack == null || stack.isEmpty()) return stack;
        ReplacerConfig c = ReplacerConfig.get();
        if (!c.enabled || (c.weapon.isEmpty() && c.item.isEmpty())) return stack;
        String id = Registries.ITEM.getId(stack.getItem()).toString();
        if (!c.replaces(id)) return stack;
        if (c.selfOnly && !isMine(stack)) return stack;

        // any vanilla item's texture / model on the sword
        if (!c.item.isEmpty()) {
            Identifier model = Identifier.tryParse(c.item);
            if (model != null) {
                if (model.equals(stack.get(DataComponentTypes.ITEM_MODEL))) return stack;
                ItemStack copy = stack.copy();
                copy.set(DataComponentTypes.ITEM_MODEL, model);
                return copy;
            }
        }

        CustomModelDataComponent cur = stack.get(DataComponentTypes.CUSTOM_MODEL_DATA);
        if (cur != null && List.of(c.weapon).equals(cur.strings())) return stack;
        ItemStack copy = stack.copy();
        copy.set(DataComponentTypes.CUSTOM_MODEL_DATA, new CustomModelDataComponent(List.of(), List.of(), List.of(c.weapon), List.of()));
        return copy;
    }

    /** the stack is one of the local player's own (hands / inventory) */
    private static boolean isMine(ItemStack stack) {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null) return true;                      // menus before the world exists
        if (p.getMainHandStack() == stack || p.getOffHandStack() == stack) return true;
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i) == stack) return true;
        return false;
    }
}
