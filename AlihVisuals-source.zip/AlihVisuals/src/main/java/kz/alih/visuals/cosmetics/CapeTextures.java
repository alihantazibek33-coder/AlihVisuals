package kz.alih.visuals.cosmetics;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.stream.ImageInputStream;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Loads .png / animated .gif capes. Decoding runs on a background thread, the GPU upload happens
 * on the render thread the first time the finished cape is asked for.
 */
public final class CapeTextures {
    private static final int MAX_FRAMES = 64;
    private static final int MAX_WIDTH = 256;

    private static final class Cape {
        volatile byte[][] pngs;
        volatile boolean failed;
        int width, height;
        int[] delays;
        int total;
        Identifier[] ids;
    }

    private static final Map<String, Cape> CACHE = new ConcurrentHashMap<>();
    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "AlihVisuals-capes");
        t.setDaemon(true);
        return t;
    });

    private CapeTextures() {}

    /** current frame of the cape, or null while it is still loading / failed */
    public static Identifier current(CosmeticsState.Entry e) {
        Cape c = ensure(e);
        if (c == null || c.ids == null) return null;
        if (c.ids.length == 1 || c.total <= 0) return c.ids[0];
        long t = System.currentTimeMillis() % c.total;
        for (int i = 0; i < c.ids.length; i++) {
            t -= c.delays[i];
            if (t < 0) return c.ids[i];
        }
        return c.ids[c.ids.length - 1];
    }

    /** {width, height} of the (normalised) cape texture, or null while loading */
    public static int[] size(CosmeticsState.Entry e) {
        Cape c = ensure(e);
        return c == null || c.ids == null ? null : new int[]{c.width, c.height};
    }

    private static Cape ensure(CosmeticsState.Entry e) {
        if (e == null) return null;
        String key = e.file().toString();
        Cape c = CACHE.get(key);
        if (c == null) {
            Cape fresh = new Cape();
            c = CACHE.putIfAbsent(key, fresh);
            if (c == null) {
                c = fresh;
                final Cape target = fresh;
                POOL.execute(() -> decode(e, target));
            }
        }
        if (c.pngs != null && c.ids == null && !c.failed) upload(c, key);
        return c.failed ? null : c;
    }

    private static void upload(Cape c, String key) {
        try {
            byte[][] data = c.pngs;
            Identifier[] ids = new Identifier[data.length];
            String base = "cape/" + Integer.toHexString(key.hashCode()) + "_";
            for (int i = 0; i < data.length; i++) {
                NativeImage img = NativeImage.read(new ByteArrayInputStream(data[i]));
                ids[i] = Identifier.of("alihvisuals", base + i);
                MinecraftClient.getInstance().getTextureManager().registerTexture(ids[i], new NativeImageBackedTexture(img));
            }
            c.ids = ids;
        } catch (Throwable t) {
            c.failed = true;
        }
    }

    // ------------------------------------------------------------------ decoding (background thread)
    private static void decode(CosmeticsState.Entry e, Cape c) {
        try {
            List<BufferedImage> frames = new ArrayList<>();
            List<Integer> delays = new ArrayList<>();
            String name = e.file().getFileName().toString().toLowerCase(Locale.ROOT);
            if (name.endsWith(".gif")) {
                readGif(e.file().toFile(), frames, delays);
            } else {
                BufferedImage img = ImageIO.read(e.file().toFile());
                if (img != null) { frames.add(img); delays.add(1000); }
            }
            if (frames.isEmpty()) { c.failed = true; return; }

            byte[][] out = new byte[frames.size()][];
            int[] d = new int[frames.size()];
            int total = 0;
            for (int i = 0; i < frames.size(); i++) {
                BufferedImage n = normalise(frames.get(i));
                if (i == 0) { c.width = n.getWidth(); c.height = n.getHeight(); }
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                ImageIO.write(n, "png", bos);
                out[i] = bos.toByteArray();
                d[i] = Math.max(20, delays.get(i));
                total += d[i];
            }
            c.delays = d;
            c.total = total;
            c.pngs = out;   // published last
        } catch (Throwable t) {
            c.failed = true;
        }
    }

    /** capes must be 2:1 (64x32 layout); old 22x17 capes are padded, huge ones are scaled down */
    private static BufferedImage normalise(BufferedImage src) {
        int w = src.getWidth(), h = src.getHeight();
        int cw, ch;
        if (w == 22 && h == 17) { cw = 64; ch = 32; }
        else { cw = Math.max(w, h * 2); ch = cw / 2; }
        BufferedImage canvas = new BufferedImage(cw, ch, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = canvas.createGraphics();
        g.drawImage(src, 0, 0, null);
        g.dispose();
        if (cw > MAX_WIDTH) {
            BufferedImage small = new BufferedImage(MAX_WIDTH, MAX_WIDTH / 2, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2 = small.createGraphics();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2.drawImage(canvas, 0, 0, MAX_WIDTH, MAX_WIDTH / 2, null);
            g2.dispose();
            return small;
        }
        return canvas;
    }

    private static void readGif(java.io.File file, List<BufferedImage> frames, List<Integer> delays) throws Exception {
        Iterator<ImageReader> it = ImageIO.getImageReadersByFormatName("gif");
        if (!it.hasNext()) throw new IllegalStateException("GIF reader is unavailable");
        ImageReader reader = it.next();
        try (ImageInputStream in = ImageIO.createImageInputStream(file)) {
            reader.setInput(in, false);
            int count = Math.min(reader.getNumImages(true), MAX_FRAMES);
            int sw = 0, sh = 0;
            IIOMetadata sm = reader.getStreamMetadata();
            if (sm != null) {
                Node root = sm.getAsTree("javax_imageio_gif_stream_1.0");
                sw = intAttr(root, "LogicalScreenDescriptor", "logicalScreenWidth", 0);
                sh = intAttr(root, "LogicalScreenDescriptor", "logicalScreenHeight", 0);
            }
            BufferedImage canvas = null;
            for (int i = 0; i < count; i++) {
                BufferedImage fr = reader.read(i);
                Node md = reader.getImageMetadata(i).getAsTree("javax_imageio_gif_image_1.0");
                int left = intAttr(md, "ImageDescriptor", "imageLeftPosition", 0);
                int top = intAttr(md, "ImageDescriptor", "imageTopPosition", 0);
                int delay = intAttr(md, "GraphicControlExtension", "delayTime", 5) * 10;
                String disposal = strAttr(md, "GraphicControlExtension", "disposalMethod", "none");
                if (canvas == null) {
                    canvas = new BufferedImage(sw > 0 ? sw : fr.getWidth(), sh > 0 ? sh : fr.getHeight(), BufferedImage.TYPE_INT_ARGB);
                }
                BufferedImage before = disposal.equals("restoreToPrevious") ? copy(canvas) : null;
                Graphics2D g = canvas.createGraphics();
                g.drawImage(fr, left, top, null);
                g.dispose();
                frames.add(copy(canvas));
                delays.add(delay);
                if (disposal.equals("restoreToBackgroundColor")) {
                    Graphics2D cg = canvas.createGraphics();
                    cg.setComposite(AlphaComposite.Clear);
                    cg.fillRect(left, top, fr.getWidth(), fr.getHeight());
                    cg.dispose();
                } else if (before != null) {
                    canvas = before;
                }
            }
        } finally {
            reader.dispose();
        }
    }

    private static BufferedImage copy(BufferedImage src) {
        BufferedImage out = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.drawImage(src, 0, 0, null);
        g.dispose();
        return out;
    }

    private static Node child(Node parent, String name) {
        for (Node n = parent.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (name.equals(n.getNodeName())) return n;
        }
        return null;
    }

    private static String strAttr(Node root, String childName, String attr, String def) {
        Node c = child(root, childName);
        if (c == null) return def;
        NamedNodeMap a = c.getAttributes();
        Node v = a == null ? null : a.getNamedItem(attr);
        return v == null ? def : v.getNodeValue();
    }

    private static int intAttr(Node root, String childName, String attr, int def) {
        try { return Integer.parseInt(strAttr(root, childName, attr, String.valueOf(def))); } catch (NumberFormatException e) { return def; }
    }
}
