package dev.shadowclient.module.modules;

import dev.shadowclient.module.ClientModule;
import dev.shadowclient.module.ModuleCategory;

public final class ScreenshotToastModule extends ClientModule {
    public ScreenshotToastModule() { super("Screenshot Notice", "Shows a small local screenshot notification.", ModuleCategory.QUALITY); }
}
