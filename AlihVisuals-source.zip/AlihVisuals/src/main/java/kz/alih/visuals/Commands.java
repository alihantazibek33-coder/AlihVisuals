package kz.alih.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.Locale;

/** Client side chat commands: .dupe  and  .friends */
public final class Commands {
    private Commands() {}

    /** @return true if the message was one of ours (it is then NOT sent to the server). */
    public static boolean handle(String msg) {
        String t = msg.trim();
        if (!t.startsWith(".") || t.length() < 2) return false;
        String[] a = t.substring(1).trim().split("\\s+");
        String cmd = a[0].toLowerCase(Locale.ROOT);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return false;
        switch (cmd) {
            case "dupe" -> { remember(mc, msg); dupe(mc, a); return true; }
            case "friends", "friend" -> { remember(mc, msg); friends(mc, a); return true; }
            default -> { return false; }
        }
    }

    private static void remember(MinecraftClient mc, String msg) {
        mc.inGameHud.getChatHud().addToMessageHistory(msg);
    }

    private static void say(MinecraftClient mc, String text, Formatting color) {
        mc.player.sendMessage(Text.literal("[AlihVisuals] ").formatted(Formatting.AQUA)
                .append(Text.literal(text).formatted(color)), false);
    }

    // ------------------------------------------------------------------ .dupe [amount]
    private static void dupe(MinecraftClient mc, String[] a) {
        ClientPlayerEntity p = mc.player;
        if (!p.isCreative()) { say(mc, ".dupe тек творчество режимінде жұмыс істейді", Formatting.RED); return; }
        ItemStack hand = p.getMainHandStack();
        if (hand.isEmpty()) { say(mc, "Қолыңда зат жоқ", Formatting.RED); return; }

        int amount = 1;
        if (a.length > 1) {
            try { amount = Math.max(1, Math.min(36, Integer.parseInt(a[1]))); }
            catch (NumberFormatException e) { say(mc, "Қолдану: .dupe [саны]", Formatting.RED); return; }
        }

        PlayerInventory inv = p.getInventory();
        int given = 0;
        for (int n = 0; n < amount; n++) {
            int slot = emptySlot(inv);
            if (slot < 0) break;
            ItemStack copy = hand.copy();   // copy keeps enchantments, name, all components
            inv.setStack(slot, copy);
            mc.interactionManager.clickCreativeStack(copy, slot < 9 ? 36 + slot : slot);
            given++;
        }
        if (given == 0) say(mc, "Инвентарь толы", Formatting.RED);
        else say(mc, hand.getName().getString() + " x" + given + " көшірілді", Formatting.GREEN);
    }

    private static int emptySlot(PlayerInventory inv) {
        for (int i = 9; i < 36; i++) if (inv.getStack(i).isEmpty()) return i;
        for (int i = 0; i < 9; i++) if (inv.getStack(i).isEmpty()) return i;
        return -1;
    }

    // ------------------------------------------------------------------ .friends <add|remove|list> [nick]
    private static void friends(MinecraftClient mc, String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
        switch (sub) {
            case "add" -> {
                if (a.length < 3) { say(mc, "Қолдану: .friends add <ник>", Formatting.RED); return; }
                if (mc.getNetworkHandler() == null) return;
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(a[2]);
                if (e == null) { say(mc, a[2] + " ойында жоқ (қосу үшін ойында отыруы керек)", Formatting.RED); return; }
                String name = e.getProfile().getName();
                if (e.getProfile().getId().equals(mc.player.getUuid())) { say(mc, "Өзіңді қоса алмайсың", Formatting.RED); return; }
                if (Friends.add(e.getProfile().getId(), name)) say(mc, name + " достарға қосылды - енді оны ұра алмайсың", Formatting.GREEN);
                else say(mc, name + " бұрыннан дос", Formatting.YELLOW);
            }
            case "remove", "del", "delete" -> {
                if (a.length < 3) { say(mc, "Қолдану: .friends remove <ник>", Formatting.RED); return; }
                if (Friends.remove(a[2])) say(mc, a[2] + " достардан өшірілді", Formatting.GREEN);
                else say(mc, a[2] + " достар тізімінде жоқ", Formatting.RED);
            }
            case "list" -> {
                List<String> n = Friends.names();
                say(mc, n.isEmpty() ? "Достар жоқ" : "Достар: " + String.join(", ", n), Formatting.YELLOW);
            }
            default -> say(mc, "Қолдану: .friends <add/remove/list> <ник>", Formatting.YELLOW);
        }
    }
}
