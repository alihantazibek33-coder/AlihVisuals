package kz.alih.visuals;

public final class Colors {
    private Colors() {}

    public static int hsb(float h, float s, float b) {
        float hh = (h - (float) Math.floor(h)) * 6f;
        float f = hh - (float) Math.floor(hh);
        float p = b * (1 - s), q = b * (1 - s * f), t = b * (1 - s * (1 - f));
        float r, g, bl;
        switch ((int) hh) {
            case 0 -> { r = b; g = t; bl = p; }
            case 1 -> { r = q; g = b; bl = p; }
            case 2 -> { r = p; g = b; bl = t; }
            case 3 -> { r = p; g = q; bl = b; }
            case 4 -> { r = t; g = p; bl = b; }
            default -> { r = b; g = p; bl = q; }
        }
        return ((int) (r * 255 + .5f) << 16) | ((int) (g * 255 + .5f) << 8) | (int) (bl * 255 + .5f);
    }

    public static int argb(int a, int rgb) {
        return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF);
    }

    public static int mulAlpha(int c, float f) {
        int a = (int) ((c >>> 24) * Math.max(0f, Math.min(1f, f)));
        return (a << 24) | (c & 0xFFFFFF);
    }

    public static int lerp(int a, int b, float t) {
        int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, aa = a >>> 24;
        int br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255, ba = b >>> 24;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }
}
